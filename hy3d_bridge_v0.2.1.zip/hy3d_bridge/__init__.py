# -*- coding: utf-8 -*-
"""
HY3D to Unreal Bridge  v0.2.0
==============================

混元生3D → Blender 整理 → UE 导入 的一站式桥接插件。

相对 v0.1.0 的新增能力：
  1. 导入：支持单个文件 / 整个文件夹批量；支持 GLB、GLTF、FBX、OBJ
  2. 合并：把混元输出的上千个碎片网格合并（全部 / 按材质 / 不合并）
  3. 整理：应用变换、轴心居中到底部、按系数缩放、规范命名
  4. 检查：面数、网格数、UV、材质、贴图分辨率（超限告警）
  5. 贴图：一键把超大贴图压到指定上限并重新打包（不改动源文件）
  6. 导出：GLB / FBX 可选，导出到约定目录
  7. 一键：导入最新 → 整理 → 检查 → 导出，串成一条命令
  8. 路径配置放在插件偏好设置里，不写进 .blend

面板位置：3D 视图 > 侧边栏(N) > HY3D

作者备注：导出参数用「按 RNA 过滤」的方式调用，
          所以不同 Blender 小版本删改了算子参数也不会报错。
"""

bl_info = {
    "name": "HY3D to Unreal Bridge",
    "author": "Codex / DSH",
    "version": (0, 2, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > HY3D",
    "description": "导入混元生3D模型、合并碎片、检查贴图、整理并导出 GLB/FBX 给 UE",
    "category": "Import-Export",
}

import os
import re

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup

ADDON_ID = __name__
HUNYUAN_URL = "https://3d.hunyuan.tencent.com/"
MODEL_EXTS = (".glb", ".gltf", ".fbx", ".obj")


# =====================================================================
#  偏好设置（跨文件保存，不进 .blend）
# =====================================================================

class HY3D_AddonPreferences(AddonPreferences):
    bl_idname = ADDON_ID

    import_dir: StringProperty(
        name="模型下载目录",
        description="混元/Tripo 下载的模型放在这里，「导入最新」会从这里挑",
        subtype="DIR_PATH",
        default="",
    )
    export_dir: StringProperty(
        name="导出给 UE 的目录",
        description="整理好的模型导出到这里，再由 UE 侧脚本批量导入",
        subtype="DIR_PATH",
        default="E:\\HY3D\\glb",
    )
    ue_dest_path: StringProperty(
        name="UE 目标路径",
        description="仅作备忘，UE 侧脚本里也有一份",
        default="/Game/AI/HY3D",
    )
    tex_warn: IntProperty(
        name="贴图告警阈值",
        description="贴图长边超过这个值就在检查时告警",
        default=2048,
        min=64,
        max=16384,
    )


def get_prefs(context=None):
    context = context or bpy.context
    try:
        return context.preferences.addons[ADDON_ID].preferences
    except Exception:
        return None


# =====================================================================
#  场景级状态
# =====================================================================

class HY3D_Settings(PropertyGroup):
    model_path: StringProperty(name="模型文件", subtype="FILE_PATH")

    base_name: StringProperty(
        name="导出名",
        description="导出时用的资产名；留空则用源文件名",
        default="",
    )

    file_format: EnumProperty(
        name="导出格式",
        description="GLB：单文件、贴图内嵌、材质还原好；FBX：UE 原生管线，碰撞/LOD 更成熟",
        items=[
            ("GLB", "GLB", "单文件，网格+材质+贴图打包，UE 走 Interchange 导入"),
            ("FBX", "FBX", "UE 原生管线，后续做碰撞/LOD/骨骼更顺"),
        ],
        default="GLB",
    )

    merge_mode: EnumProperty(
        name="合并方式",
        description="混元输出的模型常常是上千个碎片网格，必须合并才好用",
        items=[
            ("ALL", "合并成一个", "所有选中网格合成单一对象（最常用）"),
            ("MATERIAL", "按材质合并", "每种材质合成一个对象，保留材质分组"),
            ("NONE", "不合并", "保持原始层级，谨慎使用"),
        ],
        default="ALL",
    )

    do_cleanup: BoolProperty(
        name="清理层级",
        description="解除 glTF/FBX 导入带进来的父子关系（保留世界变换）。"
                    "混元模型常带一层 scale=0.01 + 旋转 90° 的父级，"
                    "不解除的话导出到 UE 会出现缩放差 100 倍、模型躺倒",
        default=True,
    )
    do_delete_empties: BoolProperty(
        name="删除遗留空物体",
        description="清理后删掉场景里已经没有任何子级的 EMPTY 对象（混元模型常带数千个）",
        default=True,
    )
    do_apply_transform: BoolProperty(
        name="应用变换",
        description="应用旋转和缩放（Ctrl+A 的等价操作），避免导入 UE 后朝向/比例异常",
        default=True,
    )
    do_center_bottom: BoolProperty(
        name="轴心居中到底部",
        description="把原点挪到底面中心，方便在 UE 里贴地摆放",
        default=True,
    )
    do_scale: BoolProperty(name="缩放", default=False)
    scale_factor: FloatProperty(
        name="缩放系数",
        description="例如 Blender 里偏小就填 100，偏大就填 0.01",
        default=1.0,
        min=0.000001,
        max=1000000.0,
    )

    do_downscale: BoolProperty(
        name="压缩贴图",
        description="把内存里的贴图缩到上限并重新打包；不改动原始贴图文件",
        default=False,
    )
    tex_size: EnumProperty(
        name="贴图上限",
        items=[
            ("512", "512", ""),
            ("1024", "1024", ""),
            ("2048", "2048", ""),
            ("4096", "4096", ""),
        ],
        default="2048",
    )

    report: StringProperty(name="检查结果", default="")
    last_export: StringProperty(name="最近导出", default="")
    status: StringProperty(name="状态", default="")


# =====================================================================
#  工具函数
# =====================================================================

def ensure_dir(path):
    if path and not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def sanitize(name, fallback="model"):
    """转成 UE 安全的 ASCII 资产名。"""
    name = re.sub(r"[^0-9A-Za-z_\-]", "_", name or "")
    name = re.sub(r"_{2,}", "_", name).strip("_")
    if not name:
        name = fallback
    if name[0].isdigit():
        name = "M_" + name
    return name


def stem_of(path):
    """取文件名主名；浏览器存成 .glb 这种无名文件时退回父文件夹名。"""
    stem = os.path.splitext(os.path.basename(path))[0].strip(" .")
    if not stem:
        stem = os.path.basename(os.path.dirname(os.path.abspath(path))).strip(" .")
    return stem or "model"


def call_filtered(op, **kwargs):
    """只传算子确实支持的参数，避免版本差异导致 TypeError。"""
    try:
        valid = set(op.get_rna_type().properties.keys())
    except Exception:
        valid = set(kwargs.keys())
    return op(**{k: v for k, v in kwargs.items() if k in valid})


def selected_meshes(context):
    return [o for o in context.selected_objects if o.type == "MESH"]


def tri_count(obj):
    try:
        return sum(len(p.vertices) - 2 for p in obj.data.polygons)
    except Exception:
        return 0


def object_materials(obj):
    return [s.material for s in obj.material_slots if s.material]


def used_images(objs):
    imgs = {}
    for obj in objs:
        for mat in object_materials(obj):
            if not mat.use_nodes or not mat.node_tree:
                continue
            for node in mat.node_tree.nodes:
                if node.type != "TEX_IMAGE" or node.image is None:
                    continue
                img = node.image
                imgs[img.name] = img
    return imgs


def deselect_all():
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        for o in bpy.context.selected_objects:
            o.select_set(False)


def only_select(objs, active=None):
    deselect_all()
    for o in objs:
        try:
            o.select_set(True)
        except Exception:
            pass
    if objs:
        bpy.context.view_layer.objects.active = active or objs[0]


def join_objects(context, objs, name=None):
    """把 objs 合并成一个对象，返回合并后的对象。"""
    objs = [o for o in objs if o and o.name in context.view_layer.objects]
    if not objs:
        return None
    if len(objs) == 1:
        target = objs[0]
    else:
        # 确保处于物体模式
        try:
            if context.object and context.object.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        only_select(objs)
        try:
            bpy.ops.object.join()
        except Exception as exc:                                    # noqa: BLE001
            print("[HY3D] join 失败：%s" % exc)
            return None
        target = context.view_layer.objects.active
    if name and target:
        target.name = name
        if target.data:
            target.data.name = name
    return target


def apply_transform(context, objs):
    only_select(objs)
    try:
        call_filtered(
            bpy.ops.object.transform_apply,
            location=False, rotation=True, scale=True, properties=True,
        )
        return True
    except Exception as exc:                                        # noqa: BLE001
        print("[HY3D] transform_apply 失败：%s" % exc)
        return False


def clear_parents(context, objs):
    """解除父子关系但保留世界变换（冻结父级带来的缩放/旋转）。"""
    only_select(objs)
    try:
        call_filtered(bpy.ops.object.parent_clear, type="CLEAR_KEEP_TRANSFORM")
        return True
    except Exception as exc:                                        # noqa: BLE001
        print("[HY3D] parent_clear 失败：%s" % exc)
        return False


def delete_orphan_empties(context):
    """删掉已经没有任何子级的 EMPTY，反复扫描直到清干净。

    嵌套的组层级（组的子级还是组）需要多轮才能删完，
    混元模型常常带数千个空物体。只删空的，绝不动还有子级的。

    实现注意：删除对象会让先前拿到的 Python 引用失效，
    所以每轮只收集「名字」，再按名字回查删除。
    """
    total = 0
    for _round in range(64):
        names = []
        for o in list(context.view_layer.objects):
            if o is None:
                continue
            try:
                if o.type == "EMPTY" and not o.children:
                    names.append(o.name)
            except Exception:
                continue
        if not names:
            break
        removed = 0
        for nm in names:
            ob = bpy.data.objects.get(nm)
            if ob is None:
                continue
            try:
                bpy.data.objects.remove(ob, do_unlink=True)
                removed += 1
            except Exception:
                pass
        total += removed
        if removed == 0:
            break
    return total


def center_bottom(context, objs):
    """把每个对象的原点挪到它自身包围盒的底面中心。"""
    scene = context.scene
    ok = 0
    for obj in objs:
        try:
            corners = [obj.matrix_world @ __import__("mathutils").Vector(c)
                       for c in obj.bound_box]
            xs = [v.x for v in corners]
            ys = [v.y for v in corners]
            zs = [v.z for v in corners]
            scene.cursor.location = (
                (min(xs) + max(xs)) / 2.0,
                (min(ys) + max(ys)) / 2.0,
                min(zs),
            )
            only_select([obj])
            bpy.ops.object.origin_set(type="ORIGIN_CURSOR")
            ok += 1
        except Exception as exc:                                    # noqa: BLE001
            print("[HY3D] 居中失败 %s: %s" % (obj.name, exc))
    try:
        scene.cursor.location = (0.0, 0.0, 0.0)
    except Exception:
        pass
    return ok


def do_scaling(context, objs, factor):
    only_select(objs)
    for obj in objs:
        obj.scale = (factor, factor, factor)
    try:
        call_filtered(
            bpy.ops.object.transform_apply,
            location=False, rotation=False, scale=True, properties=True,
        )
        return True
    except Exception as exc:                                        # noqa: BLE001
        print("[HY3D] 缩放应用失败：%s" % exc)
        return False


def build_report(context, objs):
    prefs = get_prefs(context)
    warn = prefs.tex_warn if prefs else 2048

    if not objs:
        return "没有选中任何网格。"

    tris = sum(tri_count(o) for o in objs)
    verts = sum(len(o.data.vertices) for o in objs)
    no_uv = [o.name for o in objs if not o.data.uv_layers]
    no_mat = [o.name for o in objs if not o.material_slots]

    mats = {}
    for o in objs:
        for m in object_materials(o):
            mats[m.name] = m

    imgs = used_images(objs)
    big, small = [], []
    for img in imgs.values():
        try:
            w, h = img.size
        except Exception:
            continue
        if max(w, h) <= 0:
            continue
        (big if max(w, h) > warn else small).append("%s %dx%d" % (img.name, w, h))

    lines = []
    lines.append("网格 %d 个｜顶点 %s｜三角面 %s" % (len(objs), f"{verts:,}", f"{tris:,}"))
    lines.append("材质 %d 个｜贴图 %d 张" % (len(mats), len(imgs)))

    if no_uv:
        lines.append("⚠ 无 UV：%d 个（%s%s）" % (
            len(no_uv), ", ".join(no_uv[:3]), " ..." if len(no_uv) > 3 else ""))
    if no_mat:
        lines.append("⚠ 无材质：%d 个" % len(no_mat))

    if big:
        lines.append("⚠ 贴图超过 %d：" % warn)
        for s in big[:6]:
            lines.append("    " + s)
    if small:
        lines.append("✓ 贴图尺寸正常 %d 张" % len(small))

    if len(objs) > 200:
        lines.append("⚠ 网格数过多（%d），建议先合并" % len(objs))

    return "\n".join(lines)


def downscale_images(context, objs, target):
    imgs = used_images(objs)
    changed, skipped = 0, 0
    for img in imgs.values():
        try:
            w, h = img.size
            if max(w, h) <= target or max(w, h) == 0:
                skipped += 1
                continue
            f = float(target) / float(max(w, h))
            nw = max(1, int(round(w * f)))
            nh = max(1, int(round(h * f)))
            img.scale(nw, nh)
            # 重新打包，让导出时用的是缩小后的像素
            try:
                if img.packed_file:
                    img.pack()
            except Exception:
                pass
            changed += 1
        except Exception as exc:                                    # noqa: BLE001
            print("[HY3D] 贴图压缩失败 %s: %s" % (img.name, exc))
            skipped += 1
    return changed, skipped


# =====================================================================
#  算子
# =====================================================================

class HY3D_OT_open_site(Operator):
    bl_idname = "hy3d.open_site"
    bl_label = "打开腾讯混元 3D"
    bl_description = "在默认浏览器中打开腾讯混元 3D 创作网站"

    def execute(self, context):
        bpy.ops.wm.url_open(url=HUNYUAN_URL)
        return {"FINISHED"}


class HY3D_OT_open_import_dir(Operator):
    bl_idname = "hy3d.open_import_dir"
    bl_label = "打开下载目录"
    bl_description = "在资源管理器里打开模型下载目录"

    def execute(self, context):
        prefs = get_prefs(context)
        d = prefs.import_dir if prefs else ""
        if not d or not os.path.isdir(d):
            self.report({"ERROR"}, "下载目录没设置或不存在，去插件偏好设置里填")
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=d)
        return {"FINISHED"}


class HY3D_OT_open_export_dir(Operator):
    bl_idname = "hy3d.open_export_dir"
    bl_label = "打开导出目录"
    bl_description = "在资源管理器里打开给 UE 的导出目录"

    def execute(self, context):
        prefs = get_prefs(context)
        d = prefs.export_dir if prefs else ""
        if not d or not os.path.isdir(d):
            self.report({"ERROR"}, "导出目录没设置或不存在，去插件偏好设置里填")
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=d)
        return {"FINISHED"}


class HY3D_OT_import(Operator):
    bl_idname = "hy3d.import_model"
    bl_label = "导入选中文件"
    bl_description = "导入指定的 GLB / GLTF / FBX / OBJ 文件"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        path = bpy.path.abspath(st.model_path)
        if not os.path.isfile(path):
            self.report({"ERROR"}, "请先选择一个存在的模型文件")
            return {"CANCELLED"}

        deselect_all()
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext in (".glb", ".gltf"):
                call_filtered(bpy.ops.import_scene.gltf, filepath=path)
            elif ext == ".fbx":
                call_filtered(bpy.ops.import_scene.fbx, filepath=path)
            elif ext == ".obj":
                call_filtered(bpy.ops.wm.obj_import, filepath=path)
            else:
                self.report({"ERROR"}, "只支持 GLB / GLTF / FBX / OBJ")
                return {"CANCELLED"}
        except Exception as exc:                                    # noqa: BLE001
            self.report({"ERROR"}, "导入失败：%s" % exc)
            return {"CANCELLED"}

        got = selected_meshes(context)
        if not st.base_name.strip():
            st.base_name = sanitize(stem_of(path))
        msg = "已导入 %d 个网格" % len(got)
        st.status = msg
        self.report({"INFO"}, msg + "；检查材质、比例和法线")
        return {"FINISHED"}


class HY3D_OT_import_latest(Operator):
    bl_idname = "hy3d.import_latest"
    bl_label = "导入目录里最新的模型"
    bl_description = "从下载目录里挑最新的一个模型文件导入（按修改时间）"

    def execute(self, context):
        prefs = get_prefs(context)
        d = prefs.import_dir if prefs else ""
        if not d or not os.path.isdir(d):
            self.report({"ERROR"}, "下载目录没设置或不存在")
            return {"CANCELLED"}

        cands = []
        for fn in os.listdir(d):
            full = os.path.join(d, fn)
            if os.path.isfile(full) and fn.lower().endswith(MODEL_EXTS):
                cands.append((os.path.getmtime(full), full))
        if not cands:
            self.report({"WARNING"}, "目录里没有模型文件")
            return {"CANCELLED"}

        cands.sort(reverse=True)
        newest = cands[0][1]
        context.scene.hy3d_bridge.model_path = newest
        context.scene.hy3d_bridge.base_name = sanitize(stem_of(newest))
        return bpy.ops.hy3d.import_model()


class HY3D_OT_select_meshes(Operator):
    bl_idname = "hy3d.select_all_meshes"
    bl_label = "选中场景里所有网格"
    bl_description = "把当前视图层里所有网格设为选中"

    def execute(self, context):
        meshes = [o for o in context.view_layer.objects if o.type == "MESH"]
        if not meshes:
            self.report({"WARNING"}, "场景里没有网格")
            return {"CANCELLED"}
        only_select(meshes)
        context.scene.hy3d_bridge.status = "已选中 %d 个网格" % len(meshes)
        return {"FINISHED"}


class HY3D_OT_merge(Operator):
    bl_idname = "hy3d.merge_selected"
    bl_label = "合并选中网格"
    bl_description = "按设定的合并方式把选中的碎片网格合并"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        objs = selected_meshes(context)
        if not objs:
            self.report({"WARNING"}, "请先选中网格")
            return {"CANCELLED"}

        base = sanitize(st.base_name.strip() or "model", "model")

        if st.merge_mode == "NONE" or len(objs) == 1:
            st.status = "未合并（选中 %d 个）" % len(objs)
            self.report({"INFO"}, st.status)
            return {"FINISHED"}

        before = len(objs)

        if st.merge_mode == "ALL":
            joined = join_objects(context, objs, name=base)
            if not joined:
                self.report({"ERROR"}, "合并失败，看控制台")
                return {"CANCELLED"}
        else:  # MATERIAL
            groups = {}
            for o in objs:
                key = tuple(sorted(m.name for m in object_materials(o))) or ("<none>",)
                groups.setdefault(key, []).append(o)
            made = 0
            for i, (key, group) in enumerate(sorted(groups.items(), key=lambda kv: kv[0])):
                nm = base if len(groups) == 1 else "%s_%02d" % (base, i + 1)
                if join_objects(context, group, name=nm):
                    made += 1
            if made == 0:
                self.report({"ERROR"}, "按材质合并失败，看控制台")
                return {"CANCELLED"}

        st.status = "合并：%d → %d" % (before, len(selected_meshes(context)) or 1)
        self.report({"INFO"}, st.status)
        return {"FINISHED"}


class HY3D_OT_prepare(Operator):
    bl_idname = "hy3d.prepare_selected"
    bl_label = "整理选中模型"
    bl_description = "应用变换、轴心居中到底部、按系数缩放、规范命名"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        objs = selected_meshes(context)
        if not objs:
            self.report({"WARNING"}, "请先选中网格")
            return {"CANCELLED"}

        done = []
        if st.do_cleanup:
            if clear_parents(context, objs):
                done.append("解除父级")
            if st.do_delete_empties:
                n = delete_orphan_empties(context)
                if n:
                    done.append("删空物体x%d" % n)
        if st.do_apply_transform and apply_transform(context, objs):
            done.append("应用变换")
        if st.do_scale and st.scale_factor != 1.0 and do_scaling(context, objs, st.scale_factor):
            done.append("缩放 x%g" % st.scale_factor)
        if st.do_center_bottom:
            n = center_bottom(context, objs)
            done.append("居中底部 x%d" % n)

        base = sanitize(st.base_name.strip() or "model", "model")
        if len(objs) == 1:
            objs[0].name = base
            if objs[0].data:
                objs[0].data.name = base

        st.status = "整理完成：" + ("、".join(done) if done else "无操作")
        self.report({"INFO"}, st.status)
        return {"FINISHED"}


class HY3D_OT_inspect(Operator):
    bl_idname = "hy3d.inspect_selection"
    bl_label = "检查选中模型"
    bl_description = "统计网格数、面数、UV、材质、贴图分辨率"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        objs = selected_meshes(context)
        if not objs:
            self.report({"WARNING"}, "请先选中网格")
            return {"CANCELLED"}
        st.report = build_report(context, objs)
        print("[HY3D 检查]\n" + st.report)
        first = st.report.splitlines()[0] if st.report else ""
        self.report({"INFO"}, first)
        return {"FINISHED"}


class HY3D_OT_downscale(Operator):
    bl_idname = "hy3d.downscale_textures"
    bl_label = "压缩选中模型的贴图"
    bl_description = "把贴图缩到设定上限并重新打包（不改动磁盘上的原始贴图）"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        objs = selected_meshes(context)
        if not objs:
            self.report({"WARNING"}, "请先选中网格")
            return {"CANCELLED"}
        target = int(st.tex_size)
        changed, skipped = downscale_images(context, objs, target)
        st.status = "贴图：压缩 %d 张，跳过 %d 张" % (changed, skipped)
        self.report({"INFO"}, st.status + "（请重新检查确认）")
        return {"FINISHED"}


class HY3D_OT_export(Operator):
    bl_idname = "hy3d.export_model"
    bl_label = "导出选中模型给 UE"
    bl_description = "按选定格式导出到偏好设置里的导出目录"

    def execute(self, context):
        st = context.scene.hy3d_bridge
        prefs = get_prefs(context)

        objs = selected_meshes(context)
        if not objs:
            self.report({"ERROR"}, "请先选中要导出的网格")
            return {"CANCELLED"}

        out_dir = (prefs.export_dir if prefs else "") or ""
        if not out_dir:
            self.report({"ERROR"}, "没设置导出目录（编辑 > 偏好设置 > 插件 > HY3D）")
            return {"CANCELLED"}
        ensure_dir(out_dir)

        base = sanitize(st.base_name.strip() or stem_of(st.model_path) or "model", "model")

        try:
            if st.file_format == "GLB":
                path = os.path.join(out_dir, base + ".glb")
                call_filtered(
                    bpy.ops.export_scene.gltf,
                    filepath=path,
                    export_format="GLB",
                    use_selection=True,
                    export_apply=True,
                    export_yup=True,
                    export_materials="EXPORT",
                    export_image_format="AUTO",
                )
            else:
                path = os.path.join(out_dir, base + ".fbx")
                call_filtered(
                    bpy.ops.export_scene.fbx,
                    filepath=path,
                    use_selection=True,
                    apply_scale_options="FBX_SCALE_ALL",
                    global_scale=1.0,
                    path_mode="COPY",
                    embed_textures=True,
                    mesh_smooth_type="FACE",
                    use_mesh_modifiers=True,
                )
        except Exception as exc:                                    # noqa: BLE001
            self.report({"ERROR"}, "导出失败：%s" % exc)
            return {"CANCELLED"}

        if not os.path.isfile(path):
            self.report({"ERROR"}, "导出命令跑完但文件不存在：%s" % path)
            return {"CANCELLED"}

        size = os.path.getsize(path) / 1024.0 / 1024.0
        st.last_export = path
        st.status = "已导出 %s（%.1f MB）" % (os.path.basename(path), size)
        self.report({"INFO"}, st.status)
        return {"FINISHED"}


class HY3D_OT_run_all(Operator):
    bl_idname = "hy3d.run_all"
    bl_label = "一键：整理并导出"
    bl_description = "选中网格 → 合并 → 整理 → 检查 → 导出，一次跑完"

    def execute(self, context):
        st = context.scene.hy3d_bridge

        if not selected_meshes(context):
            self.report({"WARNING"}, "请先选中网格（或先点「导入目录里最新的模型」）")
            return {"CANCELLED"}

        steps = []

        if st.merge_mode != "NONE":
            r = bpy.ops.hy3d.merge_selected()
            steps.append("合并%s" % ("✓" if "FINISHED" in r else "✗"))

        r = bpy.ops.hy3d.prepare_selected()
        steps.append("整理%s" % ("✓" if "FINISHED" in r else "✗"))

        r = bpy.ops.hy3d.inspect_selection()
        steps.append("检查%s" % ("✓" if "FINISHED" in r else "✗"))

        if st.do_downscale:
            r = bpy.ops.hy3d.downscale_textures()
            steps.append("压贴图%s" % ("✓" if "FINISHED" in r else "✗"))
            bpy.ops.hy3d.inspect_selection()

        r = bpy.ops.hy3d.export_model()
        steps.append("导出%s" % ("✓" if "FINISHED" in r else "✗"))

        st.status = "一键完成：" + " ".join(steps)
        self.report({"INFO"}, st.status)
        return {"FINISHED"}


# =====================================================================
#  面板
# =====================================================================

class HY3D_PT_main(Panel):
    bl_label = "混元 3D → UE"
    bl_idname = "HY3D_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HY3D"

    def draw(self, context):
        layout = self.layout
        st = context.scene.hy3d_bridge
        prefs = get_prefs(context)

        # --- 1 生成 ---
        box = layout.box()
        box.label(text="1. 网页生成 / 智能拓扑 / UV", icon="URL")
        box.operator("hy3d.open_site", icon="URL")
        row = box.row(align=True)
        row.operator("hy3d.open_import_dir", text="下载目录", icon="FILE_FOLDER")
        if prefs and prefs.import_dir:
            box.label(text=os.path.basename(prefs.import_dir.rstrip("\\/")) or prefs.import_dir)

        # --- 2 导入 ---
        box = layout.box()
        box.label(text="2. 导入 Blender", icon="IMPORT")
        box.prop(st, "model_path", text="文件")
        row = box.row(align=True)
        row.operator("hy3d.import_model", icon="IMPORT")
        row.operator("hy3d.import_latest", text="导入最新")
        box.operator("hy3d.select_all_meshes", icon="RESTRICT_SELECT_OFF")

        # --- 3 整理 ---
        box = layout.box()
        box.label(text="3. 整理（碎片网格必做）", icon="MODIFIER")
        box.prop(st, "merge_mode", text="")
        row = box.row(align=True)
        row.prop(st, "do_cleanup")
        sub = row.row()
        sub.enabled = st.do_cleanup
        sub.prop(st, "do_delete_empties", text="删空物体")
        row = box.row(align=True)
        row.prop(st, "do_apply_transform")
        row.prop(st, "do_center_bottom")
        row = box.row(align=True)
        row.prop(st, "do_scale")
        sub = row.row()
        sub.enabled = st.do_scale
        sub.prop(st, "scale_factor", text="")
        box.prop(st, "base_name", text="导出名")
        box.operator("hy3d.merge_selected", icon="AUTOMERGE_ON")
        box.operator("hy3d.prepare_selected", icon="TRANSFORM_ORIGINS")

        # --- 4 检查 ---
        box = layout.box()
        box.label(text="4. 检查", icon="INFO")
        box.operator("hy3d.inspect_selection", icon="INFO")
        if st.report:
            for line in st.report.splitlines()[:12]:
                box.label(text=line)

        # --- 5 贴图 ---
        box = layout.box()
        box.label(text="5. 贴图压缩", icon="IMAGE_DATA")
        row = box.row(align=True)
        row.prop(st, "do_downscale", text="")
        sub = row.row()
        sub.enabled = st.do_downscale
        sub.prop(st, "tex_size", text="上限")
        box.operator("hy3d.downscale_textures", icon="FULLSCREEN_ENTER")

        # --- 6 导出 ---
        box = layout.box()
        box.label(text="6. 导出给 UE", icon="EXPORT")
        box.prop(st, "file_format", text="格式")
        row = box.row(align=True)
        row.operator("hy3d.open_export_dir", text="导出目录", icon="FILE_FOLDER")
        if prefs and prefs.export_dir:
            box.label(text=os.path.basename(prefs.export_dir.rstrip("\\/")) or prefs.export_dir)
        box.operator("hy3d.export_model", icon="EXPORT")
        box.operator("hy3d.run_all", icon="PLAY")

        if st.status:
            box.label(text=st.status[:64], icon="CHECKMARK")


class HY3D_PT_help(Panel):
    bl_label = "流程说明"
    bl_idname = "HY3D_PT_help"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HY3D"
    bl_parent_id = "HY3D_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        for line in (
            "① 混元网页生成 → 下载模型",
            "② 导入最新（或手选文件）",
            "③ 合并（混元输出常有上千碎片）",
            "④ 整理（朝向 / 轴心 / 缩放）",
            "⑤ 检查（面数 / UV / 贴图尺寸）",
            "⑥ 导出 GLB 或 FBX 到约定目录",
            "⑦ 在 UE 里跑批量导入脚本",
        ):
            layout.label(text=line)
        layout.separator()
        layout.label(text="路径等全局设置：")
        layout.label(text="编辑 > 偏好设置 > 插件 > HY3D")


# =====================================================================
#  注册
# =====================================================================

CLASSES = (
    HY3D_AddonPreferences,
    HY3D_Settings,
    HY3D_OT_open_site,
    HY3D_OT_open_import_dir,
    HY3D_OT_open_export_dir,
    HY3D_OT_import,
    HY3D_OT_import_latest,
    HY3D_OT_select_meshes,
    HY3D_OT_merge,
    HY3D_OT_prepare,
    HY3D_OT_inspect,
    HY3D_OT_downscale,
    HY3D_OT_export,
    HY3D_OT_run_all,
    HY3D_PT_main,
    HY3D_PT_help,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hy3d_bridge = PointerProperty(type=HY3D_Settings)


def unregister():
    try:
        del bpy.types.Scene.hy3d_bridge
    except Exception:
        pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
