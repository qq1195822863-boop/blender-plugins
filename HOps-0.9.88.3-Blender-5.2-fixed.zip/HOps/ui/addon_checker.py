# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from .. utils.addons import addon_exists

used_addons = [
    ('kitops' or 'Kit_OPS', 'Kitops',           'https://item.taobao.com/item.htm?ft=t&id=750703295677'),
    ('Cablerator',          'Cablerator',       'https://item.taobao.com/item.htm?ft=t&id=750447024999'),
    ('PowerSave',           'PowerSave',        'https://item.taobao.com/item.htm?ft=t&id=750843156413'),
    ('Boxcutter',           'Boxcutter',        'https://item.taobao.com/item.htm?ft=t&id=750564170833'),
    ('mira_tools',          'Mira Tools',       'https://item.taobao.com/item.htm?ft=t&id=750893014410'),
    ('MESHmachine',         'MESHmachine',      'https://item.taobao.com/item.htm?ft=t&id=750554249560'),
    ("DECALmachine",        "DECALmachine",     'https://item.taobao.com/item.htm?ft=t&id=750414324312'),
    ('batch_ops',           'Batch_OPS',        'https://item.taobao.com/item.htm?ft=t&id=751618463959'),
    ('conform_object',      'Conform Object',   'https://item.taobao.com/item.htm?ft=t&id=750780746568'),

]

recommended_addons = [
    ("GroupPro",            "Group Pro",        "https://item.taobao.com/item.htm?ft=t&id=750770410428"),
    ('mesh_shaper',         'Mesh Shaper',      'https://item.taobao.com/item.htm?ft=t&id=750891794174'),
    ("power_snapping_pies", "Snapping Pies",    "https://github.com/mx1001/power_snapping_pies"),
    ('zen_uv',           'Zen UV',              'https://item.taobao.com/item.htm?ft=t&id=750706645566')
]

def draw_addon_diagnostics(layout, columns = 2):
    box = layout.box()
    box.label(text=_z("Recommended Addons"))
    box = box.box()
    draw_addon_table(box, used_addons, columns, True)

    box = layout.box()
    box.label(text=_z("Additional Addons"))
    box = box.box()
    draw_addon_table(box, recommended_addons, columns, False)


def draw_addon_table(layout, addons, columns, show_existance):
    col = layout.column()
    for i, (identifier, name, url) in enumerate(addons):
        if i % columns == 0: row = col.row()
        icon = addon_icon(identifier, show_existance)
        if icon == "FILE_TICK":
            row.operator("hops.display_notification", text=name, icon = icon).info = name +' Active'
        else:
            row.operator("wm.url_open", text=name, icon = icon).url = url

    if len(addons) % columns != 0:
        for i in range(0, columns - len(addons) % columns):
            row.label(text="")

def addon_icon(addon_identifier, show_existance):
    if show_existance:
        if addon_exists(addon_identifier): return "FILE_TICK"
        else: return "ERROR"
    else:
        return "NONE"
