# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from ... icons import get_icon_id
from ... utils.addons import addon_exists
from ... utility import addon


class HOPS_MT_ObjectToolsSubmenu(bpy.types.Menu):
    bl_label = _z('Objects Tools Submenu')
    bl_description = 'Objects Tools Submenu'
    bl_idname = 'HOPS_MT_ObjectToolsSubmenu'

    def draw(self, context):
        layout = self.layout

        row = layout.column().row()

        if addon.preference().ui.expanded_menu:
            column = row.column()
        else:
            column =self.layout

        column.operator("hops.flatten_align", text=_z("Reset Axis/Align/Select"), icon_value=get_icon_id("Xslap"))
        column.operator("hops.set_origin", text=_z("Set Origin"), icon_value=get_icon_id("CircleSetup"))
        column.operator("hops.floor_object", text=_z("To Floor"), icon_value=get_icon_id("grey"))
        column.separator()

        column.operator("hops.bool_dice_v2", text=_z("Dice V2"), icon_value=get_icon_id("Dice"))
        column.operator("array.twist", text=_z("Twist 360"), icon_value=get_icon_id("ATwist360"))
        if addon.preference().property.radial_array_type == 'CLASSIC':
            column.operator("hops.radial_array", text=_z("Radial Array"), icon_value=get_icon_id("ArrayCircle"))
        else:
            column.operator("hops.radial_array_nodes", text=_z("Radial Array V2"), icon_value=get_icon_id("ArrayCircle")).from_empty = True
        column.separator()
        column.operator("hops.taper", text = _z("Taper / Deform"), icon_value=get_icon_id("Tris"))
        column.separator()

        column.operator("hops.sphere_cast", text=_z("SphereCast"), icon_value=get_icon_id("SphereCast"))
        column.separator()

        column.operator("hops.edge2curve", text=_z("Curve/Extract"), icon_value=get_icon_id("Curve"))
        column.operator("view3d.face_extract", text=_z("Face Extract"), icon_value=get_icon_id("FacePanel"))
        #column.separator()

        #column.operator("hops.st3_array", text="Array V2", icon_value=get_icon_id("GreyArrayX"))
        # column.separator()

        column.separator() #.modifier_types='BOOLEAN'
        column.operator("hops.apply_modifiers", text=_z("Smart Apply"), icon_value=get_icon_id("Applyall"))
        column.operator("hops.adjust_auto_smooth", text=_z("AutoSmooth"), icon_value=get_icon_id("Diagonal"))

        if addon.preference().ui.expanded_menu:
            column = row.column()
        else:
            column.separator()

        if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
            column.menu("HOPS_MT_MaterialListMenu", text = _z("Material List"), icon="MATERIAL_DATA")
            if len(context.selected_objects) >= 2:
                column.operator("material.simplify", text=_z("Material Link"), icon_value=get_icon_id("Applyall"))
            #column.separator()

        column.operator_context = 'INVOKE_DEFAULT'
        column.operator("material.hops_new", text = _z('Add Blank Material'), icon="PLUS")

        column.separator()

        column.operator("hops.xunwrap", text=_z("Auto Unwrap"), icon_value=get_icon_id("CUnwrap"))
        #column.separator()

        if len(context.selected_objects) == 1:
            column.operator("hops.reset_status", text=_z("HOPS Reset"), icon_value=get_icon_id("StatusReset"))
            #column.separator()

        if context.active_object and context.active_object.type == 'MESH':
            column.menu("HOPS_MT_SelectViewSubmenu", text=_z("Selection Options"),  icon_value=get_icon_id("ShowNgonsTris"))
            #column.separator()

        column.separator()

        column.menu("HOPS_MT_BoolScrollOperatorsSubmenu", text=_z("Mod Scroll/Toggle"), icon_value=get_icon_id("Diagonal"))

        column.separator()

        column.menu("HOPS_MT_Export", text = _z('Export'), icon="EXPORT")
        column.separator()

        if addon_exists("MESHmachine"):
            column.separator()
            column.menu("MACHIN3_MT_mesh_machine", text="MESHmachine", icon_value=get_icon_id("Machine"))

        if addon_exists("Cablerator"):
            column.menu("VIEW3D_MT_cablerator", text=_z("Cable Ops"), icon_value=get_icon_id("Cablerator"))

        if len(context.selected_objects) == 2:
            if addon_exists("conform_object"):
                column.menu("OBJECT_MT_conform_object", text=_z("Conform Object"), icon_value=get_icon_id("Cablerator"))
                column.separator()
            column.operator("hops.shrinkwrap2", text=_z("ShrinkTo"), icon='GP_MULTIFRAME_EDITING')
        else:
            column.separator()

        column.operator("hops.to_gpstroke", text=_z("To_Stroke"), icon="GREASEPENCIL")

class HOPS_MT_MeshToolsSubmenu(bpy.types.Menu):
    bl_label = _z('Mesh Tools Submenu')
    bl_description = 'Mesh Tools Submenu'
    bl_idname = 'HOPS_MT_MeshToolsSubmenu'

    def draw(self, context):
        layout = self.layout
        is_boolean = len([mod for mod in bpy.context.active_object.modifiers if mod.type == 'BOOLEAN'])

        layout.operator_context = 'INVOKE_DEFAULT'
        layout.operator("hops.helper", text=_z("Modifier Helper"), icon="SCRIPTPLUGINS")

        layout.separator()

        layout.operator("hops.bevel_assist", text=_z("Bevel / Edge Manager"), icon_value=get_icon_id("CSharpen"))

        layout.separator()

        layout.operator("hops.bevel_helper", text=_z("Bevel Helper"), icon_value=get_icon_id("ModifierHelper"))
        layout.operator("hops.sharp_manager", text=_z("Edge Manager"), icon_value=get_icon_id("Diagonal"))
        layout.operator("view3d.bevel_multiplier", text=_z("Bevel Exponent"), icon_value=get_icon_id("FaceGrate"))

        layout.separator()

        if is_boolean:
            #layout.operator("hops.scroll_multi", text="Bool Multi Scroll ", icon_value=get_icon_id("Diagonal"))
            layout.operator("hops.ever_scroll_v2", text=_z("Ever Scroll"), icon_value=get_icon_id("StatusReset"))
            layout.operator("hops.bool_scroll_objects", text=_z("Object Scroll"), icon_value=get_icon_id("StatusReset"))
            layout.separator()

        # layout.operator("hops.scroll_multi", text="Mod Scroll/Toggle", icon_value=get_icon_id("StatusReset"))
        layout.operator("hops.ever_scroll_v2", text=_z("Ever Scroll"), icon_value=get_icon_id("StatusReset"))

        op = layout.operator("hops.modifier_scroll", text=_z("Modifier Scroll"), icon_value=get_icon_id("Diagonal"))
        op.additive = True
        op.all = True

        layout.operator("hops.bool_toggle_viewport", text= _z("Toggle Modifiers"), icon_value=get_icon_id("Ngons")).all_modifiers = False

        layout.separator()

        layout.menu("HOPS_MT_Export", text = _z('Export'), icon="EXPORT")
