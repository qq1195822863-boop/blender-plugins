# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from ... utility import addon


class HOPS_PT_bool_options(bpy.types.Panel):
    bl_label = _z("Boolean")
    bl_description = "Boolean"
    bl_category = _z("HardOps")
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)
        preference = addon.preference().property
        #self.layout.row().prop(preference, 'boolean_solver', expand=True)
        row = column.row(align=True)
        row.label(text = _z("Behavior"))

        box = column.box()
        row = box.row(align=True)
        row.prop(preference, 'bool_bstep', text=_z('Bevel Step'))
        row.prop(preference, 'parent_boolshapes', text=_z('Parent Boolshapes'))

        row = column.row(align=True)
        row.label(text = _z("Auto Cutter Removal"))

        box = column.box()
        row = box.row(align=True)
        row.prop(preference, 'Hops_sharp_remove_cutters', text=_z('Csharp'))
        row.prop(preference, 'Hops_smartapply_remove_cutters', text=_z('Smart Apply'))
        
        row = column.row(align=True)
        row.label(text=_z('Cut In:'))
        
        box = column.box()
        row = box.row(align=True)
        row.prop(preference, 'keep_cutin_bevel', expand=True, text=_z('Keep Bevel'))
        #label_row(preference.property, 'Hops_sharp_remove_cutters', layout.row(), label='Hops_sharp_remove_cutters')
