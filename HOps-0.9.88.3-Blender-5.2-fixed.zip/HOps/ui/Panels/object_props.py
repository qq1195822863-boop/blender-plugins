# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.types import Panel

# from math import radians
from ... utility import addon


class HOPS_PT_dimensions_options(Panel):
    bl_label = 'Dimensions'
    bl_space_type = 'VIEW_3D'
    bl_category = _z('HardOps')
    bl_region_type = 'UI'


    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        preference = addon.preference().property
        obj = bpy.context.object

        layout.column().prop(obj, 'dimensions', expand=True)


class HOPS_PT_context_object(Panel):
    bl_label = _z('Context_object'),
    bl_category = _z('HOps'),
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        layout = self.layout
        space = context.space_data

        row = layout.row()
        row.template_ID(context.view_layer.objects, "active", filter='AVAILABLE')