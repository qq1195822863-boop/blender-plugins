# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import *
from bpy.types import (Panel,
                       Operator,
                       AddonPreferences,
                       PropertyGroup,
                       )
import os
from ... icons import get_icon_id
from ... utils.addons import addon_exists

class HOPS_PT_BooleansPanel(bpy.types.Panel):
    bl_label = _z("Booleans")
    bl_description = "Booleans"
    # bl_category = "HardOps"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)

        col.operator("hops.bool_intersect", text=_z("Intersection"), icon="ROTATECENTER")
        col.operator("hops.bool_union", text=_z("Union"), icon="ROTATECOLLECTION")
        col.operator("hops.bool_difference", text=_z("Difference"), icon="ROTACTIVE")
