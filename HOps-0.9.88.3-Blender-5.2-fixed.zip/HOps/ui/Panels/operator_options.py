# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.types import Panel

from ... utility import addon


class HOPS_PT_operator_options(Panel):
    bl_label = _z('Bevel / Operator')
    bl_description = 'Bevel / Operator'
    bl_space_type = 'VIEW_3D'
    bl_category = _z('HOps')
    bl_region_type = 'UI'


    def draw(self, context):
        layout = self.layout
        preference = addon.preference().property
        color = addon.preference().color
        ui = addon.preference().ui

        column = layout.column(align=True)
        row = column.row(align=True)
        row.label(text=_z('Bevel:'))

        box = column.box()
        row = box.row(align=True)
        split = row.split(align=True, factor=0.70)
        row.prop(preference, 'workflow_mode', expand=True)
        row.prop(preference, 'use_harden_normals', text=_z('Harden Normals'))
        row = box.row(align=True)
        row.prop(preference, 'bevel_profile', text=_z('Profile'))
        row.prop(preference, 'default_segments', text=_z('Segments'))
        row.prop(preference, 'adaptivemode', text=_z('Adaptive'))
        row = box.row(align=True)
        #row.label(text='Miter:')
        row.prop(preference, 'bevel_miter_outer', text= '')
        row.prop(preference, 'bevel_miter_inner', text= '')
        row.prop(preference, 'bevel_loop_slide', text=_z('Loop Slide'))
        column.separator()
        # column.separator()
        # row = column.row(align=True)
        # row.prop(preference, 'Hops_twist_radial_sort', text='Radial / Twist (Render Toggle)')
        # row = column.row(align=True)
        # row.prop(preference, 'to_cam_jump', text='To_Cam Jump')
        # row.prop(preference, 'to_render_jump', text='Viewport+ Set Render')
        column.separator()

        # row = column.row(align=True)
        # row.label(text='Circle:')
        # row = column.row(align=True)
        # row.prop(preference, 'circle_divisions', expand=True, text='Circle (E) Divisions')

        row = column.row(align=True)
        row.label(text=_z('CSharp:  '))
        row = column.row(align=True)

        column.separator()

        box = column.box()
        row = box.row(align=True)
        row.prop(preference, 'auto_bweight', text=_z('Jump to Bevel'))
        row.prop(preference, 'Hops_sharp_remove_cutters', text=_z('Remove Cutters'))

        #row = column.row(align=True)
        # row.label(text='Mirror:')

        # row = column.row(align=True)
        # row.prop(preference, 'Hops_mirror_modal_scale', text='Mirror Scale')
        # row.prop(preference, 'Hops_mirror_modal_sides_scale', text='Mirror Size')

        # row = column.row(align=True)
        # row.prop(preference, 'Hops_mirror_modal_Interface_scale', text='Mirror Interface Scale')
        # row.prop(preference, 'Hops_mirror_modal_revert', text='Revert')

        # row = column.row(align=True)
        # row.prop(preference, 'Hops_gizmo_mirror_u', text='mirror u')
        # row.prop(preference, 'Hops_gizmo_mirror_v', text='mirror v')

        # column.separator()
        #
        # row = column.row(align=True)
        # row.label(text='Array:')
        # row = column.row(align=True)
        # row.prop(preference, 'force_array_reset_on_init', expand=True, text='Array Reset on Init')
        #
        # row = column.row(align=True)
        # row.prop(preference, 'force_array_apply_scale_on_init', expand=True, text='Array Scale Apply on Init')
        #
        # column.separator()
        # column.separator()
        #
        # row = column.row(align=True)
        # row.label(text='Thick:')
        # row = column.row(align=True)
        # row.prop(preference, 'force_thick_reset_solidify_init', expand=True, text='Solidify Reset on Init')
        #
        # column.separator()
        #
        # row = column.row(align=True)
        # row.label(text='Modals:')
        # row = column.row(align=True)
        #
        # column.separator()
