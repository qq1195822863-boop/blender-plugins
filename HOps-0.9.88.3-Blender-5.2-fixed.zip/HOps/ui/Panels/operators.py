# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.types import Panel

from ... utility import addon


class HOPS_PT_operators(Panel):
    bl_label = _z('Operators')
    bl_description = 'Operators'
    bl_space_type = 'VIEW_3D'
    bl_category = _z('HOps')
    bl_region_type = 'UI'

    def draw(self, context):
        layout = self.layout
        preference = addon.preference().property

        column = layout.column(align=True)
