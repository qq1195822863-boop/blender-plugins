# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import *
from ... icons import get_icon_id


class HOPS_PT_OperationsPanel(bpy.types.Panel):
    bl_label = _z("Operations")
    bl_description = "Operations"
    # bl_category = "HardOps"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        active_object = context.active_object

        if active_object is None:
            layout.label(text=_z("Select object first"))
        elif active_object.mode == "OBJECT":

            layout = self.layout

            col = layout.column(align=True)

            col.separator()

            colrow = col.row(align=True)
            colrow.operator_context = 'INVOKE_DEFAULT'

            colrow.operator("hops.draw_uv", text=_z("UV Preview"), icon_value=get_icon_id("CUnwrap"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("hops.soft_sharpen", text=_z("(S) Sharpen"), icon_value=get_icon_id("Ssharpen"))
            colrow.operator("hops.soft_sharpen", text=_z("(C) Sharpen"), icon_value=get_icon_id("CSharpen"))

            colrow = col.row(align=True)
            colrow.operator("hops.step", text=_z("Step"), icon_value=get_icon_id("Sstep"))

            colrow = col.row(align=True)
            colrow.operator("hops.adjust_bevel", text=_z("(B) Width"), icon_value=get_icon_id("AdjustBevel"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("hops.slash", text=_z("(C) Slash"), icon_value=get_icon_id("Csplit"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("hops.cut_in", text=_z("Cut-in"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("hops.adjust_array", text=_z("(Q) Array"), icon_value=get_icon_id("Qarray"))
            colrow.operator("hops.adjust_tthick", text=_z("(T) Thick"), icon_value=get_icon_id("Tthick"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("clean.sharps", text=_z("Clear S/C/Sharps"), icon_value=get_icon_id("CleansharpsE"))
            colrow.operator("view3d.clean_mesh", text=_z("Clean Mesh (E)"), icon_value=get_icon_id("CleansharpsE"))

            colrow = col.row(align=True)
            colrow.operator("hops.2d_bevel", text=_z("Bevel (2d)"), icon_value=get_icon_id("AdjustBevel"))

            col.separator()
            colrow = col.row(align=True)
            colrow.operator("hops.parent_merge", text=_z("(C) merge"), icon_value=get_icon_id("Merge"))
            colrow.operator("hops.parent_merge_soft", text=_z("(C) merge(soft)"), icon_value=get_icon_id("CSharpen"))
            colrow = col.row(align=True)
            colrow.operator("hops.simple_parent_merge", text=_z("(S) merge"), icon_value=get_icon_id("Merge"))
            colrow.operator("hops.remove_merge", text=_z("Remove Merge"), icon_value=get_icon_id("Merge"))

            col.separator()
            colrow = col.row(align=True)
            colrow.operator("material.simplify", text=_z("Material Link"), icon_value=get_icon_id("Noicon"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("view3d.bevel_multiplier", text=_z("Bevel Multiplier"), icon_value=get_icon_id("Noicon"))

            col.separator()

            colrow = col.row(align=True)
            colrow.operator("hops.sharp_manager", text=_z("Sharps Manager"), icon_value=get_icon_id("Noicon"))

        elif active_object.mode == "EDIT":

            layout = self.layout
            col = layout.column(align=True)

            col.separator()

            colrow = col.row(align=True)
            colrow.operator_context = 'INVOKE_DEFAULT'
            colrow.operator("hops.set_edit_sharpen", text=_z("Set SSharp"), icon_value=get_icon_id("MakeSharpE"))
            colrow = col.row(align=True)
            colrow.operator("hops.bevel_weight", text=_z("Bweight"), icon_value=get_icon_id("AdjustBevel"))
            col.separator()
            colrow = col.row(align=True)
            colrow.operator("clean1.objects", text=_z("Clean SSharps"), icon_value=get_icon_id("CleansharpsE")).clearsharps = False
            col.separator()

            colrow = col.row(align=True)
            colrow.menu("HOPS_MT_edgeWizardSubmenu", text=_z("AUX"), icon="PLUGIN")
            colrow.operator("hops.meshdisp", text=_z("M_Disp"), icon="PLUGIN")

            col.separator()

            colrow.operator_context = 'INVOKE_DEFAULT'
            colrow = col.row(align=True)
            colrow.operator("hops.draw_uv", text=_z("UV Preview"), icon_value=get_icon_id("CUnwrap"))
            colrow = col.row(align=True)
            colrow.operator("view3d.vertcircle", text=_z("Circle (E)"), icon_value=get_icon_id("NthCircle"))
            colrow = col.row(align=True)
            colrow.operator("view3d.vertcircle", text=_z("Circle (Nth)(E)"), icon_value=get_icon_id("NthCircle")).nth_mode = True
            # colrow = col.row(align=True)
            # colrow.operator("hops.circle", text="NEW Circle", icon_value=get_icon_id("NthCircle"))

            col.separator()
            colrow = col.row(align=True)
            colrow.operator("fgrate.op", text=_z("Grate (Face)"), icon_value=get_icon_id("FaceGrate"))
            colrow = col.row(align=True)
            colrow.operator("fknurl.op", text=_z("Knurl (Face)"), icon_value=get_icon_id("FaceKnurl"))

            col.separator()
            colrow = col.row(align=True)
            colrow.operator("quick.panel", text=_z("Panel (Face)"), icon_value=get_icon_id("EdgeRingPanel"))
            colrow = col.row(align=True)
            colrow.operator("entrench.selection", text=_z("Panel (Edge)"), icon_value=get_icon_id("FacePanel"))
            colrow = col.row(align=True)
            colrow.operator("hops.star_connect", text=_z("Star Connect"))

            if any("mira_tools" in s for s in bpy.context.preferences.addons.keys()):
                col.separator()
                colrow = col.row(align=True)
                colrow.menu("HOPS_MT_MiraSubmenu", text=_z("Mira (T)"), icon="PLUGIN")
            else:
                col.separator()
            colrow = col.row(align=True)
            colrow.menu("HOPS_MT_SymmetrySubmenu", text=_z("Symmetrize"), icon_value=get_icon_id("Xslap"))
