# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import *
from bpy.types import (Panel,
                       Operator,
                       AddonPreferences,
                       PropertyGroup,
                       )
import os
from ... icons import get_icon_id
from ... utils.addons import addon_exists

class HOPS_PT_MeshToolsPanel(bpy.types.Panel):
    bl_label = _z("Meshtools")
    bl_description = "Meshtools"
    # bl_category = "HardOps"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        active_object = context.active_object

        if active_object is None:
            layout.label(text=_z("Select object first"))
        elif active_object.mode == "OBJECT":

            layout = self.layout.column(1)

            layout.operator("hops.reset_status", text=_z("StatusReset"))
            layout.operator("hops.helper", text=_z("Modifier Helper"), icon="SCRIPTPLUGINS")
            layout.separator()
            layout.operator("array.twist", text=_z("Twist 360"), icon_value=get_icon_id("ATwist360"))
            layout.operator("nw.radial_array", text=_z("Radial 360"), icon_value=get_icon_id("ATwist360"))
            layout.separator()
            if bpy.context.object and bpy.context.object.type == 'MESH':
                layout.menu("HOPS_MT_MaterialListMenu", icon_value=get_icon_id("Noicon"))
            layout.separator()
            layout.menu("HOPS_MT_ResetAxiSubmenu", text=_z("Reset Axis"), icon_value=get_icon_id("Xslap"))
            layout.separator()
            layout.menu("HOPS_MT_SymmetrySubmenu", text=_z("Symmetry Options"), icon_value=get_icon_id("Xslap"))
            layout.separator()
            layout.operator("hops.xunwrap", text=_z("(X) Unwrap"), icon_value=get_icon_id("CUnwrap"))
            layout.separator()
            layout.operator("clean.reorigin", text=_z("(S) Clean Recenter"), icon_value=get_icon_id("SCleanRecenter"))

            layout.operator("stomp2.object", text=_z("ApplyAll (-L)"), icon_value=get_icon_id("Applyall"))


        elif active_object.mode == "EDIT":
            layout = self.layout.column(1)

            layout.menu("HOPS_MT_edgeWizardSubmenu", text=_z("(E) Wizard"))

            layout.operator_context = 'INVOKE_DEFAULT'
            layout.operator("hops.draw_uv", text=_z("UV Preview"), icon_value=get_icon_id("CUnwrap"))

            layout.operator("view3d.vertcircle", text=_z("Circle(E)"), icon_value=get_icon_id("CircleSetup")).nth_mode = False

            layout.operator("view3d.vertcircle", text=_z("Circle (Nth)(E)"), icon_value=get_icon_id("NthCircle")).nth_mode = True

            layout.separator()

            layout.operator("fgrate.op", text=_z("Grate (Face)"), icon_value=get_icon_id("FaceGrate"))

            layout.operator("fknurl.op", text=_z("Knurl (Face)"), icon_value=get_icon_id("FaceKnurl"))

            layout.separator()

            layout.operator("quick.panel", text=_z("Panel (Face)"), icon_value=get_icon_id("EdgeRingPanel"))

            layout.operator("entrench.selection", text=_z("Panel (Edge)"), icon_value=get_icon_id("FacePanel"))

            if any("mira_tools" in s for s in bpy.context.preferences.addons.keys()):
                layout.separator()
                layout.menu("HOPS_MT_MiraSubmenu", text=_z("Mira (T)"), icon="PLUGIN")
            else:
                layout.separator()
