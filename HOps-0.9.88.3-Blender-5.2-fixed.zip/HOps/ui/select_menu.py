# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy

class HOPS_MT_SelectGrouped(bpy.types.Menu):
    bl_idname = "HOPS_MT_SelectGrouped"
    bl_label = _z("Select Grouped")
    bl_description = "Select Grouped"

    def draw(self, context):
        layout = self.layout
        layout.operator_enum("object.select_grouped", "type")
        layout.operator("hops.select_display_type", text=_z("Display Type"))
        layout.operator("hops.select_hops_status", text=_z("Hardops Status"))