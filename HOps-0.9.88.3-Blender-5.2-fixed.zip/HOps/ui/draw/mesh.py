# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from ... utility import addon


def draw(column, context):
    preference = addon.preference().property

    box = column.box()

    box.label(text=_z("Mesh Clean"))

    row = box.row(align=True)
    row.prop(preference, 'meshclean_mode', expand=True)

    row = box.row(align=True)
    row.prop(preference, 'meshclean_dissolve_angle', text=_z("Limited Dissolve Angle"))
    row.prop(preference, 'meshclean_remove_threshold', text=_z("Remove Threshold"))

    row = box.row(align=True)
    row.prop(preference, 'meshclean_unhide_behavior', text=_z("Unhide Mesh"))
    row.prop(preference, 'meshclean_delete_interior', text=_z("Delete Interior Faces"))

    box.separator()

    box = column.box()
    
    box.label(text=_z('Dice'))

    row = box.row(align=True)
    row.label(text=_z('Solver / Pre-Apply '))
    row.prop(preference, 'dice_method', text='')
    row.prop(preference, 'smart_apply_dice', text='')
    
    row = box.row(align=True)
    row.label(text=_z('Display '))
    row.prop(preference, 'dice_wire_type', text='')
    row.prop(preference, 'dice_show_mesh_wire', text=_z('Wire Fade'))
