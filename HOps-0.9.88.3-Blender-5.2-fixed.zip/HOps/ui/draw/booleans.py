# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from ... utility import addon


def draw(column, context):

    preference = addon.preference().property
    #self.layout.row().prop(preference, 'boolean_solver', expand=True)
    row = column.row(align=True)
    row.label(text = _z("Behavior"))

    box = column.box()
    row = box.row(align=True)
    row.prop(preference, 'bool_bstep', text=_z('Bevel Step'))
    row.prop(preference, 'parent_boolshapes', text=_z('Parent Boolshapes'))

    row = column.row(align=True)
    row.label(text = _z("Auto Cutter Removal"))

    box = column.box()
    row = box.row(align=True)
    row.prop(preference, 'Hops_sharp_remove_cutters', text=_z('Csharp'))
    row.prop(preference, 'Hops_smartapply_remove_cutters', text=_z('Smart Apply'))
    
    row = column.row(align=True)
    row.label(text=_z('Cut In:'))
    
    box = column.box()
    row = box.row(align=True)
    row.prop(preference, 'keep_cutin_bevel', expand=True, text=_z('Keep Bevel'))
    #label_row(preference.property, 'Hops_sharp_remove_cutters', layout.row(), label='Hops_sharp_remove_cutters')
