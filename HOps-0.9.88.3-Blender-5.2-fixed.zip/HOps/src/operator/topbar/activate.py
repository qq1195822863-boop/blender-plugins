# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import Operator

from .... utility import active_tool, activate_by_name


class Hardflow_OT_topbar_activate(Operator):
    bl_idname = 'hardflow.topbar_activate'
    bl_label = _z('Activate Hardflow')
    bl_description = 'Activate Hardflow'

    def execute(self, context):

        if active_tool().idname != 'Hops':
            activate_by_name('Hops')
            self.report({'INFO'}, _z('Activated Hardops'))

            return {'FINISHED'}

        else:
            return {'PASS_THROUGH'}
