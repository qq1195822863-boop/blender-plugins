# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy, bpy_extras, pathlib
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper, ExportHelper
from pathlib import Path
from bpy.props import StringProperty, BoolProperty
from ....utility.addon import preference
from ....utils.profile import save_bevel_profile, load_bevel_profile


class SaveBevelProfile(Operator, ExportHelper):
    bl_idname = 'hops.save_bevel_profile'
    bl_label = _z('Save Bevel Profile')
    bl_options = {'REGISTER', 'INTERNAL'}
    bl_description = "Save Bevel Profile\nSave custom bevel profile to a json file"


    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    filename_ext: bpy.props.StringProperty(default='.json', options={'HIDDEN'})
    obj: StringProperty(name=_z('Object Name'), options={'HIDDEN'}, description = 'Object Name')
    mod: StringProperty(name=_z('Modifier Name'), options={'HIDDEN'}, description = 'Modifier Name')


    def invoke(self, context, event):
        folder = Path(preference().property.profile_folder).resolve()

        try:
            folder.mkdir(parents=True, exist_ok=True)
        except:
            print(f'Unable to create {folder}')

        self.filepath = str(folder.joinpath('bevel.json'))
        return super().invoke(context, event)


    def execute(self, context):
        obj = bpy.data.objects[self.obj]
        mod = obj.modifiers[self.mod]
        result = save_bevel_profile(mod, self.filepath)
        self.report(result[0], result[1])
        return result[2]


class LoadBevelProfile(Operator, ImportHelper):
    bl_idname = 'hops.load_bevel_profile'
    bl_label = _z('Load Bevel Profile')
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    bl_description = "Load Bevel Profile\nLMB - Load custom bevel profile from a json file"


    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    obj: StringProperty(name=_z('Object Name'), options={'HIDDEN'}, description = 'Object Name')
    mod: StringProperty(name=_z('Modifier Name'), options={'HIDDEN'}, description = 'Modifier Name')
    sync_segments: BoolProperty(name=_z('Sync Segments'), description = "Sync Segments\nSet segment count to number of profile points")


    def invoke(self, context, event):
        folder = Path(preference().property.profile_folder).resolve()

        try:
            folder.mkdir(parents=True, exist_ok=True)
        except:
            print(f'Unable to create {folder}')

        self.filepath = str(folder.joinpath('bevel.json'))
        return super().invoke(context, event)


    def execute(self, context):
        obj = bpy.data.objects[self.obj]
        mod = obj.modifiers[self.mod]
        result = load_bevel_profile(mod, self.filepath, self.sync_segments)
        self.report(result[0], result[1])
        return result[2]
