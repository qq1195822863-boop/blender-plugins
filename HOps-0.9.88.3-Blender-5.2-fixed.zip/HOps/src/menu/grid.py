# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z


import bpy

#Insert Object
class HOPS_MT_Tool_grid(bpy.types.Menu):
    bl_idname = "HOPS_MT_Tool_grid"
    bl_label = _z('''Grid Objects
    
    Shift + LMB - Grid (intersect)

    ''')
    bl_description = '''Grid Objects
    
    Shift + LMB - Grid (intersect)

    '''

    def draw(self, context):
        layout = self.layout

        layout.operator("hops.add_grid_square", text=_z("Square"), icon="MESH_GRID")
        layout.operator("hops.add_grid_diamond", text=_z("Diamond"), icon='MESH_GRID')
        layout.operator("hops.add_grid_honey", text=_z("Honeycomb"), icon='MESH_GRID')
        layout.operator("hops.add_grid_circle", text=_z("Circle"), icon='MESH_GRID')
