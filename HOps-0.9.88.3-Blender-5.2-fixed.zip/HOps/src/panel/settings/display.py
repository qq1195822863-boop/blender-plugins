# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import Panel

from ... utilityremove import names
from .... utility import addon


class HARDFLOW_PT_display_settings(Panel):
    bl_label = _z('Display')
    bl_description = 'Display'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _z('Hardflow')
    bl_parent_id = 'HOPS_PT_settings'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.region.type == 'UI'

    def draw(self, context):
        layout = self.layout

        preference = addon.preference()

        self.label_row(layout.row(), preference.display, 'dot_size', label=_z('Dot Size'))
        self.label_row(layout.row(), preference.display, 'dot_detect', label=_z('Detect Size'))
        self.label_row(layout.row(), preference.display, 'dot_side_offset', label=_z('Dot Offset'))
        self.label_row(layout.row(), preference.display, 'dot_corner_offset', label=_z('Corner Offset'))
        self.label_row(layout.row(), preference.property, 'dots_snap', label=_z('Display'))
        layout.separator()
        self.label_row(layout.row(), preference.display, 'dot_boolshape_fade_distance', label=_z('Fade Distance'))
        layout.separator()
        self.label_row(layout.row(), preference.display, 'display_smartshape', label=_z('Display Smartshape Row'))
        self.label_row(layout.row(), preference.display, 'display_modifiers', label=_z('Display Modifiers Row'))
        self.label_row(layout.row(), preference.display, 'display_misc', label=_z('Display Misc Row'))
        layout.separator()
        self.label_row(layout.row(), preference.color, 'Bool_Dots_Text', label=_z('Display Text for Boolean Dots'))
        self.label_row(layout.row(), preference.display, 'display_text', label=_z('Display Text in Viewport'))
        self.label_row(layout.row(), preference.display, 'display_text_size', label=_z('Display Text Size'))
        self.label_row(layout.row(), preference.display, 'display_text_size_for_dots', label=_z('Display Dots Text Size'))
        layout.separator()
        self.label_row(layout.row(), preference.display, 'use_label_factor', label=_z('Fix Label Size'))

        # self.label_row(layout.row(), preference.display, 'display_corner', label='Dot Display Corner')

    def label_row(self, row, path, prop, label=''):
        row.label(text=label if label else names[prop])
        row.prop(path, prop, text='')
