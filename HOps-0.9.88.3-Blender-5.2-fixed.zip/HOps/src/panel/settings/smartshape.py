# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import Panel

from ... utilityremove import names
from .... utility import active_tool


class HARDFLOW_PT_display_smartshapes(Panel):
    bl_label = _z('Smartshape')
    bl_description = 'Smartshape'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _z('Hops')

    @classmethod
    def poll(cls, context):
        return active_tool().idname == 'Hops'

    def draw(self, context):
        layout = self.layout


        layout.operator('hops.add_vertex', text=_z('Vertex'), icon='DOT')
        layout.operator('hops.add_plane', text=_z('Plane'), icon='MESH_PLANE')
        layout.operator('hops.add_box', text=_z('Cube'), icon='MESH_CUBE')
        layout.operator('hops.add_bbox', text=_z('Box'), icon='META_CUBE')
        layout.menu('HOPS_MT_Tool_grid', text=_z('Grid'), icon='MESH_GRID')
        layout.operator('hops.add_circle', text=_z('Circle'), icon='MESH_CIRCLE')
        layout.operator('hops.add_sphere', text=_z('Sphere'), icon='MESH_UVSPHERE')
        layout.operator('hops.add_cylinder', text=_z('Cylinder'), icon='MESH_CYLINDER')
        layout.operator('hops.add_cone', text=_z('Cone'), icon='MESH_CONE')
        layout.operator('hops.add_ring', text=_z('Ring'), icon='MESH_TORUS')
        layout.operator('hops.add_screw', text=_z('Screw'), icon='MOD_SCREW')

        # self.label_row(layout.row(), preference.display, 'display_corner', label='Dot Display Corner')

    def label_row(self, row, path, prop, label=''):
        row.label(text=label if label else names[prop])
        row.prop(path, prop, text='')
