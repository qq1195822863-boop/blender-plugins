# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import Panel

from ... tools.hopstool import modifier_operators
from .... utility import active_tool
from .... icons import get_icon_id

class HARDFLOW_PT_display_modifiers(Panel):
    bl_label = _z('Modifiers')
    bl_description = 'Modifiers'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _z('Hops')

    @classmethod
    def poll(cls, context):
        return active_tool().idname == 'Hops'

    def draw(self, context):
        layout = self.layout

        modifier_operators(context, layout, labels=True)
