# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z
import traceback

import bpy

from bl_ui.space_toolsystem_common import activate_by_id as activate_tool
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active as view3d_tools


name = __name__.partition('.')[0]

# TODO: create collections for these in preferences
vertice_presets = [3, 6, 8, 32, 64]
array_presets = [2, 4, 6, 8, 10]
width_presets = [0.02, 0.05, 0.1]
segment_presets = [1, 2, 3, 4, 6]
angle_presets = [5, 15, 30, 45, 90]

names = {
    'cut': _z('Cut'),
    'slice': _z('Slice'),
    'inset': _z('Inset'),
    'join': _z('Join'),
    'make': _z('Make'),
    'knife': _z('Knife'),
    'snap': _z('Snap'),
    'negative': _z('Negative'),
    'bbox': _z('Bbox'),
    'dot': _z('Dot'),
    'dot_highlight': _z('Highlight'),
    'wire': _z('Wire'),
    'show_shape_wire': _z('Show Shape Wire'),
    'wire_width': _z('Wire Width'),
    'bounds': _z('Show Bounds'),
    'allow_selection': _z('Allow Selection'),
    'sort_modifiers': _z('Sort Modifiers'),
    'keep_modifiers': _z('Keep Modifiers'),
    'ngon_snap_angle': _z('Ngon Snap Angle'),
    'auto_smooth': _z('Auto Smooth'),
    'join_flip_z': _z('Join Flip Z'),
    'use_multi_edit': _z('Use Mult-Edit'),
    'make_active': _z('Shift to Active'),
    'show_shape': _z('Show Shape'),
    'parent_shape': _z('Parent Shape'),
    'apply_slices': _z('Apply Slices'),
    'make_align_z': _z('Make on Z'),
    'offset': _z('Offset'),
    'destructive_menu': _z('Destructive Menu'),
    'mode_label': _z('Mode Label'),
    'shape_label': _z('Shape Label'),
    'operation_label': _z('Operation Label'),
    'surface_label': _z('Surface Label'),
    'wire_only': _z('Wires Only'),
    'thick_wire': _z('Thick Wire'),
    'circle_vertices': _z('Circle Vertices'),
    'bevel_width': _z('Bevel Width'),
    'bevel_segments': _z('Bevel Segments'),
    'quad_bevel': _z('Quad Bevel'),
    'straight_edges': _z('Straight Corner Flow'),
    'inset_thickness': _z('Inset Thickness'),
    'solidify_thickness': _z('Solidify Thickness'),
    'array_count': _z('Array Count'),
    'lazorcut_limit': _z('Lazorcut Limit'),
    'quick_execute': _z('Quick Execute'),
    'simple_trace': _z('Simple Trace'),
    'edit_disable_modifiers': _z('Disable Ctrl & Shift LMB (Edit Mode)'),
    'enable_surface_toggle': _z('Enable Surface Toggle'),
    'cursor': _z('Cursor'),
    'transform_gizmo': _z('Transform Gizmo'),
    'reduce_opacity_editmode': _z('Reduce Opacity in Edit'),
    'scroll_adjust_circle': _z('Scroll Adjust Circle'),
    'cursor_axis': _z('Cursor Axis')}


def method_handler(method,
    arguments = tuple(),
    identifier = str(),
    exit_method = None,
    exit_arguments= tuple(),
    return_result = False,
    return_value = {'CANCELLED'}):
    '''
    method: method to call
    arguments: method arguments
    identifier: optional identifer for printout
    exit_method: optional exit method to call on exception
    exit_arguments: exit method arguments
    return_result: allows return of the method and values
    return_value: return value on exception
    '''
    identifier = identifier + ' ' if identifier else ''
    try:
        if return_result:
            return method(*arguments)
        else:
            method(*arguments)
    except Exception:
        print(F'\n{name} {identifier}Method Failed:\n')
        traceback.print_exc()

        if exit_method:
            try:
                if return_result:
                    return exit_method(*exit_arguments)
                else:
                    exit_method(*exit_arguments)
            except Exception:
                print(F'\n{name} {identifier}Exit Method Failed:\n')
                traceback.print_exc()

        if return_result:
            try: return return_value
            except Exception:
                print(F'\n{name} {identifier}Exit Return Value Failed:\n')
                traceback.print_exc()
