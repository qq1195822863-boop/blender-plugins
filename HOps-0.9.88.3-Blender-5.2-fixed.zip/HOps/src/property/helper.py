# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

from bpy.types import PropertyGroup
from bpy.props import BoolProperty


class option(PropertyGroup):
    general: BoolProperty(name=_z("General"), description="General\nExpand or collapse panel", default = False)
    workflow: BoolProperty(name=_z("Workflow"), description="Workflow\nExpand or collapse panel", default = False)
    sharp: BoolProperty(name=_z("Sharp"), description="Sharp\nExpand or collapse panel", default = False)
    mesh: BoolProperty(name=_z("Mesh"), description="Mesh\nExpand or collapse panel", default = False)
    bevel: BoolProperty(name=_z("Bevel"), description="Bevel\nExpand or collapse panel", default = False)
    booleans: BoolProperty(name=_z("Boolean"), description="Boolean\nExpand or collapse panel", default = False)
    opt_ins: BoolProperty(name=_z("Optimize It"), description="Optimize It\nExpand or collapse panel", default = False)
