# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, EnumProperty, FloatProperty


def active_obj_mirror_mods(scene, context):

    modifiers = []
    obj = context.active_object
    if obj:
        if len(context.selected_objects) == 2:
            others = [obj for obj in context.selected_objects if obj != context.active_object]
            obj = others[0]

        if obj.type == "GPENCIL":
            mods = [mod for mod in obj.grease_pencil_modifiers if mod.type == "GP_MIRROR"]
        else:
            mods = [mod for mod in obj.modifiers if mod.type == "MIRROR"]

        for mod in mods:
            modifiers.append((f"{mod.name}", f"{mod.name}", ""))
        if len(mods) == 0:
            modifiers.append(("new", "New", ""))
    else:
        modifiers.append(("new", "New", ""))
    return modifiers


class props(PropertyGroup):

    running: BoolProperty(
        name=_z('Mirror is Running'),
        description="Mirror is Running\nMirror modal operation is running",
        default=False)

    advanced: BoolProperty(
        name=_z('Mirror Advanced options'),
        description=_z('''Advanced / Simple Toggle

        Mirror Advanced options display

        Shortcut: Tab 
        '''),
        default=False)

    modifier: EnumProperty(
        name=_z("Mirror Modifiers"),
        description="Mirror Modifiers\nMirror modifier to be affected",
        items=active_obj_mirror_mods)

    mode: EnumProperty(
        name=_z("Mirror Mode"),
        description="Mirror Mode\nMirror mode",
        items=[("MODIFIER", _z("Modifier"), "Modifier\nModify last mirror modifier options"),
               ("NEWMODIFIER", _z("New Modifier"), "New Modifier\nCreate new mirror modifier"),
               ("MODIFIERAPPLY", _z("Modifier&Apply"), "Modifier&Apply\nApply mirror modifier (symmetrize)"),
               ("BISECTMOD", _z("Bisect&Modifier"), "Bisect&Modifier\nBisect the mesh and add mirror modifier"),
               ("BISECT", _z("Bisect"), "Bisect\nBisect the mesh"),
               ("SYMMETRY", _z("Symmetry"), "Symmetry\nUse symetrize operator"),
               ("FLIP", _z("Flip"), "Flip\nFlip the mesh to another side")],
        default='MODIFIER')

    orientation: EnumProperty(
        name=_z("Mirror Orientation"),
        description="Mirror Orientation\nMirror selected objects using orientation",
        items=[("LOCAL", _z("Local"), "Local\nLocal Orientation", "ORIENTATION_LOCAL", 1),
               ("GLOBAL", _z("Global"), "Global\nGlobal Orientation", "ORIENTATION_GLOBAL", 2),
               ("VIEW", _z("View"), "View\nView Orientation", "ORIENTATION_VIEW", 3),
               ("CURSOR", _z("Cursor"), "Cursor\nCursor Orientation", "ORIENTATION_CURSOR", 4)],
        default='LOCAL')

    pivot: EnumProperty(
        name=_z("Mirror Pivot Point"),
        description="Mirror Pivot Point\nMirror selected objects across pivot point",
        items=[("ACTIVE", _z("Active Origin"), "Active Origin", "PIVOT_ACTIVE", 1),
               ("MEDIAN", _z("Median Point"), "Median Point", "PIVOT_MEDIAN", 2),
               ("CURSOR", _z("Cursor"), "Cursor", "PIVOT_CURSOR", 3),
               ("INDIVIDUAL", _z("Individual Origins"), "Individual Origins", "PIVOT_INDIVIDUAL", 4)],
        default='ACTIVE')

    include_active: BoolProperty(
        name=_z('Include Active'),
        description="Include Active\nInclude Active Object in Group Mirroring",
        default=False)

    close: BoolProperty(
        name=_z('Close After Operation'),
        description="Close After Operation\nClose when first mirror operation is done using gizmo",
        default=True)

    parent_empty: BoolProperty(
        name=_z('Parent Empty'),
        description="Parent Empty\nParent empty to active object",
        default=False)

    revert: BoolProperty(
        name=_z('Revert Gizmo Handlers'),
        description="Revert Gizmo Handlers\nReverting gizmo manipulator handlers",
        default=False)

    symmetrize_selected: BoolProperty(
        name=_z('Symmetrize only selected mesh'),
        description="Symmetrize only selected mesh\nOlny selected mesh in edit mode will be symmetrize",
        default=False)

    mirror_u: BoolProperty(
        name=_z('Modifier mirror_u property'),
        description="Modifier mirror_u property\nSet mirror_u on modifier",
        default=False)

    mirror_v: BoolProperty(
        name=_z('Modifier mirror_v property'),
        description="Modifier mirror_v property\nSet mirror_v on modifier",
        default=False)

    scale: FloatProperty(
        name=_z('Gizmo Scale'),
        description="Gizmo Scale\nScale of mirros gizmo",
        default= 1.8)

    width: FloatProperty(
        name=_z('Gizmo width'),
        description="Gizmo width\nWidth of morros gizmo lines",
        default= 0.5)
