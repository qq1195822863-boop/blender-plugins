# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from mathutils import Vector

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, FloatVectorProperty, FloatProperty, EnumProperty

from ... utilityremove import names
from .... utility import addon

class hops(PropertyGroup):

    colection_color: EnumProperty(
        name = _z('Collection Color'),
        description = "Collection Color\nSet Cutters Collection Color",
        items = [
            ('NONE',_z('None'),"None", '', 0),
            ('COLOR_01',_z('Red'),"Red", 'COLLECTION_COLOR_01', 1),
            ('COLOR_02',_z('Orange'),"Orange", 'COLLECTION_COLOR_02', 2),
            ('COLOR_03',_z('Yellow'),"Yellow", 'COLLECTION_COLOR_03', 3),
            ('COLOR_04',_z('Green'),"Green", 'COLLECTION_COLOR_04', 4),
            ('COLOR_05',_z('Blue'),"Blue", 'COLLECTION_COLOR_05', 5),
            ('COLOR_06',_z('Violet'),"Violet", 'COLLECTION_COLOR_06', 6),
            ('COLOR_07',_z('Pink'),"Pink", 'COLLECTION_COLOR_07', 7),
            ('COLOR_08',_z('Brown'),"Brown", 'COLLECTION_COLOR_08', 8)],
        default = 'COLOR_01')

    wire: FloatVectorProperty(
        name = names['wire'],
        description = 'Color of the shape\'s wire',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.0, 0.0, 0.0, 0.33))

    show_shape_wire: FloatVectorProperty(
        name = names['show_shape_wire'],
        description = 'Color of the shape\'s wire when the object is to be shown',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.23, 0.7, 0.15, 0.33))

    dot2: FloatVectorProperty(
        name = _z('Dot 2'),
        description = "Dot 2\nColor of Dot 2",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.35, 1, 0.29, 0.9))

    dot3: FloatVectorProperty(
        name = _z('Dot 3'),
        description = "Dot 3\nColor of Dot 3",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.133, 0.133, 0.9))

    dot4: FloatVectorProperty(
        name = _z('Dot 4'),
        description = "Dot 4\nColor of Dot 4",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.9, 0.03, 0.9))

    dot5: FloatVectorProperty(
        name = _z('Dot 5'),
        description = "Dot 5\nColor of Dot 5",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.32, 0.67, 1, 0.9))

    dot6: FloatVectorProperty(
        name = _z('Dot 5'),
        description = "Dot 5\nColor of Dot 6",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.88, 0.19, 1, 0.9))

    dot7: FloatVectorProperty(
        name = _z('Dot 5'),
        description = "Dot 5\nColor of Dot 7",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.57, 0.176, 0.9))

    displace_x: FloatVectorProperty(
        name = _z('displace_x'),
        description = "displace_x\nColor of displace_x",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.2, 0.322, 0.9))

    displace_y: FloatVectorProperty(
        name = _z('displace_y'),
        description = "displace_y\nColor of displace_y",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.54, 0.83, 0, 0.9))

    displace_z: FloatVectorProperty(
        name = _z('displace_z'),
        description = "displace_z\nColor of displace_z",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.157, 0.565, 1, 0.9))

    screw_x: FloatVectorProperty(
        name = _z('screw_x'),
        description = "screw_x\nColor of screw_x",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    screw_y: FloatVectorProperty(
        name = _z('screw_y'),
        description = "screw_y\nColor of screw_y",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    screw_z: FloatVectorProperty(
        name = _z('screw_z'),
        description = "screw_z\nColor of screw_z",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    solidify_x: FloatVectorProperty(
        name = _z('solidify_x'),
        description = "solidify_x\nColor of solidify_x",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    solidify_y: FloatVectorProperty(
        name = _z('solidify_y'),
        description = "solidify_y\nColor of solidify_y",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    solidify_z: FloatVectorProperty(
        name = _z('solidify_z'),
        description = "solidify_z\nColor of solidify_z",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    solidify_c: FloatVectorProperty(
        name = _z('solidify_c'),
        description = "solidify_c\nColor of solidify_c",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.157, 0.565, 1, 0.9))

    array_x: FloatVectorProperty(
        name = _z('array_x'),
        description = "array_x\nColor of array_x",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.875, 0.832, 0, 0.9))

    array_y: FloatVectorProperty(
        name = _z('array_y'),
        description = "array_y\nColor of array_y",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.875, 0.832, 0, 0.9))

    array_z: FloatVectorProperty(
        name = _z('array_z'),
        description = "array_z\nColor of array_z",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.875, 0.832, 0, 0.9))

    simple_deform_x: FloatVectorProperty(
        name = _z('simple_deform_x'),
        description = "simple_deform_x\nColor of simple_deform_x",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.939, 0.236, 1, 0.9))

    simple_deform_y: FloatVectorProperty(
        name = _z('simple_deform_y'),
        description = "simple_deform_y\nColor of simple_deform_y",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.939, 0.236, 1, 0.9))

    simple_deform_z: FloatVectorProperty(
        name = _z('simple_deform_z'),
        description = "simple_deform_z\nColor of simple_deform_z",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.939, 0.236, 1, 0.9))

    wireframe_c: FloatVectorProperty(
        name = _z('wireframe_c'),
        description = "wireframe_c\nColor of wireframe_c",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.939, 0.236, 1, 0.9))

    bevel_c: FloatVectorProperty(
        name = _z('bevel_c'),
        description = "bevel_c\nColor of bevel_c",
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    dot: FloatVectorProperty(
        name = names['dot'],
        description = 'Color of snapping points',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    dot_highlight: FloatVectorProperty(
        name = names['dot_highlight'],
        description = 'Color of snapping points highlighted',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.597, 0.133, 0.9))

    enable_tool_overlays: BoolProperty(
        name=_z('Enable tool overlays'),
        description='Enable tool overlays',
        default=True)

    Hops_text_color: FloatVectorProperty(
        name="",
        default=Vector((0.6, 0.6, 0.6, 0.9)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_text2_color: FloatVectorProperty(
        name="",
        default=Vector((0.6, 0.6, 0.6, 0.9)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_border_color: FloatVectorProperty(
        name="",
        default=Vector((0.235, 0.235, 0.235, 0.8)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_border2_color: FloatVectorProperty(
        name="",
        default=Vector((0.692, 0.298, 0.137, 0.718)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_logo_color: FloatVectorProperty(
        name="",
        default=(0.448, 0.448, 0.448, 0.1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_logo_color_csharp: FloatVectorProperty(
        name="",
        default=(1, 0.597, 0.133, 0.9),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_logo_color_cstep: FloatVectorProperty(
        name="",
        default=(0.29, 0.52, 1.0, 0.9),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_logo_color_boolshape2: FloatVectorProperty(
        name="",
        default=(1, 0.133, 0.133, 0.53),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_logo_color_boolshape: FloatVectorProperty(
        name="",
        default=(0.35, 1, 0.29, 0.53),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_hud_color: FloatVectorProperty(
        name="",
        default=(0.17, 0.17, 0.17, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_hud_text_color: FloatVectorProperty(
        name="",
        default=(0.831, 0.831, 0.831, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_hud_help_color: FloatVectorProperty(
        name="",
        default=(0.250, 0.750, 1, 0.7),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_display_logo: BoolProperty(name=_z("Display Logo"), default=False, description = "Display Logo")

    Bool_Dots_Text: BoolProperty(name=_z("Display Dots Text"), default=True, description = "Display Dots Text")

    Hops_logo_size: FloatProperty(
        name=_z("HardOps Indicator Size"),
        description="HardOps Indicator Size\nBoxCutter indicator size",
        default=2, min=0, max=100)

    Hops_logo_x_position: FloatProperty(
        name=_z("HardOps Indicator X Position"),
        description="HardOps Indicator X Position\nBoxCutter Indicator X Position",
        default=-203)

    Hops_logo_y_position: FloatProperty(
        name=_z("HardOps Indicator Y Position"),
        description="HardOps Indicator Y Position\nBoxCutter Indicator Y Position",
        default=19)

    Hops_mirror_modal_scale: FloatProperty(
        name=_z("Modal Mirror Operators Scale"),
        description="Modal Mirror Operators Scale",
        default=5, min=0.1, max=100)

    Hops_mirror_modal_sides_scale: FloatProperty(
        name=_z("Modal Mirror Operators Sides Scale"),
        description="Modal Mirror Operators Sides Scale",
        default=0.20, min=0.01, max=0.99)

    expand: BoolProperty(name=_z("expand color options"), default=False, description = "expand color options")
    hud_expand: BoolProperty(name=_z("Hud color options"), default=False, description = "Hud color options")
    col_expand: BoolProperty(name=_z("Collection color options"), default=False, description = "Collection color options")

    #UI SYSTEM
    Hops_UI_text_color: FloatVectorProperty(
        name="",
        default=(1, 1, 1, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_secondary_text_color: FloatVectorProperty(
        name="",
        default=(1, 1, 1, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_mods_highlight_color: FloatVectorProperty(
        name="",
        default=(.879, .669, .229, 1), #RGB
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_highlight_color: FloatVectorProperty(
        name="",
        default=(0, 0, 1, .025),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_highlight_drag_color: FloatVectorProperty(
        name="",
        default=(1, 0, 0, .25),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_background_color: FloatVectorProperty(
        name="",
        default=(.75, .75, .75, 0),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_cell_background_color: FloatVectorProperty(
        name="",
        default=(.411, .411, .411, .35),
        size=4,
        min=0, max=1,
        subtype='COLOR',
        description = "Background color for modals")

    tips_background: FloatVectorProperty(
        name="",
        default=(.411, .411, .411),
        size=3,
        min=0, max=1,
        subtype='COLOR',
        description = "Background color for Dot UI Tips")

    Hops_UI_dropshadow_color: FloatVectorProperty(
        name="",
        default=(0, 0, 0, .15),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_border_color: FloatVectorProperty(
        name="",
        default=(0.2, 0.2, 0.2, .7),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_mouse_over_color: FloatVectorProperty(
        name="",
        default=(0, 0, .25, .5),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_text_highlight_color: FloatVectorProperty(
        name="",
        default=(1, 1, 0, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_UI_uv_color: FloatVectorProperty(
        name="",
        default=(.25, .25, .25, .875),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    # Hops extra drawing
    Hops_wire_mesh: FloatVectorProperty(
        name="",
        default=(1, .5, 0, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    poly_debug_alpha: FloatProperty(
        name=_z("Poly Debug Alpha"),
        default=0.20, min=0.001, max=1, description = "Poly Debug Alpha")

    # --- OPERATIONMS --- #
    grid_system_color: FloatVectorProperty(
        name="",
        default=(1, 1, 1, .5),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    # Form UI : PRIVATE DATA
    form_color_prop_1: FloatVectorProperty(
        name=_z("form_color_prop_1"),
        size = 4, min = 0, max = 1,
        subtype='COLOR',
        default = (0, 0, 0, 1), description = "form_color_prop_1")

    form_color_prop_2: FloatVectorProperty(
        name=_z("form_color_prop_2"),
        size = 4, min = 0, max = 1,
        subtype='COLOR',
        default = (0, 0, 0, 1), description = "form_color_prop_2")

    form_color_prop_2: FloatVectorProperty(
        name=_z("form_color_prop_3"),
        size = 4, min = 0, max = 1,
        subtype='COLOR',
        default = (0, 0, 0, 1), description = "form_color_prop_3")


def header_row(row, prop, label='', emboss=False):
    preference = addon.preference()
    icon = 'DISCLOSURE_TRI_RIGHT' if not getattr(preference.color, prop) else 'DISCLOSURE_TRI_DOWN'
    row.alignment = 'LEFT'
    row.prop(preference.color, prop, text='', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.25
    sub.prop(preference.color, prop, text='', icon=icon, emboss=emboss)
    row.prop(preference.color, prop, text=F'{label}', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.75
    sub.prop(preference.color, prop, text=' ', icon='BLANK1', emboss=emboss)


def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):

    # --- Collection --- #
    box = layout.box()
    header_row(box.row(align=True), 'col_expand', label=_z('Collection Display'))
    box.separator()
    if preference.color.col_expand:
        label_row(preference.color, 'colection_color', box.row(), label=_z('Collection Color'))


    # --- HUD --- #
    box = layout.box()
    header_row(box.row(align=True), 'hud_expand', label=_z('HUD Display'))
    box.separator()
    if preference.color.hud_expand:

        # Logo
        main_split = box.split()
        split = main_split.box()
        sub_box = split.box()
        sub_box.label(text=_z("Logo"))
        sub_box = sub_box.box()
        label_row(preference.color, 'Hops_display_logo', sub_box.row(), label=_z('Show Logo'))
        label_row(preference.color, 'Hops_logo_color', sub_box.row(), label=_z('Color'))
        label_row(preference.color, 'Hops_logo_color_boolshape', sub_box.row(), label=_z('Boolshape'))
        label_row(preference.color, 'Hops_logo_size', sub_box.row(), label=_z('Size'))
        label_row(preference.color, 'Hops_logo_x_position', sub_box.row(), label=_z('Logo X'))
        label_row(preference.color, 'Hops_logo_y_position', sub_box.row(), label=_z('Logo Y'))

        # Gizmo
        sub_box = split.box()
        sub_box.label(text=_z("Gizmo"))
        sub_box = sub_box.box()
        label_row(preference.operator.mirror, 'scale', sub_box.row(), label=_z('Mirror Scale'))
        label_row(preference.operator.mirror, 'width', sub_box.row(), label=_z('Mirror Width'))

        # Logo
        sub_box = split.box()
        sub_box.label(text=_z("Active tool"))
        sub_box = sub_box.box()
        label_row(preference.color, 'wire', sub_box.row())
        label_row(preference.color, 'show_shape_wire', sub_box.row())

        # --- UI System --- #
        # split = main_split.split()
        sub_box = split.box()
        sub_box.label(text=_z("UI System"))
        sub_box = sub_box.box()
        label_row(preference.color, 'Hops_UI_cell_background_color', sub_box.row(), label=_z('Cell BG'))
        label_row(preference.color, 'tips_background', sub_box.row(), label=_z('Tips Background'))
        label_row(preference.color, 'Hops_UI_text_color', sub_box.row(), label=_z('Main Text'))
        label_row(preference.color, 'Hops_UI_secondary_text_color', sub_box.row(), label=_z('Secoundary Text'))
        label_row(preference.color, 'Hops_UI_mods_highlight_color', sub_box.row(), label=_z('Text Highlight'))
        label_row(preference.color, 'Hops_UI_background_color', sub_box.row(), label=_z('Background'))
        label_row(preference.color, 'Hops_UI_highlight_color', sub_box.row(), label=_z('Highlight'))
        label_row(preference.color, 'Hops_UI_dropshadow_color', sub_box.row(), label=_z('Drop Shadow'))
        label_row(preference.color, 'Hops_UI_border_color', sub_box.row(), label=_z('Border'))
        label_row(preference.color, 'Hops_UI_mouse_over_color', sub_box.row(), label=_z('Hover'))
        label_row(preference.color, 'Hops_UI_highlight_drag_color', sub_box.row(), label=_z('Drag'))
        label_row(preference.color, 'Hops_UI_uv_color', sub_box.row(), label=_z('UV'))
        label_row(preference.color, 'Hops_wire_mesh', sub_box.row(), label=_z('Mesh Wire'))
        label_row(preference.color, 'poly_debug_alpha', sub_box.row(), label=_z('Poly Debug Alpha'))

        # --- UI System --- #
        main_split = box.split()
        sub_box = main_split.box()
        sub_box.label(text=_z("Operations"))
        sub_box = sub_box.box()
        label_row(preference.color, 'grid_system_color', sub_box.row(), label=_z('Grids'))

    # --- DOTS --- #
    box = layout.box()
    header_row(box.row(align=True), 'expand', label=_z('Dots Display'))
    box.separator()
    if preference.color.expand:

        # Booleandots
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Booleandots"))
        sub_box = sub_box.box()
        label_row(preference.color, 'dot2', sub_box.row(), label=_z('Union'))
        label_row(preference.color, 'dot3', sub_box.row(), label=_z('Difference'))
        label_row(preference.color, 'dot4', sub_box.row(), label=_z('Slash'))
        label_row(preference.color, 'dot5', sub_box.row(), label=_z('Knife'))
        label_row(preference.color, 'dot6', sub_box.row(), label=_z('Inset'))
        label_row(preference.color, 'dot7', sub_box.row(), label=_z('Intersect'))

        # Solidify
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Solidify"))
        sub_box = sub_box.box()
        label_row(preference.color, 'solidify_x', sub_box.row(), label=_z('Solidify X'))
        label_row(preference.color, 'solidify_y', sub_box.row(), label=_z('Solidify Y'))
        label_row(preference.color, 'solidify_z', sub_box.row(), label=_z('Solidify Z'))
        label_row(preference.color, 'solidify_c', sub_box.row(), label=_z('Solidify C'))

        # Displace
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Displace"))
        sub_box = sub_box.box()
        label_row(preference.color, 'displace_x', sub_box.row(), label=_z('Displace X'))
        label_row(preference.color, 'displace_y', sub_box.row(), label=_z('Displace Y'))
        label_row(preference.color, 'displace_z', sub_box.row(), label=_z('Displace Z'))

        # Screw
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Screw"))
        sub_box = sub_box.box()
        label_row(preference.color, 'screw_x', sub_box.row(), label=_z('Screw X'))
        label_row(preference.color, 'screw_y', sub_box.row(), label=_z('Screw Y'))
        label_row(preference.color, 'screw_z', sub_box.row(), label=_z('Screw Z'))

        # Array
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Array"))
        sub_box = sub_box.box()
        label_row(preference.color, 'array_x', sub_box.row(), label=_z('Array X'))
        label_row(preference.color, 'array_y', sub_box.row(), label=_z('Array Y'))
        label_row(preference.color, 'array_z', sub_box.row(), label=_z('Array Z'))

        # Simple Deform

        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Simple Deform"))
        sub_box = sub_box.box()
        label_row(preference.color, 'simple_deform_x', sub_box.row(), label=_z('Deform X'))
        label_row(preference.color, 'simple_deform_y', sub_box.row(), label=_z('Deform Y'))
        label_row(preference.color, 'simple_deform_z', sub_box.row(), label=_z('Deform Z'))

        # Basic Dots
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Basic Dots"))
        sub_box = sub_box.box()
        label_row(preference.color, 'dot', sub_box.row())
        label_row(preference.color, 'dot_highlight', sub_box.row())

        # Wireframe
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Wireframe"))
        sub_box = sub_box.box()
        label_row(preference.color, 'wireframe_c', sub_box.row(), label=_z('Wireframe'))

        # Bevel
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Bevel"))
        sub_box = sub_box.box()
        label_row(preference.color, 'bevel_c', sub_box.row(), label=_z('Bevel'))

        # Dots Text
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Dots Text"))
        sub_box = sub_box.box()        
        label_row(preference.color, 'Bool_Dots_Text', sub_box.row(), label=_z('Display Dots Text'))
        layout.separator()