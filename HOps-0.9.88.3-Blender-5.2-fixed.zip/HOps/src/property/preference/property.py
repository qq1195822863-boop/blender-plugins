# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy, os
from pathlib import Path
from math import radians
from mathutils import Vector
from bpy.types import PropertyGroup
from bpy.props import BoolProperty, FloatVectorProperty, FloatProperty, StringProperty, EnumProperty, IntProperty

from .... utility import addon, modifier
from .... import bl_info
from ... utilityremove import names


def update_HardOps_Panel_Tools(self, context):
    panel = getattr(bpy.types, "hops_main_panel", None)
    if panel is not None:
        bpy.utils.unregister_class(panel)
        panel.bl_category = addon.preference().toolbar_category_name
        bpy.utils.register_class(panel)


def category_name_changed(self, context):
    category = addon.preference().toolbar_category_name
    try:
        change_hard_ops_category(category)
    except Exception as e:
        print(e)


def profile_dir():
    return Path(__file__).parents[5].joinpath('presets', 'profiles')

# Edit mode properties

Eevee_presets = [
    ("64", "64", "64"),
    ("128", "128", "128"),
    ("256", "256", "256"),
    ("512", "512", "512"),
    ("1024", "1024", "1024"),
    ("2048", "2048", "2048"),
    ("4096", "4096", "4096")]


booleans_modes = [
    ("BMESH", _z("Bmesh"), "Bmesh"),
    ("CARVE", _z("Carve"), "Carve")]

settings_tabs_items = [
    ("UI", _z("UI"), "UI"),
    ("DRAWING", _z("Drawing"), "Drawing"),
    ("INFO", _z("Info"), "Info"),
    ("KEYMAP", _z("Keymap"), "Keymap"),
    ("LINKS", _z("Links / Help"), "Links / Help"),
    ("ADDONS", _z("Addons"), "Addons")]

mirror_modes = [
    ("MODIFIER", _z("Mod"), "Mod"),
    ("BISECT", _z("Bisect"), "Bisect"),
    ("SYMMETRY", _z("Symmetry"), "Symmetry")]

mirror_modes_multi = [
    ("VIA_ACTIVE", _z("Mod"), "Mod"),
    ("MULTI_SYMMETRY", _z("Symmetry"), "Symmetry")]

mirror_direction = [
    ("-", "-", ""),
    ("+", "+", "")]

ko_popup_type = [
    ("DEFAULT", _z("Default"), "Default"),
    ("ST3", "St3", "")]

# menu_array_type = [
#     ("DEFAULT", "Default", ""),
#     ("ST3", "St3 V1", ""),
#     ("ST3_V2", "St3 V2", "")]

array_type = [
    ("CIRCLE", _z("Circle"), "Circle"),
    ("DOT", _z("Dot"), "Dot")]

symmetrize_type = [
    ("DEFAULT", _z("Default"), "Default"),
    ("Machin3", "Machin3", "M3")]

accu_length_opts = [
    ('Kilometers', _z('Kilometers'), 'Kilometers'),
    ('Meters', _z('Meters'), 'Meters'),
    ('Centimeters', _z('Centimeters'), 'Centimeters'),
    ('Millimeters', _z('Millimeters'), 'Millimeters'),
    ('Micrometers', _z('Micrometers'), 'Micrometers'),
    ('Miles', _z('Miles'), 'Miles'),
    ('Feet', _z('Feet'), 'Feet'),
    ('Inches', _z('Inches'), 'Inches'),
    ('Thousandth', _z('Thousandth'), 'Thousandth')]

recent_sort_char = {}

sort_options = (
    'sort_modifiers',
    'sort_nodes',
    'sort_bevel',
    'sort_array',
    'sort_mirror',
    'sort_solidify',
    'sort_weighted_normal',
    'sort_simple_deform',
    'sort_triangulate',
    'sort_decimate',
    'sort_remesh',
    'sort_subsurf',
    'sort_bevel_last',
    'sort_array_last',
    'sort_mirror_last',
    'sort_nodes_last',
    'sort_solidify_last',
    'sort_weighted_normal_last',
    'sort_simple_deform_last',
    'sort_triangulate_last',
    'sort_decimate_last',
    'sort_remesh_last',
    'sort_subsurf_last')


def bc():
    wm = bpy.context.window_manager

    if hasattr(wm, 'bc'):
        return bpy.context.preferences.addons[wm.bc.addon].preferences

    return False


def kitops():
    wm = bpy.context.window_manager

    if hasattr(wm, 'kitops'):
        return bpy.context.preferences.addons[wm.kitops.addon].preferences

    return False


def sync_sort(prop, context):
    for option in sort_options:

        if bc() and hasattr(bc().behavior, option):
            bc().behavior[option] = getattr(prop, option)
        # else:
        #     print(F'Unable to sync sorting options with Box Cutter; Hard Ops {option}\nUpdate Box Cutter!')


def validate_char(prop, context, option):
    for other in dir(prop):
        if not other.endswith('_char'):
            continue

        if option == other:
            if not getattr(prop, option):
                value = prop.__annotations__[option].keywords['default']
                recent_sort_char[option] = value
                setattr(prop, option, value)

                return

            continue

        if getattr(prop, option) == getattr(prop, other):
            setattr(prop, other, recent_sort_char[option])
            recent_sort_char[option] = getattr(prop, option)

            return

    recent_sort_char[option] = getattr(prop, option)


def sort_depth(prop, context):
    sync_sort(prop, context)

    # modifier.sort_depth = prop.sort_depth


def sort_char(prop, context):
    validate_char(prop, context, 'sort_char')
    sync_sort(prop, context)

    modifier.sort_flag = prop.sort_char


def sort_ignore_char(prop, context):
    validate_char(prop, context, 'sort_ignore_char')
    sync_sort(prop, context)

    modifier.ignore_flag = prop.sort_ignore_char


def sort_last_char(prop, context):
    validate_char(prop, context, 'sort_last_char')
    sync_sort(prop, context)

    modifier.sort_last_flag = prop.sort_last_char


def sort_lock_above_char(prop, context):
    validate_char(prop, context, 'sort_lock_above_char')
    sync_sort(prop, context)

    modifier.lock_below_flag = prop.sort_lock_above_char


def sort_lock_below_char(prop, context):
    validate_char(prop, context, 'sort_lock_below_char')
    sync_sort(prop, context)

    modifier.lock_above_flag = prop.sort_lock_below_char


def sort_stop_char(prop, context):
    validate_char(prop, context, 'sort_stop_char')
    sync_sort(prop, context)

    modifier.stop_flag = prop.sort_stop_char


class hops(PropertyGroup):

    bl_idname = f"HOps: {bl_info['version'][0]}.{bl_info['version'][1]}.{bl_info['version'][2]}.{bl_info['version'][3]}"

    debug: BoolProperty(name=_z("debug"), default=False, description = "debug")

    # Not shown in pref
    show_presets: BoolProperty(
        name = _z("Show Presets"),
        description = "Show Presets\nShow presets in helper",
        default = True)

    toolshelf: EnumProperty(
        name=_z("hopstool"), description="hopstool",
        items=[
            ('HOPSTOOL', _z("Hopstool"), "Hopstool"),
            ('MIRROR', _z("Mirror"), "Mirror")],
        default='HOPSTOOL')

    # Convert BC notifications
    bc_dimensions_converter: EnumProperty(
        name=_z("Dimensions"),
        description="Dimensions\nBC Dimensions Converter",
        items=[
            ("Kilometers", _z("Kilometers"), "Kilometers"),
            ("Meters", _z("Meters"), "Meters"),
            ("Centimeters", _z("Centimeters"), "Centimeters"),
            ("Millimeters", _z("Millimeters"), "Millimeters"),
            ("Micrometers", _z("Micrometers"), "Micrometers"),
            ("Miles", _z("Miles"), "Miles"),
            ("Feet", _z("Feet"), "Feet"),
            ("Inches", _z("Inches"), "Inches"),
            ("Thousandth", _z("Thousandth"), "Thousandth")],
        default='Meters')

    accu_length: EnumProperty(
        name=_z("Accu Length"),
        description="Accu Length\nLength to start with accu",
        items=accu_length_opts,
        default='Meters')

    bevel_miter_outer: EnumProperty(
        name=_z("Outer Miter"),
        description="Outer Miter",
        items=[
            ("MITER_SHARP", _z("Sharp"), "Sharp"),
            ("MITER_PATCH", _z("Patch"), "Patch"),
            ("MITER_ARC", _z("Arc"), "Arc")],
        default='MITER_ARC')

    bevel_miter_inner: EnumProperty(
        name=_z("Inner Miter"),
        description="Inner Miter",
        items=[
            ("MITER_SHARP", _z("Sharp"), "Sharp"),
            ("MITER_ARC", _z("Arc"), "Arc")],
        default='MITER_SHARP')

    map_scroll_ftype: EnumProperty(
        name=_z("Map Scroll File Types"),
        description="Map Scroll File Types",
        items=[
            ("PNG", "PNG", ""),
            ("JPG", "JPG", ""),
            ("BMP", "BMP", ""),
            ("TIFF", "TIFF", ""),
            ("PNG-JPG", "PNG-JPG", ""),
            ("ALL", _z("ALL"), "ALL")],
        default='PNG')

    decalmachine_fix: BoolProperty(name=_z("Use Setup For DECALmachine"), default=False, description = "Use Setup For DECALmachine")

    adaptivemode: BoolProperty(_z("Adaptive Segments"), default=False, description="Adaptive Segments\nDynamic segment adjustment during bevel",)
    adaptiveoffset: FloatProperty(_z("Adaptive Offset"), default=10, min=0, description = "Adaptive Offset")
    adaptivewidth: BoolProperty(_z("Adaptive Segments"), default=False, description = "Adaptive Segments")

    auto_bweight: BoolProperty(_z("auto bweight"), default=False, description="auto bweight\nJump to Adjust Bevel post Csharpen",)
    bevel_profile: FloatProperty(_z("default bevel profile"), default=0.70, min=0, max=1, description="default bevel profile\nDefault bevel profile for modals",)
    default_segments: IntProperty(name=_z("Default Segments"), description="Default Segments\nDefault segments for new bevel", default=3, min=1, max=36)
    use_default_profiles: BoolProperty(_z("Default Profiles"), default=True, description = "Default Profiles")

    profile_folder: StringProperty(_z("Profile Folder"), default=str(Path(__file__).parents[5].joinpath('presets', 'profiles')), subtype='DIR_PATH', description = "Profile Folder")
    lights_folder: StringProperty(_z("Lights Folder"), default=str(Path(__file__).parents[5].joinpath('presets', 'lights')), subtype='DIR_PATH', description = "Lights Folder")
    maps_folder: StringProperty(_z("Roughness Folder"), default=str(Path(__file__).parents[5].joinpath('maps')), subtype='DIR_PATH', description = "Roughness Folder")

    keep_cutin_bevel: BoolProperty(name=_z("Keep Cut In Bevel"), default=True, description="Keep Cut In Bevel\nKeeps bevel during cut-in process. By default bevel is omitted.")
    force_array_reset_on_init: BoolProperty(name=_z("Force Array Reset"), default=False, description = "Force Array Reset")
    force_array_apply_scale_on_init: BoolProperty(name=_z("Force Array Apply Scale"), default=False, description = "Force Array Apply Scale")
    force_thick_reset_solidify_init: BoolProperty(name=_z("Force Reset Solidify"), default=False, description = "Force Reset Solidify")

    ko_popup_type: EnumProperty(
        name=_z("KitOps Popup Type"),
        description="""KitOps Popup Type\nAsset Loader Toggle

Kitops popup toggle for expansive or classic
Default - classic kitops popup
Expansive - digital loader for both kitops and decalmachine""",
        items=[("DEFAULT", _z("Default"), "Default"),
        ("ST3", _z("Expansive"), "Expansive")],
        default='ST3')

    # array_type: EnumProperty(
    #     name="Array V1 Gizmo Type",
    #     description="Array V1 Circle / DOT",
    #     items=[
    #         ("CIRCLE", "Circle", ""),
    #         ("DOT", "Dot", "")],
    #         default='CIRCLE')

    radial_array_type: EnumProperty(
        name=_z("Radia_Array Type"),
        description="""Radia_Array Type\nRadial Array Option Type 
 Classic supports only meshes and uses 2 modifiers 
 Nodes is a single modifier and supports curves as well 
 """,
        items=[
            ("CLASSIC", _z("Classic"), "Classic"),
            ("NODES", _z("Nodes (V2)"), "Nodes (V2)")],
            default='CLASSIC')

    to_shape_type: EnumProperty(
        name=_z("To_Shape Type"),
        description="To_Shape Type\nTo_Shape Interface Type",
        items=[
            ("CLASSIC", _z("Classic "), "Classic "),
            ("CLASSIC+", _z("To_Shape 1.5 "), "To_Shape 1.5 ")],
            default='CLASSIC+')

    multi_tool_entry: EnumProperty(
        name=_z("Multi Tool Entry"),
        description="Multi Tool Entry\nMulti tool entry point",
        items=[
            ("SELECT", _z("SELECT"), "SELECT"),
            ("SPIN", _z("SPIN"), "SPIN"),
            ("MERGE", _z("MERGE"), "MERGE"),
            ("DISSOLVE", _z("DISSOLVE"), "DISSOLVE"),
            ("JOIN", _z("JOIN"), "JOIN"),
            ("KNIFE", _z("KNIFE"), "KNIFE")],
            default='SELECT')

    menu_style_selector: EnumProperty(
        name=_z("Menu Style Selector"),
        description="Menu Style Selector\nMenu style selector",
        items=[
            ("DEFAULT", _z("Default"), "Default"),
            ("BLENDER", "Blender", "")],
            default='DEFAULT')

    array_v2_use_2d: EnumProperty(
        name=_z("Array V2 Adjust Mode"),
        description="Array V2 Adjust Mode\nMethod for Array V2",
        items=[
            ("2D", "2D", ""),
            ("3D", "3D", "")],
            default='2D')

    # st3_meshtools: BoolProperty(name="Enable ST3 Meshtools", default=False, description="Enable experimental ST3 Meshtools in edit")

    meshclean_mode: EnumProperty(
        name=_z("Mode"), description="Mode",
        items=[
            ('ACTIVE', _z("Active"), "Active\nEffect all the active object geometry"),
            ('SELECTED', _z("Selected"), "Selected\nEffect only selected geometry or selected objects geometry"),
            ('VISIBLE', _z("Visible"), "Visible\nEffect only visible geometry")],
            default='ACTIVE')

    meshclean_dissolve_angle: FloatProperty(
        name=_z("Limited Dissolve Angle"),
        default=radians(0.5),
        min=radians(0),
        max=radians(30),
        subtype="ANGLE", description = "Limited Dissolve Angle")

    meshclean_remove_threshold: FloatProperty(
        name=_z("Remove Threshold Amount"),
        description="Remove Threshold Amount\nRemove Double Amount",
        default=0.001,
        min=0.0001,
        max=1.00)

    meshclean_unhide_behavior: BoolProperty(default=True)
    meshclean_delete_interior: BoolProperty(default=False)
    #to_cam_jump: BoolProperty(default=True, description="To_Camera activate new camera as active")
    to_cam: EnumProperty(
        name=_z("To_Cam Behavior"),
        description="""To_Cam Behavior\nTo_Cam Behavior

Frontal - places camera in front of central model
View - Aligns camera to view which can be preferred""",
        items=[
            ("DEFAULT", _z("Frontal"), "Frontal"),
            ("VIEW", _z("View"), "View")],
            default='VIEW')

    # dice_version: EnumProperty(
    #     name="Dice Behavior",
    #     description="Dice Behavior\n\nV1: Classic Dice\nV2: New Dice \n",
    #     items=[
    #         ("V1", "Original", ""),
    #         ("V2", "Version 2", "")],
    #         default='V2')

    to_render_jump: BoolProperty(default=False, description="Lookdev settings to render settings on confirm of viewport+")
    to_light_constraint: BoolProperty(default=False, description="Blank / Add light utilizes track to")

    add_prefix: BoolProperty(default=False, description="Add Prefix On Select Q menu Items")

    accushape_type: EnumProperty(
        name=_z("Default Accushape Version"),
        description="Default Accushape Version\nWhat technique to use for accushape",
        items=[
            ('CLASSIC', _z("Classic"), "Classic\nOriginal version of accushape"),
            ('V2', "V2", "V2\nRefined redesigned optimal aimed for mobility")],
        default='V2')

    bool_scroll: EnumProperty(
        name=_z("Default Boolscroll Method"),
        description="Default Boolscroll Method\nWhat technique to use to boolscroll",
        items=[
            ('CLASSIC', _z("Classic"), "Classic\nIsolate cutters then begin showing cutters via scroll"),
            ('ADDITIVE', _z("Additive"), "Additive\nDo not hide previous cutters when beginning scroll")],
        default='CLASSIC')

    bool_scroll_type: EnumProperty(
        name=_z("Default Scroll System"),
        description="Default Scroll System\nWhich system of scroll",
        items=[
            ('CLASSIC', _z("Classic"), "Classic\nClassic Bool/Mod scroller"),
            ('EVERY', _z("Every"), "Every\nUnified scroll system")],
        default='EVERY')

    ever_scroll_dot_open: EnumProperty(
        name=_z("Default Launch UI"),
        description="Default Launch UI\nLaunch EverScroll with Dot Open / Closed",
        items=[
            ('DOT', _z("Dot UI"), "Dot UI\nUse Dot UI"),
            ('FAS', _z("FAS UI"), "FAS UI\nDot will be closed")],
        default='FAS')

    dice_method: EnumProperty(
        name=_z("Default Dice Method"),
        description="Default Dice Method\nWhat technique to use to cut the object",
        items=[
            ('KNIFE_PROJECT', _z("Knife Project"), "Knife Project\nUse knife project to cut the object"),
            ('MESH_INTERSECT', _z("Mesh Intersect"), "Mesh Intersect\nUse mesh intersect to cut the object")],
        default='KNIFE_PROJECT')

    dice_adjust: EnumProperty(
        name=_z("Default Dice Adjust"),
        description="Default Dice Adjust\nWhat variable to start out adjusting with the mouse",
        items=[
            ('AXIS', _z("Axis"), "Axis\nUse the mouse to adjust the dicing axis"),
            ('SEGMENTS', _z("Segments"), "Segments\nUse the mouse to adjust the amount of cuts"),
            ('NONE', _z("None"), "None\nDon't use the mouse to adjust anything")],
        default='AXIS')

    dice_show_mesh_wire: BoolProperty(
        name=_z("Dice Show Mesh Wire"),
        description="Dice Show Mesh Wire\nShow the wireframe of the mesh after it has been cut",
        default=True)

    dice_wire_type: EnumProperty(
        name=_z("Dice Wire Type"),
        description="Dice Wire Type\nWhat type of wire drawing to use",
        items=[
            ('LINES', _z("Lines"), "Lines\nDraw the dice shader with lines"),
            ('TICKS', _z("Ticks"), "Ticks\nDraw the dice shader with ticks (angle brackets)"),
            ('DOTS', _z("Dots"), "Dots\nDraw the dice shader with dots")],
        default='LINES')

    smart_apply_dice: EnumProperty(
        name=_z("Default Dice Adjust"),
        description="Default Dice Adjust\nInitial optional apply behavior on dice launch",
        items=[
            ('SMART_APPLY', _z("Smart Apply"), "Smart Apply\nSmart apply prior to dice"),
            ('APPLY', _z("Apply"), "Apply\nConvert to mesh prior to dice."),
            ('NONE', _z("None"), "None\nDo not apply. Just Dice.")],
        default='NONE')

    bool_bstep: BoolProperty(
        name=_z("Bool Bevel Step"),
        description="Bool Bevel Step\nAdd new bevel during sort bypass on Ctrl + click boolean operations",
        default=True)

    boolean_solver: EnumProperty(
        name=_z("Boolean Solver"),
        description="Boolean Solver",
        items=[('FAST', _z("Fast"), "Fast\nFast solver for booleans (Default)"),
               ('EXACT', _z("Exact"), "Exact\nExact solver for booleans (Slower)")],
        default='FAST')

    sharp_use_crease: BoolProperty(name=_z("Allow Sharpening To Use Crease"), default=True, description="Allow Sharpening To Use Crease\nSharpen / Mark to mark using crease 1.0")
    sharp_use_bweight: BoolProperty(name=_z("Allow Sharpening To Use Bevel Weight"), default=True, description="Allow Sharpening To Use Bevel Weight\nSharpen / Mark to mark using bevel weight 1.0")
    sharp_use_seam: BoolProperty(name=_z("Allow Sharpening To Use Seams"), default=False, description="Allow Sharpening To Use Seams\nSharpen / Mark to mark using seams. Assists with face selection")
    sharp_use_sharp: BoolProperty(name=_z("Allow Sharpening To Use Sharp Edges"), default=True, description="Allow Sharpening To Use Sharp Edges\nSharpen / Mark to mark using sharp marking. Assists autosmoothing")

    sort_modifiers: BoolProperty(
        name = _z('Sort Modifiers'),
        description = "Sort Modifiers\n Sort modifier order",
        update = sync_sort,
        default = True)

    sort_bevel: BoolProperty(
        name = _z('Sort Bevel'),
        description = "Sort Bevel\n Ensure bevel modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_weighted_normal: BoolProperty(
        name = _z('Sort Weighted Normal'),
        description = "Sort Weighted Normal\n Ensure weighted normal modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_array: BoolProperty(
        name = _z('Sort Array'),
        description = "Sort Array\n Ensure array modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_mirror: BoolProperty(
        name = _z('Sort Mirror'),
        description = "Sort Mirror\n Ensure mirror modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_solidify: BoolProperty(
        name = _z('Sort Soldify'),
        description = "Sort Soldify\n Ensure solidify modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = False)

    sort_triangulate: BoolProperty(
        name = _z('Sort Triangulate'),
        description = "Sort Triangulate\n Ensure triangulate modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_simple_deform: BoolProperty(
        name = _z('Sort Simple Deform'),
        description = "Sort Simple Deform\n Ensure simple deform modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_decimate: BoolProperty(
        name = _z('Sort Decimate'),
        description = "Sort Decimate\n Ensure decimate modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = False)

    sort_nodes: BoolProperty(
        name = _z('Sort Nodes'),
        description = "Sort Nodes\n Ensure Geometry Nodes modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = False)

    sort_remesh: BoolProperty(
        name = _z('Sort Remesh'),
        description = "Sort Remesh\n Ensure remesh modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_subsurf: BoolProperty(
        name = _z('Sort Subsurf'),
        description = "Sort Subsurf\n Ensure subsurf modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = False)

    sort_weld: BoolProperty(
        name = _z('Sort Weld'),
        description = "Sort Weld\n Ensure weld modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = False)

    sort_uv_project: BoolProperty(
        name = _z('Sort UV Project'),
        description = "Sort UV Project\n Ensure uv project modifiers are placed after any boolean modifiers created",
        update = sync_sort,
        default = True)

    sort_bevel_last: BoolProperty(
        name = _z('Sort Bevel'),
        description = "Sort Bevel\n Only effect the most recent bevel modifier when sorting",
        update = sync_sort,
        default = True)

    sort_weighted_normal_last: BoolProperty(
        name = _z('Sort Weighted Normal Last'),
        description = "Sort Weighted Normal Last\n Only effect the most recent weighted normal modifier when sorting",
        update = sync_sort,
        default = True)

    sort_array_last: BoolProperty(
        name = _z('Sort Array Last'),
        description = "Sort Array Last\n Only effect the most recent array modifier when sorting",
        update = sync_sort,
        default = True)

    sort_mirror_last: BoolProperty(
        name = _z('Sort Mirror Last'),
        description = "Sort Mirror Last\n Only effect the most recent mirror modifier when sorting",
        update = sync_sort,
        default = True)

    sort_solidify_last: BoolProperty(
        name = _z('Sort Soldify Last'),
        description = "Sort Soldify Last\n Only effect the most recent solidify modifier when sorting",
        update = sync_sort,
        default = False)

    sort_triangulate_last: BoolProperty(
        name = _z('Sort Triangulate Last'),
        description = "Sort Triangulate Last\n Only effect the most recent triangulate modifier when sorting",
        update = sync_sort,
        default = True)

    sort_simple_deform_last: BoolProperty(
        name = _z('Sort Simple Deform Last'),
        description = "Sort Simple Deform Last\n Only effect the most recent simple deform modifier when sorting",
        update = sync_sort,
        default = True)

    sort_decimate_last: BoolProperty(
        name = _z('Sort Decimate Last'),
        description = "Sort Decimate Last\n Only effect the most recent decimate modifier when sorting",
        update = sync_sort,
        default = False)

    sort_nodes_last: BoolProperty(
        name = _z('Sort Nodes last'),
        description = '\n Only effect the most recent nodes modifier when sorting',
        update = sync_sort,
        default = True)

    sort_remesh_last: BoolProperty(
        name = _z('Sort Remesh Last'),
        description = "Sort Remesh Last\n Only effect the most recent remesh modifier when sorting",
        update = sync_sort,
        default = True)

    sort_subsurf_last: BoolProperty(
        name = _z('Sort Subsurf Last'),
        description = "Sort Subsurf Last\n Only effect the most recent subsurface modifier when sorting",
        update = sync_sort,
        default = False)

    sort_weld_last: BoolProperty(
        name = _z('Sort Weld Last'),
        description = "Sort Weld Last\n Only effect the most recent weld modifier when sorting",
        update = sync_sort,
        default = True)

    sort_uv_project_last: BoolProperty(
        name = _z('Sort UV Project Last'),
        description = "Sort UV Project Last\n Only effect the most recent uv project modifier when sorting",
        update = sync_sort,
        default = True)

    sort_bevel_ignore_weight: BoolProperty(
        name = _z('Ignore Weight Bevels'),
        description = "Ignore Weight Bevels\n Ignore bevel modifiers that are using the weight limit method while sorting",
        update = sync_sort,
        default = True)

    sort_bevel_ignore_vgroup: BoolProperty(
        name = _z('Ignore VGroup Bevels'),
        description = "Ignore VGroup Bevels\n Ignore bevel modifiers that are using the vertex group limit method while sorting",
        update = sync_sort,
        default = True)

    sort_bevel_ignore_only_verts: BoolProperty(
        name = _z('Ignore Only Vert Bevels'),
        description = "Ignore Only Vert Bevels\n Ignore bevel modifiers that are using the only vertices option while sorting",
        update = sync_sort,
        default = True)

    sort_depth: IntProperty(
        name = _z('Sort Depth'),
        description = "Sort Depth\n Number of sortable mods from the end (bottom) of the stack. 0 to sort whole stack",
        update = sort_depth,
        min = 0,
        default = 6)

    sort_char: StringProperty(
        name = _z('Sort Flag'),
        description = "Sort Flag\n Prefix a modifier name with this text character and it will sort the modifier\n  Note: Check the above options before utilizing these flags\n             Many of the behaviors exist for common modifiers",
        update = sort_char,
        maxlen = 1,
        default = '*')

    sort_ignore_char: StringProperty(
        name = _z('Ignore Flag'),
        description = """Ignore Flag\n
 Prefix the modifier name with this text character and it will be ignored.
  Default: Space""",
        update = sort_ignore_char,
        maxlen = 1,
        default = ' ')

    sort_last_char: StringProperty(
        name = _z('Sort Last Flag'),
        description = """Sort Last Flag\n
 Prefix the modifier name with this text character and it will be treated like the most recent modifier of the type when sorted.
  Note: The lowest modifier in the stack with this flag takes precedence

 Prefix twice to force""",
        update = sort_last_char,
        maxlen = 1,
        default = '!')

    sort_lock_above_char: StringProperty(
        name = _z('Lock Above Flag'),
        description = """Lock Above Flag\n
 Prefix a modifier name with this text character and it will keep itself below the modifier above it""",
        update = sort_lock_above_char,
        maxlen = 1,
        default = '^')

    sort_lock_below_char: StringProperty(
        name = _z('Lock Below Flag'),
        description = """Lock Below Flag\n
 Prefix a modifier name with this text character and it will keep itself above the modifier below it""",
        update = sort_lock_below_char,
        maxlen = 1,
        default = '.')

    sort_stop_char: StringProperty(
        name = _z('Stop Flag'),
        description = """Stop Flag\n
 Prefix a modifier name with this text character and it will not sort it or any modifiers above it in the stack.
   Note: Including those with prefixes""",
        update = sort_stop_char,
        maxlen = 1,
        default = '_')

    workflow: EnumProperty(
        name=_z("Mode"), description="Mode\nDefault mode of boolean usage.",
        items=[
            ('NONDESTRUCTIVE', _z("NonDestructive"), "NonDestructive\nKeep boolean modifiers unapplied initially"),
            ('DESTRUCTIVE', _z("Destructive"), "Destructive\nApply boolean modifiers immediately")],
            default='NONDESTRUCTIVE')

    workflow_mode: EnumProperty(
        name=_z("Mode"), description="Mode\nDefault mode of bevel mod usage.",
        items=[
            ('ANGLE', _z("Angle"), "Angle\nDefault bevel utilizing mesh angle for calculation"),
            ('WEIGHT', _z("Weight"), "Weight\nUtilizies bevel working from weighted edges")],
            default='ANGLE')

    # add_weighten_normals_mod: BoolProperty(name="WN", default=False, description="Adds weighted normal mod via Csharp at end of stack (antiquated)")
    use_harden_normals: BoolProperty(name=_z("HN"), default=False, description="HN\nEnables Harden normals on Bevel use")

    helper_tab: StringProperty(name=_z("Helper Set Category"), default="MODIFIERS", description = "Helper Set Category")

    Eevee_preset_HQ: EnumProperty(items=Eevee_presets, default="2048")
    Eevee_preset_LQ: EnumProperty(items=Eevee_presets, default="64")

    tab: EnumProperty(name=_z("Tab"), items=settings_tabs_items, description = "Tab")

    toolbar_category_name: StringProperty(
        name=_z("Toolbar Category"),
        default="HOps",
        description="Toolbar Category\nName of the tab in the toolshelf in the 3d view",
        update=category_name_changed)

    bev_bool_helper: BoolProperty(
        name=_z("Bevel / Boolean Helper"),
        default=True,
        description=_z("Toggles bevel / boolean helper with bevel boolean multi tool \n Ctrl + Shift + B \n Intended for laptop usage and workflow simplification"))

    bevel_loop_slide: BoolProperty(
        name=_z("Bweight loop slide"),
        default=True,
        description="Bweight loop slide\nEnables loop slide on bevel modifiers")

    pie_mod_expand: BoolProperty(
        name=_z("Pie Mod Expand"),
        default=False,
        description="Pie Mod Expand\nExpand Pie")

    right_handed: BoolProperty(
        name=_z("Right Handed"),
        default=True,
        description="Right Handed\nReverse The X Mirror For Right Handed People")

    BC_unlock: BoolProperty(
        name=_z("BC"),
        default=False,
        description="BC\nBC Support")

    hops_modal_help: BoolProperty(
        name=_z("Modal Help"),
        default=False,
        description="Modal Help\nEnables help for modal operators")

    Hops_sharp_remove_cutters: BoolProperty(
        name=_z("Remove Cutters"),
        description="Remove Cutters\nRemove Cutters on Csharp apply",
        default=False)

    Hops_smartapply_remove_cutters: BoolProperty(
        name=_z("Smart Apply Remove Cutters"),
        description="""Smart Apply Remove Cutters\nSmart Apply Remove Cutters

Experimental:
Can have issues with multi mesh smart apply or shared cutters.
Work in progress""",
        default=False)

    sharpness: FloatProperty(name=_z("angle edge marks are applied to"), default=radians(30), min=radians(1), max=radians(180), precision=3, unit='ROTATION', description = "angle edge marks are applied to")
    auto_smooth_angle: FloatProperty(name=_z("angle edge marks are applied to"), default=radians(60), min=radians(1), max=radians(180), precision=3, unit='ROTATION', description = "angle edge marks are applied to")

    # operators
    Hops_mirror_modes: EnumProperty(name=_z("Mirror Modes"), items=mirror_modes, default='MODIFIER', description = "Mirror Modes")
    Hops_mirror_modes_multi: EnumProperty(name=_z("Mirror Modes Multi"), items=mirror_modes_multi, default='VIA_ACTIVE', description = "Mirror Modes Multi")
    Hops_mirror_direction: EnumProperty(name=_z("Mirror Direction"), items=mirror_direction, default='+', description = "Mirror Direction")

    Hops_gizmo_mirror_block_x: BoolProperty(name=_z("Mirror X Gizmo Block"), default=False, description = "Mirror X Gizmo Block")
    Hops_gizmo_mirror_block_y: BoolProperty(name=_z("Mirror Y Gizmo Block"), default=False, description = "Mirror Y Gizmo Block")
    Hops_gizmo_mirror_block_z: BoolProperty(name=_z("Mirror Z Gizmo Block"), default=False, description = "Mirror Z Gizmo Block")

    Hops_gizmo_mirror_u: BoolProperty(name=_z("Mirror UV"), default=False, description = "Mirror UV")
    Hops_gizmo_mirror_v: BoolProperty(name=_z("Mirror UV"), default=False, description = "Mirror UV")

    Hops_mirror_modal_mod_on_bisect: BoolProperty(
        name=_z("Modal Mirror Bisect Modifier"),
        default=True,
        description="Modal Mirror Bisect Modifier\nuse modifier for modal mirror bisect")

    Hops_mirror_modal_use_cursor: BoolProperty(
        name=_z("Modal Mirror Uess Cursor"),
        default=False,
        description="Modal Mirror Uess Cursor\nuses cursor for modal mirror")

    Hops_mirror_modal_revert: BoolProperty(
        name=_z("Modal Mirror Revert"),
        default=True,
        description="Modal Mirror Revert\nreverts modal mirror")

    Hops_mirror_modal_Interface_scale: FloatProperty(
        name=_z("Modal Mirror Interface Scale"),
        description="Modal Mirror Interface Scale",
        default=0.7, min=0.1, max=50)

    Hops_gizmo_array: FloatProperty(
        name=_z("Array gizmo"),
        description="Array gizmo",
        default=0
        )

    Hops_modal_percent_scale: FloatProperty(
        name=_z("Modal Operators Scale"),
        description="Modal Operators Scale",
        default=1, min=0.001, max=100)

    Hops_twist_radial_sort: BoolProperty(
        name=_z("Twist / Radial Bypass"),
        default=True,
        description="""Twist / Radial Bypass\nDetermines render visibility for twist360/radial

Bypasses sort bypass / edit display on twist / radial 360
*bypassing sort can be useful for cutting radial shapes as a whole*""")

    auto_scroll_time_interval: FloatProperty(
        name=_z("Auto Scroll Interval"),
        description="Auto Scroll Interval\nAuto Scroll Time Interval in seconds",
        default=1, min=0.1, max=60)

    # Edit mode properties

    adjustbevel_use_1_segment: BoolProperty(name=_z("use 1 segment"), default=True, description = "use 1 segment")

    Hops_circle_size: FloatProperty(
        name=_z("Bevel offset step"),
        description="Bevel offset step",
        default=0.0001, min=0.0001)

    Hops_gizmo: BoolProperty(name=_z("Display Mirror Gizmo"), default=True, description = "Display Mirror Gizmo")
    Hops_gizmo_fail: BoolProperty(name=_z("gizmo failed"), default=False, description = "gizmo failed")
    Hops_gizmo_mirror: BoolProperty(name=_z("Display Mirror Gizmo"), default=False, description = "Display Mirror Gizmo")
    Hops_gizmo_qarray: BoolProperty(name=_z("Display Array Gizmo"), default=False, description = "Display Array Gizmo")

    circle_divisions: IntProperty(name=_z("Division Count"), description="Division Count\nAmount Of Vert divisions for circle", default=5, min=1, max=12)

    dots_snap: EnumProperty(
        name=_z("Mode"), description="Mode",
        items=[
            ('ORIGIN', _z("Origin"), "Origin"),
            ('FIXED', _z("Fixed"), "Fixed"),
            ('CURSOR', _z("Cursor"), "Cursor")],
        default='CURSOR')

    modal_handedness: EnumProperty(
        name=_z("Handedness"),
        description="Orientation Style for modal operation\n\nprotip: Use left.\n",
        items=[
            ('LEFT', _z("Left"), "Left"),
            ('RIGHT', _z("Right"), "Right")],
        default='LEFT')

    dots_x_cursor: FloatProperty(_z("dots x"), default=100, description = "dots x")
    dots_y_cursor: FloatProperty(_z("dots y"), default=0, description = "dots y")

    dots_x: FloatProperty(_z("dots x"), default=100, description = "dots x")
    dots_y: FloatProperty(_z("dots y"), default=100, description = "dots y")

    parent_boolshapes: BoolProperty(name=_z("Parent Boolshapes"), default=False, description="Parent Boolshapes\nParents cutter to the target allowing for transformation")

    view_align_filter_empties: BoolProperty(
        name = _z('View Align Filter Empties'),
        description = 'View Align Filter Empties',
        default = False)

    # Map Scroll
    map_scroll_folder_count: IntProperty(name=_z("Map Scroll Folder Count"), description="Map Scroll Folder Count", default=3, min=3, max=8)
    map_scroll_file_count: IntProperty(name=_z("Map Scroll File Count"), description="Map Scroll File Count", default=3, min=3, max=8)

    # UI Toggles
    show_hardops_properties: BoolProperty(name=_z("Show Hard-Ops Properties"), default=False, description = "Show Hard-Ops Properties")
    show_sharp_options: BoolProperty(name=_z("Show Sharp Options"), default=False, description = "Show Sharp Options")
    show_cutter_options: BoolProperty(name=_z("Show Cutter Options"), default=False, description = "Show Cutter Options")

    # Sculpt PreUse Options
    add_primitive_newobject: BoolProperty(name=_z("Added primitive becomes new object"), default=False, description = "Added primitive becomes new object")

    show_misc_options: BoolProperty(name=_z("Show Misc Options"), default=False, description = "Show Misc Options")

    in_tool_popup_style: EnumProperty(
        name=_z("In-Tool pop-up Style"),
        description="In-Tool pop-up Style\nStyle of popup when applicable ",
        items=[
            ('DEFAULT', _z("Default"), "Default\nDefault style"),
            ('BLENDER', "Blender", "Blender style")],
        default='DEFAULT')

def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def header_row(row, prop, label='', emboss=False):
    preference = addon.preference()
    icon = 'DISCLOSURE_TRI_RIGHT' if not getattr(preference.property, prop) else 'DISCLOSURE_TRI_DOWN'
    row.alignment = 'LEFT'
    row.prop(preference.property, prop, text='', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.25
    sub.prop(preference.property, prop, text='', icon=icon, emboss=emboss)
    row.prop(preference.property, prop, text=F'{label}', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.75
    sub.prop(preference.property, prop, text=' ', icon='BLANK1', emboss=emboss)


def draw(preference, context, layout):

    # --- HARD-OPS PROPS --- #
    box = layout.box()
    header_row(box.row(align=True), 'show_hardops_properties', label=_z('Hardops Properties'))
    box.separator()
    if preference.property.show_hardops_properties:
        # Controls
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Modal Controls"))
        sub_box = sub_box.box()
        label_row(preference.property, 'modal_handedness', sub_box.row(), label=_z('Left/Right'))

        # Menu
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Menu Options"))
        sub_box = sub_box.box()
        label_row(preference.property, 'ko_popup_type', sub_box.row(), label=_z('KitOps Popup'))
        #label_row(preference.property, 'dice_version', sub_box.row(), label='Dice')
        label_row(preference.property, 'to_shape_type', sub_box.row(), label=_z('To_Shape'))
        label_row(preference.property, 'accushape_type', sub_box.row(), label=_z('Accushape'))
        label_row(preference.property, 'radial_array_type', sub_box.row(), label=_z('Radial Array'))

        # Controls
        split = box.split()
        sub_box = box.box()
        sub_box.label(text=_z("Scroll Options"))
        sub_box = sub_box.box()
        #label_row(preference.property, 'bool_scroll_type', sub_box.row(), label='Scroll Type')
        label_row(preference.property, 'bool_scroll', sub_box.row(), label=_z('Bool Scroll'))
        #if addon.preference().property.bool_scroll_type != 'CLASSIC':
        label_row(preference.property, 'ever_scroll_dot_open', sub_box.row(), label=_z('Scroll UI'))
        label_row(preference.property, 'auto_scroll_time_interval', sub_box.row(), label=_z('Time Interval'))

        # Bevel
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Bevel Defaults"))
        sub_box = sub_box.box()
        label_row(preference.property, 'workflow_mode', sub_box.row(), label=_z('Workflow Mode'))
        label_row(preference.property, 'default_segments', sub_box.row(), label=_z('Segments'))
        label_row(preference.property, 'bevel_profile', sub_box.row(), label=_z('Profile'))
        label_row(preference.property, 'bevel_miter_outer', sub_box.row(), label=_z('Miter Outer'))
        label_row(preference.property, 'bevel_miter_inner', sub_box.row(), label=_z('Miter Inner'))
        label_row(preference.property, 'use_default_profiles', sub_box.row(), label=_z('Default Profiles'))
        label_row(preference.property, 'use_harden_normals', sub_box.row(), label=_z('Harden Normals'))

        # Clean
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("In-Tool"))
        sub_box = sub_box.box()
        label_row(preference.property, 'array_v2_use_2d', sub_box.row(), label=_z('Array Method'))
        label_row(preference.property, 'multi_tool_entry', sub_box.row(), label=_z('Select Tool '))
        label_row(preference.property, 'in_tool_popup_style', sub_box.row(), label=_z('Pop-up Style'))
        label_row(preference.property, 'menu_style_selector', sub_box.row(), label=_z('Menu Style'))

        # Operators
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Operator"))
        sub_box = sub_box.box()
        label_row(preference.behavior, 'mat_viewport', sub_box.row(), label=_z('Blank Material (view)'))
        label_row(preference.property, 'Hops_twist_radial_sort', sub_box.row(), label=_z('Radial / Twist Render'))
        label_row(preference.property, 'to_render_jump', sub_box.row(), label=_z('Viewport+ Set Render'))
        label_row(preference.property, 'view_align_filter_empties', sub_box.row(), label=_z('View Align Filter'))
        label_row(preference.property, 'meshclean_mode', sub_box.row(), label=_z('Meshclean '))
        label_row(preference.property, 'accu_length', sub_box.row(), label=_z('Accushape '))
        label_row(preference.property, 'add_primitive_newobject', sub_box.row(), label=_z('Add Primitive - New Object '))

        # Misc
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Misc"))
        sub_box = sub_box.box()
        label_row(preference.property, 'to_light_constraint', sub_box.row(), label=_z('Blank Light Constraint'))
        label_row(preference.property, 'to_cam', sub_box.row(), label=_z('To_Cam '))
        label_row(preference.property, 'map_scroll_ftype', sub_box.row(), label=_z('Map Scroll'))
        label_row(preference.property, 'map_scroll_folder_count', sub_box.row(), label=_z('Map Scroll Folders'))
        label_row(preference.property, 'map_scroll_file_count', sub_box.row(), label=_z('Map Scroll Files'))

        # Paths
        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Paths"))
        sub_box = sub_box.box()
        label_row(preference.property, 'profile_folder', sub_box.row(), label=_z('Profile Folder'))
        label_row(preference.property, 'lights_folder', sub_box.row(), label=_z('Lights Folder'))
        label_row(preference.property, 'maps_folder', sub_box.row(), label=_z('Maps Folder'))

    # --- MARK & SHARPEN --- #
    box = layout.box()
    header_row(box.row(align=True), 'show_sharp_options', label=_z('Mark & Sharpen'))
    # box.separator()
    if preference.property.show_sharp_options:

        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Mark"))
        sub_box = sub_box.box()
        label_row(preference.property, 'sharp_use_crease', sub_box.row(), label=_z('Crease'))
        label_row(preference.property, 'sharp_use_bweight', sub_box.row(), label=_z('Bevel Weight'))
        label_row(preference.property, 'sharp_use_seam', sub_box.row(), label=_z('Seam'))
        label_row(preference.property, 'sharp_use_sharp', sub_box.row(), label=_z('Sharp'))

        split = box.split()
        sub_box = split.box()
        sub_box.label(text=_z("Sharp Defaults"))
        sub_box = sub_box.box()
        label_row(preference.property, 'sharpness', sub_box.row(), label=_z('Angle'))

    # --- CUTTERS --- #
    box = layout.box()
    header_row(box.row(align=True), 'show_cutter_options', label=_z('Cutter Removal'))
    box.separator()
    if preference.property.show_cutter_options:
        box = box.box()
        label_row(preference.property, 'Hops_sharp_remove_cutters', box.row(), label=_z('Csharp '))
        label_row(preference.property, 'Hops_smartapply_remove_cutters', box.row(), label=_z('Smart Apply '))

    # --- MISC --- #
    box = layout.box()
    header_row(box.row(align=True), 'show_misc_options', label=_z('Misc Options'))
    box.separator()
    if preference.property.show_misc_options:
        box = box.box()
        label_row(preference.property, 'bev_bool_helper', box.row(), label=_z('Bevel / Boolean Multi Hotkey'))

    # --- DEBUG --- #
    layout.separator()
    label_row(preference.property, 'debug', layout.row(), label=_z('Debug Options'))
    if addon.preference().property.debug:
        draw_debug_options(addon.preference(), layout)


def draw_debug_options(preference, layout):

    #label_row(preference.property, 'st3_meshtools', layout.row(), label='St3 Meshtools')
    label_row(preference.property, 'decalmachine_fix', layout.row(), label=_z('Use Decalmachine Fix'))
    label_row(preference.property, 'show_presets', layout.row(), label=_z('show_presets'))
    label_row(preference.property, 'adaptivemode', layout.row(), label=_z('Use Adaptive Mode'))
    label_row(preference.property, 'adaptiveoffset', layout.row(), label=_z('Use Adaptive Offset'))
    label_row(preference.property, 'adaptivewidth', layout.row(), label=_z('Use Adaptive Width'))
    label_row(preference.property, 'auto_bweight', layout.row(), label=_z('Use Auto Bweight'))
    label_row(preference.property, 'keep_cutin_bevel', layout.row(), label=_z('keep_cutin_bevel'))
    label_row(preference.property, 'force_array_reset_on_init', layout.row(), label=_z('force_array_reset_on_init'))
    label_row(preference.property, 'force_array_apply_scale_on_init', layout.row(), label=_z('force_array_apply_scale_on_init'))
    label_row(preference.property, 'force_thick_reset_solidify_init', layout.row(), label=_z('force_thick_reset_solidify_init'))
    label_row(preference.property, 'meshclean_dissolve_angle', layout.row(), label=_z('meshclean_dissolve_angle'))
    label_row(preference.property, 'meshclean_remove_threshold', layout.row(), label=_z('meshclean_remove_threshold'))
    label_row(preference.property, 'meshclean_unhide_behavior', layout.row(), label=_z('meshclean_unhide_behavior'))
    label_row(preference.property, 'meshclean_delete_interior', layout.row(), label=_z('meshclean_delete_interior'))
    label_row(preference.property, 'Hops_gizmo_mirror_u', layout.row(), label=_z('mirror U'))
    label_row(preference.property, 'Hops_gizmo_mirror_v', layout.row(), label=_z('mirror V'))
    #label_row(preference.property, 'hops_modal_help', layout.row(), label='Show Help For modal Operators')
    # label_row(preference.property, 'sort_bevel', layout.row(), label='sort_bevel')
    # label_row(preference.property, 'sort_solidify', layout.row(), label='sort_solidify')
    # label_row(preference.property, 'sort_array', layout.row(), label='sort_array')
    # label_row(preference.property, 'sort_mirror', layout.row(), label='sort_mirror')
    # label_row(preference.property, 'sort_weighted_normal', layout.row(), label='sort_weighted_normal')
    # label_row(preference.property, 'sort_simple_deform', layout.row(), label='sort_simple_deform')
    # label_row(preference.property, 'sort_triangulate', layout.row(), label='sort_triangulate')
    # label_row(preference.property, 'sort_decimate', layout.row(), label='sort_decimate')

    if preference.property.sort_modifiers:
        row = layout.row(align=True)
        row.alignment = 'RIGHT'
        split = row.split(align=True, factor=0.85)

        row = split.row(align=True)
        for type in modifier.sort_types:
            icon = F'MOD_{type}'
            if icon == 'MOD_WEIGHTED_NORMAL':
                icon = 'MOD_NORMALEDIT'
            elif icon == 'MOD_SIMPLE_DEFORM':
                icon = 'MOD_SIMPLEDEFORM'
            elif icon == 'MOD_DECIMATE':
                icon = 'MOD_DECIM'
            elif icon == 'MOD_WELD':
                icon = 'AUTOMERGE_OFF'

            # Fix
            if icon == 'MOD_UV_PROJECT':
                icon = 'MOD_UVPROJECT'
            elif icon == 'MOD_NODES':
                icon = 'GEOMETRY_NODES'

            row.prop(preference.property, F'sort_{type.lower()}', text='', icon=icon)

        row = split.row(align=True)
        row.scale_x = 1.5
        row.popover('HOPS_PT_sort_last', text='', icon='SORT_ASC')


    label_row(preference.property, 'workflow', layout.row(), label=_z('workflow'))
    label_row(preference.property, 'workflow_mode', layout.row(), label=_z('workflow_mode'))
    #label_row(preference.property, 'add_weighten_normals_mod', layout.row(), label='add_weighten_normals_mod')
    label_row(preference.property, 'use_harden_normals', layout.row(), label=_z('use_harden_normals'))
    label_row(preference.property, 'helper_tab', layout.row(), label=_z('helper_tab'))
    label_row(preference.property, 'tab', layout.row(), label=_z('tab'))
    label_row(preference.property, 'toolbar_category_name', layout.row(), label=_z('toolbar_category_name'))
    label_row(preference.property, 'bevel_loop_slide', layout.row(), label=_z('bevel_loop_slide'))
    label_row(preference.property, 'pie_mod_expand', layout.row(), label=_z('pie_mod_expand'))
    label_row(preference.property, 'right_handed', layout.row(), label=_z('right_handed'))
    label_row(preference.property, 'BC_unlock', layout.row(), label=_z('BC_unlock'))
    label_row(preference.property, 'auto_smooth_angle', layout.row(), label=_z('auto_smooth_angle'))
    label_row(preference.property, 'Hops_mirror_modes', layout.row(), label=_z('Hops_mirror_modes'))
    label_row(preference.property, 'Hops_mirror_modes_multi', layout.row(), label=_z('Hops_mirror_modes_multi'))
    label_row(preference.property, 'Hops_mirror_direction', layout.row(), label=_z('Hops_mirror_direction'))
    label_row(preference.property, 'Hops_mirror_modal_use_cursor', layout.row(), label=_z('Hops_mirror_modal_use_cursor'))
    label_row(preference.property, 'Hops_mirror_modal_revert', layout.row(), label=_z('Hops_mirror_modal_revert'))
    label_row(preference.property, 'Hops_mirror_modal_Interface_scale', layout.row(), label=_z('Hops_mirror_modal_Interface_scale'))
    label_row(preference.property, 'Hops_gizmo_array', layout.row(), label=_z('Hops_gizmo_array'))
    label_row(preference.property, 'Hops_modal_percent_scale', layout.row(), label=_z('Hops_modal_percent_scale'))
    label_row(preference.property, 'adjustbevel_use_1_segment', layout.row(), label=_z('adjustbevel_use_1_segment'))
    label_row(preference.property, 'Hops_circle_size', layout.row(), label=_z('Hops_circle_size'))
    label_row(preference.property, 'Hops_gizmo', layout.row(), label=_z('Hops_gizmo'))
    label_row(preference.property, 'Hops_gizmo_fail', layout.row(), label=_z('Hops_gizmo_fail'))
    label_row(preference.property, 'Hops_gizmo_mirror', layout.row(), label=_z('Hops_gizmo_mirror'))
    label_row(preference.property, 'Hops_gizmo_qarray', layout.row(), label=_z('Hops_gizmo_qarray'))
    label_row(preference.property, 'parent_boolshapes', layout.row(), label=_z('Parent Boolshapes'))
