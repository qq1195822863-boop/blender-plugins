# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
import textwrap


from bpy.types import PropertyGroup, Panel
from bpy.props import BoolProperty, IntProperty, EnumProperty
from .... import bl_info
from .... utility import addon
from .... utils.blender_ui import get_dpi_factor

import rna_keymap_ui


def get_hotkey_entry_item(km, kmi_name, kmi_value, properties):
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if properties == 'name':
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item
            elif properties == 'tab':
                if km.keymap_items[i].properties.tab == kmi_value:
                    return km_item
            elif properties == 'none':
                return km_item
    return None

sharp_modes = [
    ("SSHARP", _z("Ssharp"), "Ssharp"),
    ("CSHARP", _z("Csharp"), "Csharp"),
    ("RESHARP", _z("Resharp"), "Resharp"),
    ("CSHARPBEVEL", _z("CsharpBevel"), "CsharpBevel"),
    ("SSHARPWN", _z("Weighted Mod"), "Weighted Mod"),
    ("AUTOSMOOVE", _z("Autosmooth"), "Autosmooth"),
    ("CLEANSHARP", _z("Cleansharp"), "Cleansharp"),
    ("SMART_APPLY", _z("Smart Apply"), "Smart Apply")]


class hops(PropertyGroup):

    # Modal Controls
    spacebar_accept: BoolProperty(name=_z("Spacebar Accept"), default=False, description=f'Disabling allows spacebar to use menu in-tool in addition to tab on select modals.\n ie: Bevel, Boolshift, To_Shape 1.5')

    rmb_cancel: BoolProperty(name=_z("RMB Cancel"), default=True, description=f'Use right mouse button to cancel an operator')

    # Sharps
    sharp: EnumProperty(
        name=_z("Sharp Modes"),
        default='SSHARP',
        items=sharp_modes, description = "Sharp Modes")

    sharp_alt: EnumProperty(
        name=_z("Sharp Modes"),
        default='SSHARPWN',
        items=sharp_modes, description = "Sharp Modes")

    sharp_ctrl: EnumProperty(
        name=_z("Sharp Modes"),
        default='CSHARP',
        items=sharp_modes, description = "Sharp Modes")

    sharp_shift: EnumProperty(
        name=_z("Sharp Modes"),
        default='AUTOSMOOVE',
        items=sharp_modes, description = "Sharp Modes")

    sharp_alt_ctrl: EnumProperty(
        name=_z("Sharp Modes"),
        default='SSHARP',
        items=sharp_modes, description = "Sharp Modes")

    sharp_shift_ctrl: EnumProperty(
        name=_z("Sharp Modes"),
        default='RESHARP',
        items=sharp_modes, description = "Sharp Modes")

    sharp_alt_shift: EnumProperty(
        name=_z("Sharp Modes"),
        default='SSHARP',
        items=sharp_modes, description = "Sharp Modes")

    # Menu drop downs
    expand_modals: BoolProperty(name=_z("Show Modal Operators hotkeys"), default=False, description = "Show Modal Operators hotkeys")
    expand_sharpen: BoolProperty(name=_z("Show sharpen options"), default=False, description = "Show sharpen options")
    show_main_pie: BoolProperty(name=_z("Show main pie"), default=False, description = "Show main pie")
    show_main_menu: BoolProperty(name=_z("Show main menu"), default=False, description = "Show main menu")
    show_menu_sys: BoolProperty(name=_z("Show menu systems"), default=False, description = "Show menu systems")
    show_booleans: BoolProperty(name=_z("Show booleans"), default=False, description = "Show booleans")
    show_operators: BoolProperty(name=_z("Show operators"), default=False, description = "Show operators")
    show_edit_mode: BoolProperty(name=_z("Show edit mode"), default=False, description = "Show edit mode")
    show_third_party: BoolProperty(name=_z("Show third party"), default=False, description = "Show third party")
    show_extended: BoolProperty(name=_z("Show extended"), default=False, description = "Show extended")


def header_row(row, prop, label='', emboss=False):
    preference = addon.preference()
    icon = 'DISCLOSURE_TRI_RIGHT' if not getattr(preference.keymap, prop) else 'DISCLOSURE_TRI_DOWN'
    row.alignment = 'LEFT'
    row.prop(preference.keymap, prop, text='', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.25
    sub.prop(preference.keymap, prop, text='', icon=icon, emboss=emboss)
    row.prop(preference.keymap, prop, text=F'{label}', emboss=emboss)

    sub = row.row(align=True)
    sub.scale_x = 0.75
    sub.prop(preference.keymap, prop, text=' ', icon='BLANK1', emboss=emboss)


class HOPS_PT_Keys_info(Panel):
    bl_label = _z('Keys info')
    bl_description = 'Keys info'
    bl_space_type = 'VIEW_3D'
    bl_category = _z('HOps')
    bl_region_type = 'UI'

    def draw(self, context):
        layout = self.layout
        preference = addon.preference()

        layout.label(text=f'''{bl_info['description']}''')

        # if addon.preference().needs_update:# and not 'Connection Failed':
        #     text = _z("Needs Update")
        #     layout.label(text=("{}.{}.{}.{} : {}").format(bl_info['version'][0], bl_info['version'][1], bl_info['version'][2], bl_info['version'][3], text), icon='ERROR')
        # elif addon.preference().needs_update == _z('Connection Failed'):
        #     text = _z("Unknown")
        #     layout.label(text=f'''{bl_info['version'][0]}.{bl_info['version'][1]}.{bl_info['version'][2]}.{bl_info['version'][3]} : {text}''', icon='ERROR')
        # else:
        #     text = _z("Current")
        #     layout.label(text=f'''{bl_info['version'][0]}.{bl_info['version'][1]}.{bl_info['version'][2]}.{bl_info['version'][3]} : {text}''', icon='FUND')

        row = layout.row(align=True)

        layout.label(text=_z('Menus'))

        row = layout.row(align=True)
        layout.label(text=_z('Main Menu'), icon='EVENT_Q')

        row.label(text='', icon='EVENT_SHIFT')
        row.label(text=_z('Pie Menu'), icon='EVENT_Q')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('`  Hops Helper'))

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('Preference / Keymap Helper'), icon='EVENT_K')

        # row = layout.row(align=True)
        # row.label(text='', icon='EVENT_CTRL')
        # row.label(text='Multi assist', icon='EVENT_O')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_ALT')
        row.label(text=_z('Material List'), icon='EVENT_M')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_ALT')
        row.label(text=_z('Viewport Submenu'), icon='EVENT_V')

        layout.separator()
        layout.label(text=_z('Boolean Multi Tool'))
        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text='', icon='EVENT_SHIFT')
        row.label(text=_z('Bevel/Bool Multi Tool'), icon='EVENT_B')

        layout.separator()

        layout.label(text=_z('Operators'))
        row = layout.row(align=True)
        row.label(text='', icon='EVENT_ALT')
        row.label(text=_z('Interactive Mirror'), icon='EVENT_X')
        layout.separator()

        layout.label(text=_z('Booleans'))
        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('Union'), icon='ADD')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('Difference'), icon='REMOVE')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('Slash'), icon='IPO_LINEAR')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text=_z('Intersect'), icon='SORTBYEXT')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_ALT')
        row.label(text='', icon='EVENT_SHIFT')
        row.label(text=_z('Inset'), icon='IPO_LINEAR')
        layout.separator()

        layout.label(text=_z('Edit Mode'))
        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text='', icon='EVENT_ALT')
        row.label(text=_z('Union'), icon='ADD')

        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text='', icon='EVENT_ALT')
        row.label(text=_z('Difference'), icon='REMOVE')

        if addon_exists('mira_tools'):
            layout.separator()
            layout.label(text=_z('3rd Party'))
            row = layout.row(align=True)
            row.label(text='', icon='EVENT_CTRL')
            row.label(text='', icon='EVENT_SHIFT')
            row.label(text=_z('`  Mira Curve Stretch Helper'))

        layout.separator()
        layout.label(text=_z('Others'))
        row = layout.row(align=True)
        row.label(text='', icon='EVENT_CTRL')
        row.label(text='', icon='EVENT_ALT')
        row.label(text='', icon='EVENT_SHIFT')
        row.label(text='', icon='EVENT_L')
        row.label(text=_z('Logo Adjust'), icon='REMOVE')

        layout.separator()


class HOPS_PT_Keys(Panel):
    bl_label = _z('Keys Options')
    bl_description = 'Keys Options'
    bl_space_type = 'VIEW_3D'
    bl_category = _z('HOps')
    bl_region_type = 'UI'

    def draw(self, context, layout):
        preference = addon.preference()
        draw(preference, context, layout)


def draw(preference, context, layout):

    box = layout.box()
    split = box.split()
    col = split.column()

    col.label(text=_z('Do not remove hotkeys, disable them instead.'))

    # Modal Controls
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'expand_modals', label=_z('Modal Operators'))
    if preference.keymap.expand_modals:
        sub_box = sub_box.box()
        sub_box.label(text=_z('Modal Operators'))
        sub_box.separator()
        sub_box.prop(preference.keymap, "spacebar_accept", text=_z("Spacebar Accept"))
        sub_box.prop(preference.keymap, "rmb_cancel")

    # Sharpen
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'expand_sharpen', label=_z('Sharpen'))
    if preference.keymap.expand_sharpen:
        sub_box = sub_box.box()
        sub_box.label(text=_z('Sharpen Activation'))
        sub_box.separator()
        sub_box.prop(preference.keymap, "sharp", text=_z("Main"))
        sub_box.prop(preference.keymap, "sharp_alt", text="Alt")
        sub_box.prop(preference.keymap, "sharp_ctrl", text="Ctrl")
        sub_box.prop(preference.keymap, "sharp_shift", text="Shift")
        sub_box.prop(preference.keymap, "sharp_alt_shift", text="Alt + Shift")
        sub_box.prop(preference.keymap, "sharp_alt_ctrl", text="Alt + Ctrl")
        sub_box.prop(preference.keymap, "sharp_shift_ctrl", text="Ctrl + Shift")
        sub_box.separator()
        sub_box.separator()

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.user

    # Main Pie
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_main_pie', label=_z('Main Pie'))
    if preference.keymap.show_main_pie:
        sub_box = sub_box.box()

        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', 'HOPS_MT_MainPie', 'name')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # Main Menu
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_main_menu', label=_z('Main Menu'))
    if preference.keymap.show_main_menu:
        sub_box = sub_box.box()

        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_MainMenu', 'name')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # Menus & Systems
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_menu_sys', label=_z('Menus & Systems'))
    if preference.keymap.show_menu_sys:
        sub_box = sub_box.box()

        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'hops.helper', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'hops.pref_helper', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_MaterialListMenu', 'name')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_ViewportSubmenu', 'name')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # Booleans
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_booleans', label=_z('Booleans'))
    if preference.keymap.show_booleans:
        sub_box = sub_box.box()

        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'hops.bool_union_hotkey', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'hops.bool_difference_hotkey', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'hops.bool_intersect_hotkey', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'hops.slash_hotkey', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'hops.bool_inset', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # Operators
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_operators', label=_z('Operators'))
    if preference.keymap.show_operators:
        sub_box = sub_box.box()

        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'hops.mirror_gizmo', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'hops.bev_multi', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # Edit Mode
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_edit_mode', label=_z('Edit Mode'))
    if preference.keymap.show_edit_mode:
        sub_box = sub_box.box()

        km = kc.keymaps['Mesh']
        kmi = get_hotkey_entry_item(km, 'hops.edit_bool_union', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

        sub_box.separator()
        km = kc.keymaps['Mesh']
        kmi = get_hotkey_entry_item(km, 'hops.edit_bool_difference', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))

    # 3rd Part
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_third_party', label=_z('3rd Party'))
    if preference.keymap.show_third_party:
        sub_box = sub_box.box()

        if addon_exists('mira_tools'):
            sub_box = sub_box.box()
            sub_box.label(text=_z("Mira"))
            km = kc.keymaps['Mesh']
            kmi = get_hotkey_entry_item(km, 'mesh.curve_stretch', 'none', 'none')
            if kmi:
                sub_box.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
            else:
                sub_box.label(text=_z("No hotkey entry found"))
                sub_box.label(text=_z("restore hotkeys from interface tab"))
        else:
            sub_box.label(text=_z("nothing to see here"))

    # Extended
    sub_box = col.box()
    header_row(sub_box.row(align=True), 'show_extended', label=_z('Extended'))
    if preference.keymap.show_extended:
        sub_box = sub_box.box()

        km = kc.keymaps['3D View']
        kmi = get_hotkey_entry_item(km, 'hops.tilde_remap', 'none', 'none')
        if kmi:
            sub_box.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, sub_box, 0)
        else:
            sub_box.label(text=_z("No hotkey entry found"))
            sub_box.label(text=_z("restore hotkeys from interface tab"))


def addon_exists(name):
    for addon_name in bpy.context.preferences.addons.keys():
        if name in addon_name: return True
    return False
