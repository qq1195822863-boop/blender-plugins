# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.utils import register_class, unregister_class
from bpy.types import AddonPreferences
from bpy.props import EnumProperty, PointerProperty, StringProperty, BoolProperty
import importlib

from . import behavior, display, expand, color, info, keymap, links, addons, ui, property
from . operators import operators, mirror
from .... utility import addon
from .... icons import get_icon_id
from .... import bl_info
from .... utils.blender_ui import get_dpi_factor
from .... utils.addons import addon_exists

# label row text names


class Hardops(AddonPreferences):
    bl_idname = addon.name

    def update_language(self, context):
        try:
            bpy.context.preferences.view.language = self.language
            
            if bpy.context.preferences.view.language != "en_US":
                bpy.context.preferences.view.use_translate_new_dataname = False
        
            bpy.ops.script.reload()
        except Exception as e:
            print("Couldn't parse: {}".format(e))

    if 'zh_CN' in bpy.app.translations.locales:
        language: bpy.props.EnumProperty(
            name = _z("Language"),
            description = _z("Language Description"),
            update = update_language,
            default = bpy.context.preferences.view.language if bpy.context.preferences.view.language in ["zh_CN", "zh_TW"] else "en_US",
            items =  [
                ("en_US", "English", "English"),
                # ("es", "Español", "Spanish"),
                # ("it_IT", "Italiano", "Italian"),
                # ("ja_JP", "日本語", "Japanese"),
                ("zh_CN", "简体中文", "Simplified Chinese"),
                ("zh_TW", "繁體中文", "Traditional Chinese"),
                # ("ru_RU", "русский", "Russian"),
                # ("fr_FR", "Français", "French"),
                # ("de_DE", "Deutsch", "German"),
                # ("ko_KR", "한국어(한국)", "Korean")
                # ('pt_PT', 'Português', 'Portuguese'),
                # ('nl_NL', 'Nederlands', 'Dutch'), 
            ]
        )
    else:
        language: bpy.props.EnumProperty(
            name = _z("Language"),
            description = _z("Language Description"),
            update = update_language,
            default = bpy.context.preferences.view.language if bpy.context.preferences.view.language in ["zh_HANS", "zh_HANT"] else "en_US",
            items =  [
                ("en_US", "English", "English"),
                # ("es", "Español", "Spanish"),
                # ("it_IT", "Italiano", "Italian"),
                # ("ja_JP", "日本語", "Japanese"),
                ("zh_HANS", "简体中文", "Simplified Chinese"),
                ("zh_HANT", "繁體中文", "Traditional Chinese"),
                # ("ru_RU", "русский", "Russian"),
                # ("fr_FR", "Français", "French"),
                # ("de_DE", "Deutsch", "German"),
                # ("ko_KR", "한국어(한국)", "Korean")
                # ('pt_PT', 'Português', 'Portuguese'),
                # ('nl_NL', 'Nederlands', 'Dutch'), 
            ]
        )

    settings: EnumProperty(
        name = _z('Settings'),
        description = "Settings\nSettings to display",
        items = [
            ('UI', _z('Ui'), "Ui"),
            ('PROPERTY', _z('Properties'), "Properties"),
            # ('BEHAVIOR', 'Behaviors', ''),
            ('COLOR', _z('Color'), "Color"),
            # ('DISPLAY', 'Display', ''),
            ('INFO', _z('Info'), "Info"),
            ('KEYMAP', _z('Keymap'), "Keymap"),
            ('LINKS', _z('Links/Help'), "Links/Help"),
            ('ADDONS', _z('Addons'), "Addons")],
        default = 'UI')

    # TODO: add update handler to gizmo toggles that calls gizmo ot

    behavior: PointerProperty(type=behavior.hardflow)
    ui: PointerProperty(type=ui.hops)
    color: PointerProperty(type=color.hops)
    display: PointerProperty(type=display.hardflow)
    expand: PointerProperty(type=expand.hardflow)
    property: PointerProperty(type=property.hops)
    keymap: PointerProperty(type=keymap.hops)
    needs_update: StringProperty()
    wrap_text: BoolProperty(default=True)
    operator: PointerProperty(type=operators)

    def draw(self, context):

        layout = self.layout
        box = layout.box()       

        box.prop(self, "language")

        box.label(text=_z("Translation is in progress. Whole text isn't translated"))

        row = self.layout.row()
        row.operator("wm.url_open", text=_z("Watch online video tutorials")).url = "https://www.bilibili.com/video/BV1hX4y1x7iZ/"
        row.operator("wm.url_open", text=_z("Chat Room")).url = "http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=LOP7dt3N9TrKLQTzU0hO_rgqr_rOl8sb&authKey=iOM7p2Juuj%2BURJffZXBYNhSfdnb9TPjI5mAG1um2h8KSJJj1hsLNxFL%2BiyY%2BjgOu&noverify=0&group_code=242343175"
        row.operator("wm.url_open", text=_z("Buy More")).url = "https://mesh.taobao.com/"
        layout = self.layout

        # if self.needs_update:
        #     col = layout.column_flow()
        #     row = col.row()
        #     row.separator()
        #     row.alert = True
        #     row.label(text=self.needs_update)

        #     row.operator("wm.url_open", text="", icon_value=get_icon_id("bmarket")).url = "https://item.taobao.com/item.htm?ft=t&id=632239323157"
        #     # row.operator("wm.url_open", text="", icon_value=get_icon_id("artstation")).url = "https://www.artstation.com/marketplace/orders"
        #     # row.operator("wm.url_open", text="", icon_value=get_icon_id("gumroad")).url = "https://gumroad.com/library"
        #     row.operator("wm.url_open", text="", icon="INFO").url = "https://hardops-manual.readthedocs.io/en/latest/faq/#how-do-i-update-hard-ops-boxcutter"
        # else:
        #     col = layout.column_flow()
        #     row = col.row()
        #     row.separator()
        #     row.label(text=_z('Hardops is up-to-date'))

        column = layout.column(align=True)

        row = column.row(align=True)
        row.prop(addon.preference(), 'settings', expand=True)

        box = column.box()
        globals()[addon.preference().settings.lower()].draw(addon.preference(), context, box)
        # context.area.tag_redraw()


class HOPS_OT_pref_helper(bpy.types.Operator):
    bl_idname = 'hops.pref_helper'
    bl_description = f'''Configure the preferences of {bl_info['description']}
    ***save prefs to keep across sessions***

    '''
    bl_label = _z('''Preferences''')
    bl_options = {'UNDO'}

    panels: dict = {}
    label: bool = False

    @classmethod
    def poll(cls, context): # need a poll for panel lookup
        return True

    def check(self, context):
        return True

    def invoke(self, context, event):
        preference = addon.preference()

        if not property.bc(): # reset toggle just incase
            preference.ui.bc_hops_toggle = 'HOPS'

        preference.wrap_text = False

        if preference.ui.use_helper_popup:
            self.label = True
            return context.window_manager.invoke_popup(self, width=int(400 * get_dpi_factor(force=False)))
        else:
            return context.window_manager.invoke_props_dialog(self, width=int(400 * get_dpi_factor(force=False)))


    def cancel(self, context):
        addon.preference().wrap_text = True
        return


    def execute(self, context):
        addon.preference().wrap_text = True
        return {'FINISHED'}


    def draw(self, context):
        preference = addon.preference()
        bc = property.bc()

        layout = self.layout

        if bc:
            row = layout.row()
            row.prop(preference.ui, 'bc_hops_toggle', expand=True)

            col = layout.column()
            col.separator()

        if preference.ui.bc_hops_toggle == 'BC':
            bc.layout = layout
            bc.draw(context)

        else:
            preference.layout = layout
            preference.draw(context)

        layout.separator()

        row = layout.row()
        row.operator_context = 'EXEC_AREA'

        row.menu('USERPREF_MT_save_load', text='', icon='COLLAPSEMENU')

        prefs = context.preferences
        if not prefs.use_preferences_save or bpy.app.use_userpref_skip_save_on_exit:
            row.operator('wm.save_userpref', text=_z("Save Preferences{:s}").format(" *" if prefs.is_dirty else ""))


classes = (
    mirror.props,
    operators,
    keymap.hops,
    HOPS_OT_pref_helper,
    property.hops,
    behavior.hardflow,
    color.hops,
    ui.hops,
    display.hardflow,
    expand.hardflow,
    Hardops)


def init_recent_sort_char():
    from .... utility import modifier
    from . import property

    def _init_recent_sort_char():
        if not bpy.context:
            return 0.1

        preference = addon.preference()

        for option in dir(preference.property):
            if not option.endswith('_char'):
                continue

            property.recent_sort_char[option] = getattr(preference.property, option)
            flag = option.replace('sort_', '').replace('_char', '')
            if flag == 'char':
                flag = 'sort'

            if flag == 'lock_above':
                flag = 'lock_below'

            elif flag == 'lock_below':
                flag = 'lock_above'

            flag += '_flag'
            setattr(modifier, flag, getattr(preference.property, option))

        return

    bpy.app.timers.register(_init_recent_sort_char, first_interval=0.1)


def register():
    init_recent_sort_char()
    for cls in classes:
        register_class(cls)
    ui.update_hops_panels(None,None)


def unregister():
    for cls in classes:
        unregister_class(cls)
