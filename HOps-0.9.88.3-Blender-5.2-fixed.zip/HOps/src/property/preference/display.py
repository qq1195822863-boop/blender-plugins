# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, IntProperty, FloatProperty

from ... utilityremove import names


class hardflow(PropertyGroup):

    dot_size: IntProperty(
        name = _z('Dot Size'),
        description = "Dot Size\nDot size",
        soft_min = 3,
        soft_max = 40,
        default = 10)

    dot_detect: IntProperty(
        name = _z('Dot Detection'),
        description = "Dot Detection\nDot detection size",
        soft_min = 1,
        soft_max = 30,
        default = 14)

    dot_side_offset: FloatProperty(
        name = _z('Dot offset'),
        description = "Dot offset\nDot side offset",
        soft_min = 0.5,
        soft_max = 5.0,
        default = 1.9)

    dot_corner_offset: FloatProperty(
        name = _z('Dot Corner offset'),
        description = "Dot Corner offset\nDot corner offset",
        soft_min = 0.5,
        soft_max = 5.0,
        default = 1.5)

    display_corner: IntProperty(
        name = _z('Dot Display Corner'),
        description = "Dot Display Corner\nDot display corner",
        soft_min = 0,
        soft_max = 7,
        default = 2)

    dot_boolshape_fade_distance: FloatProperty(
        name = _z('Boolshape Fade distance'),
        description = "Boolshape Fade distance\nFade distance for boolshape dots",
        default = 2.5)

    display_smartshape: BoolProperty(
        name = _z('Display Smartshape Row'),
        description = 'Display Smartshape Row',
        default = True)

    display_modifiers: BoolProperty(
        name = _z('Display Modifiers Row'),
        description = 'Display Modifiers Row',
        default = True)

    display_misc: BoolProperty(
        name = _z('Display Misc Row'),
        description = 'Display Misc Row',
        default = True)

    display_text: BoolProperty(
        name = _z('Display OnScreen Text'),
        description = 'Display OnScreen Text',
        default = True)

    bc_notifications: BoolProperty(
        name = _z('BC Notifications'),
        description = """BC Notifications\nBoxcutter Assistive Notifications
        
        Display OnScreen Text for BoxCutter
        Intended to assist with notification display 
        
        """,
        default = False)

    bc_extra_notifications: BoolProperty(
        name = _z("Extra Boxcutter Notifications"),
        description = "Extra Boxcutter Notifications\nShow additional boxcutter notifications",
        default = True)

    display_text_size: IntProperty(
        name = _z('Text size'),
        description = 'Text size',
        soft_min = 1,
        soft_max = 40,
        default = 20)

    display_text_size_for_dots: IntProperty(
        name = _z('Text size'),
        description = 'Text size',
        soft_min = 1,
        soft_max = 40,
        default = 20)

    use_label_factor: BoolProperty(
        name = _z('Use Label Factor'),
        description = "Use Label Factor\nUse label scale factor for blender version 2.82 and greater.\n"
                      'Fixes issues with label size in the topbar for most screens.\n'
                      'Disable if the labels in the topbar are displaying incorrectly',
        default = True)

def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):

    label_row(preference.display, 'dot_size', layout.row(), label=_z('Dot Size'))
    label_row(preference.display, 'dot_detect', layout.row(), label=_z('Dot Detection'))
    label_row(preference.display, 'dot_side_offset', layout.row(), label=_z('Dot side OffSet'))
    label_row(preference.display, 'dot_corner_offset', layout.row(), label=_z('Dot corner OffSet'))
    label_row(preference.display, 'display_corner', layout.row(), label=_z('Dot Display Corner'))
    label_row(preference.display, 'display_smartshape', layout.row(), label=_z('Display Smartshape Row'))
    label_row(preference.display, 'display_modifiers', layout.row(), label=_z('Display Modifiers Row'))
    label_row(preference.display, 'display_misc', layout.row(), label=_z('Display Misc Row'))
    label_row(preference.display, 'display_text', layout.row(), label=_z('Display Text in 3d'))
    label_row(preference.display, 'display_text_size', layout.row(), label=_z('Display Text Size'))
    label_row(preference.display, 'display_text_size_for_dots', layout.row(), label=_z('Display Dot Text Size'))
    label_row(preference.display, 'use_label_factor', layout.row(), label=_z('Fix Label Size'))
