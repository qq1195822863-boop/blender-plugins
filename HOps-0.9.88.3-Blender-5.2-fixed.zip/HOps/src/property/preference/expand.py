# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy

from bpy.types import PropertyGroup
from bpy.props import BoolProperty


class hardflow(PropertyGroup):

    display: BoolProperty(
        name = _z('Expand Display'),
        default = False, description = 'Expand Display')

    behavior: BoolProperty(
        name = _z('Expand Behavior'),
        default = False, description = 'Expand Behavior')


