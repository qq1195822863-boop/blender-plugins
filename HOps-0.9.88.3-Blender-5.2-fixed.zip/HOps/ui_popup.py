# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import *
from . icons import icons
from . ui.addon_checker import draw_addon_diagnostics
from . utils.addons import addon_exists
from . utils.blender_ui import get_dpi_factor
from . utility import addon
from . utility import modifier
from . import bl_info


class HOPS_OT_LearningPopup(bpy.types.Operator):
    """Learning Popup Helper
Learn more about Hard Ops / Boxcutter and how to use them.

    """
    bl_idname = "hops.learning_popup"
    bl_label = _z("Learning Popup Helper")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.system.dpi

        return context.window_manager.invoke_props_dialog(self, width=int(200 * get_dpi_factor(force=False)))

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)
        row = col.row()
        box = col.box()

        for name, url in weblinks:
            col.operator("wm.url_open", text=name).url = url

weblinks = [
    (f'''{bl_info['version'][0]}.{bl_info['version'][1]}{bl_info['version'][2]} Release Log''',   "https://masterxeon1001.com/2021/01/10/hard-ops-987-francium-release/"),
    (_z("H9 Learning Playlist"),         "https://www.youtube.com/playlist?list=PLjqpj14voWsXlLHjT8jMnn5uKLfXKFki8"),
    ("Glebs Lighting Course",      "https://gumroad.com/a/14423155/tpodw"),
    ("Blender Bros",                "https://gumroad.com/a/739308659"),
    ("Josh's Youtube",        "https://www.youtube.com/playlist?list=PLLnvxH5YKLoKWtvIJT2-SdOql2QpewslQ"),
    ("Ryuu's Youtube",        "https://www.youtube.com/playlist?list=PLJrcFnBj2iIgOelGfcdz5ZKof-D4LSphA"),
    ("StellarWorks",                "https://www.youtube.com/channel/UCK4RSljZQXfpwBrAUxwwxjw"),
    (_z("Rachel's Helmet Tutorial"),  "https://gum.co/scifihelmet"),
    (_z("Hard Ops Manual"),         "http://hardops-manual.readthedocs.io/en/latest/"),
    (_z("Hard Ops Documentation"),  "http://hardops-manual.readthedocs.io/en/latest/"),
    (_z("HOPS / BC Playlist"),        "https://www.youtube.com/playlist?list=PL0RqAjByAphEUuI2JDxIjjCQtfTRQlRh0"),
    (_z("HOPScutter Playlist"),      "https://www.youtube.com/playlist?list=PL0RqAjByAphHoCDKWy6OU4BwB7hTi8lo_"),
    (_z("Classic Video Playlist"), "https://www.youtube.com/playlist?list=PL0RqAjByAphGlunfvu2mM6aFyOJkdywyZ"),
    (_z("Hard Ops User Gallery"),   "https://www.pinterest.com/masterxeon1001/hard-ops-users/"),
    ("Challenge Board",         "https://www.pinterest.com/masterxeon1001/-np/"),
    ("Blender Transition Group",  "https://www.facebook.com/groups/701978080244781/"),
    (_z("Hard Ops Facebook Group"), "https://www.facebook.com/groups/HardOps/"),
    (_z("Hard Ops Discord Channel"),"https://discord.gg/ySRW6u9"),
    (_z("BoxCutter Release Log"), "https://masterxeon1001.com/2020/10/03/boxcutter-717-update-log/")
]

ko_weblinks = [
    (_z("KitOps Pro"),           "https://item.taobao.com/item.htm?ft=t&id=750703295677"),
    (_z("HOPS Classic Inserts"),  "https://gumroad.com/l/hopsclassicinserts"),
    (_z("Kit OPS Homepage"),      "https://www.kit-ops.com/")
]


class HOPS_OT_InsertsPopupPreview(bpy.types.Operator):
    """Kit Ops
Asset Multiloader
KitOps / DecalMachine / PowerLink

LMB - Insert Popup Window
Shift - Insert Popup Persistent (Digital only)
    Alt - KitOps Insert Popup (alt)

    """
    #Ctrl + Shift - Mark as cutter (E)

    bl_idname = "view3d.insertpopup"
    bl_label = _z("Kit Ops")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        preference = addon.preference().ui
        dpi_value = bpy.context.preferences.system.dpi
        wm = context.window_manager

        if event.shift and event.ctrl and not event.alt:
            selected = context.selected_objects

            for obj in selected:
                bpy.ops.object.convert(target='MESH')
                bpy.context.object.location[2] = 0.01
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                bpy.ops.hops.soft_sharpen()
                bpy.context.object.kitops.type = 'CUTTER'
                bpy.context.object.kitops.main = True
                bpy.context.object.kitops.boolean_type = 'DIFFERENCE'
            return {'FINISHED'}
        elif event.ctrl:
            bpy.ops.hops.kit_ops_window("INVOKE_DEFAULT")
            return {'FINISHED'}
        else:
            if addon.preference().property.ko_popup_type == 'DEFAULT' or event.alt:
                if preference.use_kitops_popup:
                    return context.window_manager.invoke_popup(self, width=int(200 * get_dpi_factor(force=False)))
                else:
                    return context.window_manager.invoke_props_dialog(self, width=int(200 * get_dpi_factor(force=False)))
            else:
                if addon_exists("DECALmachine") or hasattr(wm, 'kitops'):
                    bpy.ops.hops.kit_ops_window("INVOKE_DEFAULT")
                else:
                    self.report({'INFO'}, _z("An error has occured"))
                return {'FINISHED'}

    def draw(self, context):
        wm = context.window_manager
        if hasattr(wm, 'kitops'):
            from kitops.addon.interface.panel import KO_PT_ui
            KO_PT_ui.draw(self,context)

            from kitops.addon.utility.addon import preference

            preference = preference()

            self.layout.separator()

            row = self.layout.row()
            row.label(text=_z('Sort Modifiers'))
            row.prop(preference, 'sort_modifiers', text='')

            if preference.sort_modifiers:
                row = self.layout.row(align=True)
                row.alignment = 'RIGHT'
                split = row.split(align=True, factor=0.85)

                row = split.row(align=True)
                for type in modifier.sort_types:
                    icon = F'MOD_{type}'
                    if icon == 'MOD_WEIGHTED_NORMAL':
                        icon = 'MOD_NORMALEDIT'
                    elif icon == 'MOD_SIMPLE_DEFORM':
                        icon = 'MOD_SIMPLEDEFORM'
                    elif icon == 'MOD_DECIMATE':
                        icon = 'MOD_DECIM'
                    elif icon == 'MOD_WELD':
                        icon = 'AUTOMERGE_OFF'
                    elif icon == 'MOD_UV_PROJECT':
                        icon = 'MOD_UVPROJECT'
                    elif icon == 'MOD_NODES':
                        icon = 'GEOMETRY_NODES'
                    row.prop(preference, F'sort_{type.lower()}', text='', icon=icon)

                row = split.row(align=True)
                row.scale_x = 1.5
                row.popover('KO_PT_sort_last', text='', icon='SORT_ASC')

        else:
            layout = self.layout

            col = layout.column(align=True)
            row = col.row()
            box = col.box()

            for name, url in ko_weblinks:
                box.operator("wm.url_open", text=name).url = url


    def check(self, context):
        try:
            return True
        except:
            return {"RUNNING_MODAL"}

class HOPS_OT_AddonPopupPreview(bpy.types.Operator):
    """Addon Popup
    Addon checker popup

    """
    bl_idname = "view3d.addoncheckerpopup"
    bl_label = _z("Addon Popup")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.system.dpi

        return context.window_manager.invoke_props_dialog(self, width=int(200 * get_dpi_factor(force=False)))

    def draw(self, context):
        draw_addon_diagnostics(self.layout, columns=2)

    def check(self, context):
        return True


class HOPS_OT_PizzaPopupPreview(bpy.types.Operator):
    """Pizza Popup
    Order A Pizza!

    """
    bl_idname = "view3d.pizzapopup"
    bl_label = _z("Pizza Popup")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.system.dpi

        return context.window_manager.invoke_props_dialog(self, width=int(200 * get_dpi_factor(force=False)))

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        layout.label(text=_z("Pizza Ops"))
        # layout.label(text="")
        # layout.label(text="")

        # row = layout.row()

        # layout.label(text=_z("Dominos Pizza"))
        # layout.operator("wm.url_open", text=_z("Order Dominoes")).url = "https://order.dominos.com/"
        # layout.label(text="")
        # layout.separator()

        # layout.label(text=_z("Pizza Hut Pizza"))
        layout.operator("wm.url_open", text=_z("Order Pizza Hut")).url = "http://www.pizzahut.com/"
        # layout.label(text="")
        # layout.separator()

        # layout.label(text=_z("Papa John's Pizza"))
        # layout.operator("wm.url_open", text=_z("Order Papa John's")).url = "https://www.papajohns.com/order/menu"
        # layout.label(text="")
        # layout.separator()
