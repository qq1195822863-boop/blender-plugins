# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from math import radians
from bpy.props import EnumProperty, IntProperty, FloatProperty, BoolProperty
from .. utils import update_bevel_modifier_if_necessary, update_Weight_modifier_if_necessary
from ... utils.context import ExecutionContext
from . soft_sharpen import soft_sharpen_object
from ... utility import addon
from ... utils.objects import apply_modifiers
from ... utils.objects import get_modifier_with_type
from ... utility import modifier
from ...ui_framework.operator_ui import Master


class HOPS_OT_ComplexSharpenOperator(bpy.types.Operator):
    bl_idname = "hops.complex_sharpen"
    bl_label = _z("Hops Csharpen")
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {"REGISTER", "UNDO"}
    bl_description = _z("""Classic Csharpen System
    
*CSharp is now part of Sharpen under CTRL*
Adds Bevel Modifier / Shade Smooth / Enable Autosmooth
Mark Sharp Edges / Destructively Bakes - Ignores Modifiers via F6

Hold shift - Bypass modifier apply / Sstatus change
""")

    items: [(x.identifier, x.name, x.description, x.icon)
            for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    boolean: BoolProperty(name=_z("boolean"), default=True, description = "boolean")

    mirror: BoolProperty(name=_z("mirror"), default=False, description = "mirror")

    bevel: BoolProperty(name=_z("bevel"), default=False, description = "bevel")

    solidify: BoolProperty(name=_z("solidify"), default=True, description = "solidify")

    array: BoolProperty(name=_z("array"), default=False, description = "array")

    others: BoolProperty(name=_z("others"), default=False, description = "others")

    bevel_vg: BoolProperty(name=_z("only bevel with vertex group"), default=True, description = "only bevel with vertex group")

    segment_amount: IntProperty(name=_z("Segments"), description="Segments\nSegments For Bevel", default=3, min=1, max=12)

    bevelwidth: FloatProperty(name=_z("Bevel Width Amount"),
                              description="Bevel Width Amount\nSet Bevel Width",
                              default=0.0200,
                              precision=3,
                              min=0.000,
                              max=100)

    segment_modal: IntProperty(name=_z("Segments"), description="Segments\nSegments For Bevel", default=3, min=1, max=12)

    bevelwidth_modal: FloatProperty(name=_z("Bevel Width Global"),
                                    description="Bevel Width Global\nSet Global Bevel Width",
                                    default=0.0200,
                                    precision=3,
                                    min=0.000,
                                    max=100)

    additive_mode: BoolProperty(name=_z("Additive Mode"),
                                description="Additive Mode\nDon't clear existing edge properties",
                                default=True)

    auto_smooth_angle: FloatProperty(name=_z("angle edge marks are applied to"),
                                     default=radians(60),
                                     min=radians(1),
                                     max=radians(180),
                                     precision=3,
                                     unit='ROTATION', description = "angle edge marks are applied to")

    is_global: BoolProperty(name=_z("Is Global"), default=True, description = "Is Global")

    to_bwidth: BoolProperty(name=_z("To Bevel Width"), default=False, description = "To Bevel Width")

    reveal_mesh = True

    called_ui = False

    def __init__(self, *args, **kwargs):

        HOPS_OT_ComplexSharpenOperator.called_ui = False

    @classmethod
    def poll(cls, context):

        selected = context.selected_objects
        object = context.active_object
        if object is None: return False
        if object.mode == "OBJECT" and all(obj.type == "MESH" for obj in selected):
            return True


    def draw(self, context):

        layout = self.layout

        col = layout.column()

        col.label(text=_z("Modifiers Applied By Csharp"))
        colrow = col.row(align=True)
        colrow.prop(self, "boolean", text=_z('Bool'), toggle=True)
        colrow.prop(self, "solidify", text=_z('Sol'), toggle=True)
        colrow.prop(self, "bevel", text=_z('Bev'), toggle=True)
        colrow.prop(self, "mirror", text=_z('Mir'), toggle=True)
        colrow.prop(self, "array", text=_z('Arr'), toggle=True)
        colrow.prop(self, "others", text=_z('Others'), toggle=True)
        col.separator()
        if self.bevel:
            colrow = col.row(align=True)
            colrow.prop(self, "bevel_vg", text=_z('Vertex Group bevels applied only'))
        col.separator()
        col.label(text=_z("General Parameters"))
        col = layout.column(align=True)
        colrow = col.row(align=True).split(factor=0.3, align=True)
        colrow.prop(self, "segment_modal", text='')
        colrow.prop(self, "segment_amount")
        colrow = col.row(align=True).split(factor=0.3, align=True)
        colrow.prop(self, "bevelwidth_modal", text='')
        colrow.prop(self, "bevelwidth")
        col.separator()

        col.label(text=_z("Sharpening Parameters"))
        col = layout.column(align=True)
        colrow = col.row(align=True).split(factor=0.3, align=True)
        colrow.prop(self, "additive_mode", toggle=True)
        colrow.prop(addon.preference().property, "sharpness", text=_z("Sharpness"))
        colrow = col.row(align=True).split(factor=0.3, align=True)
        colrow.prop(self, "is_global", text=_z("Global"), toggle=True)
        if self.is_global:
            colrow.prop(addon.preference().property, "auto_smooth_angle", text=_z("Auto Smooth Angle"))
        else:
            colrow.prop(self, "auto_smooth_angle", text=_z("Auto Smooth Angle"))
        col.separator()


    def invoke(self, context, event):

        selected = context.selected_objects
        object = context.active_object

        self.is_global = context.active_object.hops.is_global
        self.auto_smooth_angle = context.active_object.data.auto_smooth_angle

        self.apply_mods = True
        if event.shift:
            self.apply_mods = False

        for obj in selected:
            bevels = [mod for mod in object.modifiers if (mod.type in "BEVEL") and not mod.vertex_group]
            bevel = next(iter(bevels or []), None)
            if bevel is not None:
                self.segment_amount = bevel.segments
                self.bevelwidth = bevel.width
            else:
                self.segment_amount = self.segment_modal
                self.bevelwidth = self.bevelwidth_modal

        self.execute(context)
        if event.shift:
            object.hops.status = "UNDEFINED"

        if addon.preference().property.auto_bweight:
            bpy.ops.hops.adjust_bevel("INVOKE_DEFAULT", ignore_ctrl=True)
        #Assistive to Sharpen
        elif self.to_bwidth:
            bpy.ops.hops.adjust_bevel("INVOKE_DEFAULT", ignore_ctrl=True)

        return {"FINISHED"}


    def execute(self, context):

        selected = context.selected_objects
        object = context.active_object

        for obj in selected:

            complex_sharpen_active_object(
                self,
                obj,
                addon.preference().property.sharpness,
                addon.preference().property.auto_smooth_angle,
                self.additive_mode,
                self.segment_amount,
                self.bevelwidth,
                self.reveal_mesh,
                self.apply_mods)

            update_bevel_modifier_if_necessary(
                obj,
                self.segment_amount,
                self.bevelwidth,
                addon.preference().property.bevel_profile)

            # if addon.preference().property.add_weighten_normals_mod:
            #     update_Weight_modifier_if_necessary(obj)

            obj.hops.is_global = self.is_global
            obj.data.auto_smooth_angle = addon.preference().property.auto_smooth_angle if self.is_global else self.auto_smooth_angle

        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = object

        # Operator UI
        if not HOPS_OT_ComplexSharpenOperator.called_ui:
            HOPS_OT_ComplexSharpenOperator.called_ui = True

            ui = Master()
            draw_data = [
                [_z("Csharp Classic")],
                #["Array",           self.array],
                #["Solidify",        self.solidify],
                [_z("Bevel"),           self.bevel],
                [_z("Boolean "),        self.boolean],
                [_z("Modifiers Applied")],
                ]
            ui.receive_draw_data(draw_data=draw_data)
            ui.draw(draw_bg=addon.preference().ui.Hops_operator_draw_bg, draw_border=addon.preference().ui.Hops_operator_draw_border)


        return {"FINISHED"}


def complex_sharpen_active_object(self, object, sharpness, auto_smooth_angle, additive_mode, segment_amount, bevelwidth, reveal_mesh, apply_mods):

    if apply_mods:
        apply_mod(self, object)

    soft_sharpen_object(object, sharpness, auto_smooth_angle, additive_mode, reveal_mesh)
    object = bpy.context.active_object


def apply_mod(self, object):

    mod_types = []
    others = []
    bevel = []
    last_bevel = None
    if self.boolean:
        mod_types.append('BOOLEAN')
    if self.mirror:
        mod_types.append('MIRROR')
    if self.bevel:
        if self.bevel_vg:
            bevel = [mod for mod in object.modifiers if (mod.type in "BEVEL") and mod.vertex_group]
        else:
            mod_types.append('BEVEL')
            bevels = [mod for mod in object.modifiers if (mod.type in "BEVEL")]
            if bevels:
                last_bevel = bevels[-1]
    if self.solidify:
        mod_types.append('SOLIDIFY')
    if self.array:
        mod_types.append('ARRAY')

    mods = [mod for mod in object.modifiers if mod.type in mod_types]
    if self.others:
        others = [mod for mod in object.modifiers if mod.type not in {'BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY', 'ARRAY'}]
    mod = mods + others + bevel
    if last_bevel:
        mod.remove(last_bevel)
    if mod:
        modifier.apply(object, modifiers=mod)
