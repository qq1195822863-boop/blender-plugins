# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy


class HOPS_OT_CollapseModifiers(bpy.types.Operator):
    """Collapse Modifiers
    Collapse all modifiers

    """
    bl_idname = "hops.collapse_modifiers"
    bl_label = _z("Collapse Modifiers")
    bl_options = {"REGISTER", "INTERNAL"}

    def execute(self, context):

        scene = bpy.context.scene

        objects = [obj for obj in scene.objects if obj.type == "MESH" or "CURVE"]

        for obj in objects:
            for mod in obj.modifiers:
                mod.show_expanded = False

        return {"FINISHED"}


class HOPS_OT_OpenModifiers(bpy.types.Operator):
    """Open Modifiers
Expand all modifiers"""
    bl_idname = "hops.open_modifiers"
    bl_label = _z("Open Modifiers")
    bl_options = {"REGISTER", "INTERNAL"}

    def execute(self, context):

        scene = bpy.context.scene

        objects = [obj for obj in scene.objects if obj.type == "MESH" or "CURVE"]

        for obj in objects:
            for mod in obj.modifiers:
                mod.show_expanded = True

        return {"FINISHED"}
