# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import BoolProperty
from ... utility import addon


class HOPS_OT_DecalMachineFix(bpy.types.Operator):
    bl_idname = "hops.decalmachine_fix"
    bl_label = _z("Enable/Disable DM Fix")
    bl_description = "Enable/Disable DM Fix"
    bl_options = {"REGISTER", "UNDO"}

    option : BoolProperty(name=_z("enable/disable"), default=False, description = "enable/disable")

    def execute(self, context):
        addon.preference().property.decalmachine_fix = self.option

        return {"FINISHED"}
