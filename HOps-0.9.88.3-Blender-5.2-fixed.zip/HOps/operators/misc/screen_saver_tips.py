# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

from ... import bl_info
from ... utility import addon

'''
Make sure to have 2 or more items per list item.
'''


# Screen Saver Tips
tips = [
    [_z("Sharpen / Csharp"), _z("Ctrl + click to apply booleans!"), _z("Also performs sharpening"), _z("Part of sharpen")],
    [_z("Settings >> Shade Solid"), _z("Shift + Click to duplicate and make solid"), _z("Read the tooltip")],
    [_z("BoolShift"), _z("Select a boolshape and press Q"), _z("Shift a bool to any state from any state.")],
    [_z("To_Shape V2"), "Q >> O >> T ", _z("Quick access w/to_shape V2"), _z("Allows for the creation of a shape in the area of a selection"), _z("Decap allows for various interesting possibities")],
    [_z("Q >> Add Modifiers >> Cloth"), _z("Convert a selection to cloth"), _z("Adjust pressure in the cloth panel"), _z("Adjust the shrinkage amount as well."), _z("Optimized for single sided geometry")],
    [_z("Spherecast"), _z("Q >> Meshtools >> Spherecast"), _z("Converts a box into a sphere."),_z("Adds a subdivision then cast modifier.")],
    [_z("Bevel"), _z("1 - Resets bevel to edge bevel defaults (profile 0.5)"), _z("2 - Sets bevel to vert bevel defaults (profile 0.5)"), _z("3 - Allows for a profile 1.0 bevel w/ edge. Useful for subdivision conversion")],
    [_z("Array V2"), _z("Press V for 3d array"), _z("Allows for a more interactive way to set the distance and segments at once.")],
    [_z("LookDev +"), "Alt + V >> V", _z("Press R in modal to set the environment to the render.")],
    [_z("Subdivison"), _z("Q >> Add Modifier >> Subdivision"), _z("Alt + Click to set it first in the stack"), _z("Can be assistive with upresing boolean geometry.")],
    [_z("Taper"), _z("Q >> Meshtools >> Taper"), _z("Shift + clicking allows for individual tapering of multiple objects."), _z("Useful for tapering boolshapes post boxcutting. Supports Wedge")],
    [_z("Dice"), _z("Ctrl + Click to dice on all axis"), _z("Alt + click to smart apply unto dice."), _z("Pressing T allows for Twist to be used post dice")],
    [_z("Stacking Bevels"), _z("Ctrl + click to add a 30 degree bevel "), _z("Ctrl + shift click to add a 60 degree bevel"), _z("Q >> Operations >> Step will also add a 60 degree bevel in non-destructive mode.")],
    [_z("Smart Shapes"), _z("Activate Hopstool using the T Panel button"), _z("The topbar has a plethora of smart shapes to choose from"), _z("Hold ctrl to view dots and adjust shapes dynamically.")],
    [_z("Manage"), _z("Unify - bring all solid objects into the active collection"), _z("Sync - ensure render settings are the exact same as viewport"), _z("Evict - remove cutters and evict cutters to the Cutters collection"), _z("Purify - Delete all cutters unassociated with meshes. But keep extractions")],
    [_z("Smooth"), _z("Shift + click to create a smart vgroup for omission"), _z("Allows for mirrored smoothing"), _z("Ideal for hard surface smoothing")],
    [_z("New Modifier"), _z("Ctrl + click any modifier to add a new modifier"), ],
    [_z("UV Display"), "Q >> O >> U", _z("Display UVs on the fly. In the 3d view!"), _z("Auto UV under Q >> Meshtools >> Auto UV also displays UVs")],
    [_z("Mark "), _z("Edit Mode Q >> Mark"), _z("Without selection mark performs an ssharpen operation ")],
    [_z("Up to date? "), _z("The hops button at the top of the 3d view will tell you "), _z("Icons are also available for the marketplace of your choosing "), _z("Get updated!")],
    [_z("Accushape "), _z("Located in Q >> Operations"), _z("Also at the top of hopstool >> Alt + W "), _z("Allows for interactive scaling and proportion adjustments of objects")],
    [_z("Radial Array "), _z("For single axis mirroring you use mirror (alt + X)"), _z("For radial mirroring, radial array is recommended ")],
    [_z("Sculpt Quick Jump "), _z("Q >> Operations >> Brush "), _z("Displays a brush window for quick selection "), _z("Now supports cloth filter")],
    [_z("Multi Axial Dice "), _z("Q >> Meshtools >> Dice (ctrl + click)"), _z("Ctrl + clicking Dice will dice on all axis "), _z("Dice can be used as a remesher of sorts this way")],
    [_z("UV Display "), "Q >> O >> U ", _z("Displays uvs in the 3d view. ")],
    [_z("Link Ops >> Pizza Ops"), _z("Ever order a pizza?"), _z("Q >> Settings >> Link Ops (ctrl + click)"), _z("AR hates it but it's a classic")],
    [_z("HardOPS Version: {}.{}.{}.{}").format(bl_info['version'][0], bl_info['version'][1], bl_info['version'][2], bl_info['version'][3]), _z("Service Pack Level: {}").format(bl_info['version'][3])],
    [_z("Tips V1"), _z("This is still a concept"), _z("Thanks for reading my tips")],
    [_z("Boolean Grates"), _z("HOPStool grid shapes can be shift clicked to conform to a boolshape"), _z("Try it out!")],
    [_z("Everyscroll Autoscroll"), _z("Shift + Space during everscroll autoscrolls"), _z("Give your middle mouse button a break")],
    [_z("UV Display Edit Mode"), _z("Still Q O U"), _z("Now displays the whole uv set while coloring the selection")],
    [_z("Really like smart apply?"), _z("Sharpen prefs allow it to be mapped now"), _z("Try the successor of Csharpen!")],
    [_z("Dice Join"), _z("When using dice / twist w/ multiple objects they now apply and join"), _z("This should help deform that multiselection")],
    [_z("Pong"), _z("Ctrl + Click about in settings to play pong!"), _z("Now displaying ads from the Link Launcher")],
    [_z("Uniquify"), _z("Now supporting curve cases"), _z("It just gets better and better.")],
    [_z("Selection To Bool V3"), _z("Located in ST3 tools / edit mode"), _z("Turn a face to a boolean. Now better than ever.")],
    [_z("Polygon Debug"), _z("Now at the topbar of hopstool"), _z("Get in and solve that topology!")],
    [_z("Array V2"), _z("Deadzone Circle - allows for adjustment without changing position"), _z("Shows on the launch of array V2")],
    [_z("Uniquify"), _z("Now supporting radial arrays"), _z("Give it a try!")],
    [_z("Curve Alot of Stuff?"), _z("Theres a Q menu option for that"), _z("Use F9 to scroll and find the perfect axis")],
    [_z("3d Cursor Alignment"), _z("Ever tried to align the 3d cursor to an edge / face?"), _z("Edit Mode Q > O > S will take care of you.")],
    [_z("Inset Slice"), _z("Inset is cool and all but have you tried inset slice?"), _z("It can be found in the F9 panel of inset")],
    [_z("Meshclean Editmode"), _z("Start in editmode"), _z("Finish in edit mode.")],
    [_z("Taper / Wedge"), _z("You've seen it in boxcutter."), _z("Now in hops under Q >> Meshtools.")],
    [_z("To_Shape 1.5"), _z("Miss individual orientation with to_shape?"), _z("1.5 is available under opt-ins and has your back.")],
    [_z("Cut In / Merge"), _z("Merge is part of cut_in. Read the tooltip"), _z("Cut / Slice and Intersect all at the same time.")],
    [_z("Select Tool Quad / Tri Support"), _z("Select tool can make quads and tris on the fly if you read the help"), _z("F is also there for making faces and filling them")],
    [_z("Everscroll"), _z("Modifiers, Boolshapes and Children."), _z("Scroll em all and be sure to try shift + space to autoscroll!")],
    ["ZenUV", _z("Shoutout to ZenUV for their requests improving UV Display"), _z("Now supporting Zen UV via HOPSlink!")],
    [_z("Blank Materials"), _z("Generates a random material"), _z("Be sure the read the tooltip. It does alot")],
    [_z("Blank Camera"), _z("When used adds a camera to view in addition to making a marker in the timeline"), _z("Set up shots and pan quick and easy")],
    [_z("Blank Lights"), _z("Don't know what kinda lighting rig to use?"), _z("We'll show you endless possibilities")],
    [_z("Material Replacement w/ Scroll"), _z("Alt + M >> Shift + click material scroll"), _z("Keep the material but replace the nodes.")],
    [_z("Blank Material Scroll"), _z("Ctrl + click blank material to scroll endless blank materials"), _z("Try it with a selection!")],
    [_z("Blank Light Non-Destructive Scroll"), _z("Alt + V >> Ctrl + click Blank Light"), _z("Keep the rig and lights but see endless choices")],
    [_z("Blank Light - Expanded Mode"), _z("Tab in blank light will open a light editor"), _z("Customize, Isolate and refine the ultimate lighting setup")],
    [_z("Light Rig Reuse"), _z("Shift + S in Blank Light allows for rig to be saved"), _z("And with J the configurations saved can be cycled.")],
    [_z("Looking for tutorials?"), _z("Q >> Settings >> Link Ops"), _z("From this window users can scroll and find whatever they need")],
    [_z("HOPS Button"), _z("At the top of the 3d view is the HopsButton"), _z("Links are the final tab and can help you with docs or tutorials.")],
    ["Boxcutter", _z("New to boxcutter?"), _z("N panel displays help and hotkeys. Useful for beginners")],
    [_z("Material Scroll"), _z("Shift + Click - Non-destructive scroll (replace the nodes / keep the mat)"), _z("Ctrl + Click - Blank Material Scroll (unique material per scroll)")],
    [_z("Manage - Collect"), _z("Collect - Unify all solid objects into a reusable collection prime for reuse with PowerLink!"), _z("Available in the F6 ")]
]
