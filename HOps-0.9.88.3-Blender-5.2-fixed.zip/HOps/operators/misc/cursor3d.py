# -*- coding: UTF-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import BoolProperty


class HOPS_OT_Curosr3d(bpy.types.Operator):
    bl_idname = "hops.cursor3d"
    bl_label = _z("Hops set 3d cursor")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Hops set 3d cursor\nSet Boolshape Status"


    def execute(self, context):

        prefs = context.window_manager.keyconfigs[bpy.context.preferences.keymap.active_keyconfig].preferences
        if 'select_mouse' in prefs:
            if prefs['select_mouse'] == 1:
                return {'PASS_THROUGH'}
        
        #py.ops.transform.translate(cursor_transform=True)

        bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', orientation='GEOM')

        return {'FINISHED'}
