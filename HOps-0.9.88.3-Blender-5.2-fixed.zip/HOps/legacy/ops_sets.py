# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy
import bpy.utils.previews
from bpy.types import WindowManager
from bpy.props import BoolProperty, IntProperty, FloatProperty, EnumProperty
from bpy.props import *
from .. utils.addons import addon_exists
from .. utility import addon
from ..ui_framework.operator_ui import Master

#############################
# RenderSet1
#############################

# Sets Up The Render / As Always

class HOPS_OT_renset1Operator(bpy.types.Operator):
    
    bl_idname = 'render.setup'
    bl_label = _z('HQ RenderSetup')
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Sets Eevee / Cycles settings to render High Quality\nConfigurable in HOPS Dropdown render section\nEnables Cavity / Shadow in viewport shading.\nF9 for fine adjustments")

    use_square_samples: BoolProperty(name=_z("use_square_samples"), default=True, description = "use_square_samples")
    sample_clamp_indirect: IntProperty(name=_z("sample_clamp_indirect"), default=2, description = "sample_clamp_indirect")
    sample_clamp_direct: IntProperty(name=_z("sample_clamp_direct"), default=2, description = "sample_clamp_direct")
    preview_samples: IntProperty(name=_z("preview_samples"), default=40, description = "preview_samples")
    samples: IntProperty(name=_z("samples"), default=15, description = "samples")
    min_bounces: IntProperty(name=_z("min_bounces"), default=5, description = "min_bounces")
    glossy_bounces: IntProperty(name=_z("glossy_bounces"), default=16, description = "glossy_bounces")
    diffuse_bounces: IntProperty(name=_z("diffuse_bounces"), default=16, description = "diffuse_bounces")
    blur_glossy: FloatProperty(name=_z("blur_glossy"), default=1, description = "blur_glossy")
    sample_as_light: BoolProperty(name=_z("sample_as_light"), default=True, description = "sample_as_light")
    sample_map_resolution: IntProperty(name=_z("sample_map_resolution"), default=512, description = "sample_map_resolution")
    light_sampling_threshold: IntProperty(name=_z("light_sampling_threshold"), default=0, description = "light_sampling_threshold")


    use_gtao: BoolProperty(name=_z("use_gtao"), default=True, description = "use_gtao")
    use_ssr: BoolProperty(name=_z("use_ssr"), default=True, description = "use_ssr")
    use_ssr_halfres: BoolProperty(name=_z("use_ssr_halfres"), default=False, description = "use_ssr_halfres")
    use_soft_shadows: BoolProperty(name=_z("use_soft_shadows"), default=True, description = "use_soft_shadows")
    use_shadow_high_bitdepth: BoolProperty(name=_z("use_shadow_high_bitdepth"), default=True, description = "use_shadow_high_bitdepth")
    gi_diffuse_bounces: IntProperty(name=_z("gi_diffuse_bounces"), default=4, description = "gi_diffuse_bounces")
    taa_samples: IntProperty(name=_z("taa_samples"), default=64, description = "taa_samples")
    show_shadows: BoolProperty(name=_z("show_shadows"), default=True, description = "show_shadows")
    show_cavity: BoolProperty(name=_z("show_cavity"), default=True, description = "show_cavity")
    use_scene_lights: BoolProperty(name=_z("use_scene_lights"), default=True, description = "use_scene_lights")
    curvature_valley_factor: FloatProperty(name=_z("curvature_valley_factor"), default=0.745455, description = "curvature_valley_factor")
    curvature_ridge_factor: FloatProperty(name=_z("curvature_ridge_factor"), default=0.690909, description = "curvature_ridge_factor")
    cavity_valley_factor: FloatProperty(name=_z("cavity_valley_factor"), default=0.475, description = "cavity_valley_factor")
    cavity_ridge_factor: FloatProperty(name=_z("cavity_ridge_factor"), default=0.225, description = "cavity_ridge_factor")

    called_ui = False

    def __init__(self, *args, **kwargs):

        HOPS_OT_renset1Operator.called_ui = False

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)

        if context.scene.render.engine == 'CYCLES':
            column.prop(self, "use_square_samples")
            column.prop(self, "sample_clamp_indirect")
            column.prop(self, "sample_clamp_direct")
            column.prop(self, "preview_samples")
            column.prop(self, "samples")
            column.prop(self, "min_bounces")
            column.prop(self, "glossy_bounces")
            column.prop(self, "diffuse_bounces")
            column.prop(self, "blur_glossy")
            column.prop(self, "sample_as_light")
            column.prop(self, "sample_map_resolution")
            column.prop(self, "light_sampling_threshold")

        if context.scene.render.engine == 'BLENDER_EEVEE':

            column.prop(self, "use_gtao")
            column.prop(self, "use_ssr")
            column.prop(self, "use_ssr_halfres")
            column.prop(self, "use_soft_shadows")
            column.prop(self, "use_shadow_high_bitdepth")

            row = column.row(align=True)
            row.prop(addon.preference().property, "Eevee_preset_HQ", expand=True)

            column.prop(self, "gi_diffuse_bounces")
            column.prop(self, "taa_samples")
            column.prop(self, "show_shadows")
            column.prop(self, "show_cavity")
            column.prop(self, "use_scene_lights")
            column.prop(self, "curvature_valley_factor")
            column.prop(self, "curvature_ridge_factor")
            column.prop(self, "cavity_valley_factor")
            column.prop(self, "cavity_ridge_factor")

    def execute(self, context):
        c = bpy.context.scene
        c2 = bpy.context.space_data.shading

        if c.render.engine == 'CYCLES':
            c.cycles.progressive = 'PATH'
            c.cycles.use_square_samples = self.use_square_samples
            c.cycles.sample_clamp_indirect = self.sample_clamp_indirect
            c.cycles.sample_clamp_direct = self.sample_clamp_direct
            c.cycles.preview_samples = self.preview_samples
            c.cycles.samples = self.samples
            c.cycles.min_bounces = self.min_bounces
            c.cycles.glossy_bounces = self.glossy_bounces
            c.cycles.diffuse_bounces = self.diffuse_bounces
            c.cycles.blur_glossy = self.blur_glossy
            c.world.cycles.sample_as_light = self.sample_as_light
            c.world.cycles.sample_map_resolution = self.sample_map_resolution
            c.cycles.light_sampling_threshold = self.light_sampling_threshold
        if c.render.engine == 'BLENDER_EEVEE':
            c.render.engine = 'BLENDER_EEVEE'
            c.eevee.use_gtao = self.use_gtao
            c.eevee.use_ssr = self.use_ssr
            c.eevee.use_ssr_halfres = self.use_ssr_halfres
            c.eevee.use_soft_shadows = self.use_soft_shadows
            c.eevee.use_shadow_high_bitdepth = self.use_shadow_high_bitdepth
            c.eevee.shadow_cube_size = addon.preference().property.Eevee_preset_HQ
            c.eevee.gi_cubemap_resolution = addon.preference().property.Eevee_preset_HQ
            c.eevee.shadow_cascade_size = addon.preference().property.Eevee_preset_HQ
            c.eevee.gi_diffuse_bounces = self.gi_diffuse_bounces
            c.eevee.taa_samples = self.taa_samples

            #Shading
            c2.show_shadows = self.show_shadows
            c2.show_cavity = self.show_cavity
            c2.use_scene_lights = self.use_scene_lights
            c2.cavity_type = 'BOTH'
            c2.curvature_valley_factor = self.curvature_valley_factor
            c2.curvature_ridge_factor = self.curvature_ridge_factor
            c2.cavity_valley_factor = self.cavity_valley_factor
            c2.cavity_ridge_factor = self.cavity_ridge_factor

        else:
            pass

        # Operator UI
        if not HOPS_OT_renset1Operator.called_ui:
            HOPS_OT_renset1Operator.called_ui = True

            ui = Master()

            if c.render.engine == 'BLENDER_EEVEE':
                draw_data = [
                    [_z("Eevee HQ")],
                    [_z("Eevee configured to high quality"), ""],
                    [_z("Resolution"), addon.preference().property.Eevee_preset_HQ],
                    [_z("Soft Shadows"), self.use_soft_shadows],
                    [_z("Reflections"), self.use_ssr],
                    [_z("Viewport Cavity/Shadows"), _z(self.show_cavity)],
                    ]
            else:
                draw_data = [
                    [_z("Cycles HQ")],
                    [_z("Cycles configured to high quality"), ""],
                    [_z("Samples"), self.samples],
                    [_z("Preview Samples"), self.preview_samples],
                    [_z("Glossy Bounces"), self.glossy_bounces]
                    ]
            ui.receive_draw_data(draw_data=draw_data)
            ui.draw(draw_bg=addon.preference().ui.Hops_operator_draw_bg, draw_border=addon.preference().ui.Hops_operator_draw_border)

        return {'FINISHED'}

#############################
# RenderSet2
#############################

# Sets Up The Render / As Always
class HOPS_OT_renset2Operator(bpy.types.Operator):
    
    bl_idname = "renderb.setup"
    bl_label = _z("LQ RenderSetup")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Sets Eevee / Cycles settings to render Lower Quality\nConfigurable in HOPS Dropdown render section\nDisables Cavity / Shadow in viewport shading.\nF9 for fine adjustments")

    use_square_samples: BoolProperty(name=_z("use_square_samples"), default=True, description = "use_square_samples")
    sample_clamp_indirect: IntProperty(name=_z("sample_clamp_indirect"), default=10, description = "sample_clamp_indirect")
    sample_clamp_direct: IntProperty(name=_z("sample_clamp_direct"), default=0, description = "sample_clamp_direct")
    preview_samples: IntProperty(name=_z("preview_samples"), default=40, description = "preview_samples")
    samples: IntProperty(name=_z("samples"), default=40, description = "samples")
    min_bounces: IntProperty(name=_z("min_bounces"), default=5, description = "min_bounces")
    glossy_bounces: IntProperty(name=_z("glossy_bounces"), default=8, description = "glossy_bounces")
    transparent_max_bounces: IntProperty(name=_z("transparent_max_bounces"), default=8, description = "transparent_max_bounces")
    transmission_bounces: IntProperty(name=_z("transmission_bounces"), default=8, description = "transmission_bounces")
    volume_bounces: IntProperty(name=_z("volume_bounces"), default=8, description = "volume_bounces")
    diffuse_bounces: IntProperty(name=_z("diffuse_bounces"), default=8, description = "diffuse_bounces")
    blur_glossy: FloatProperty(name=_z("blur_glossy"), default=1, description = "blur_glossy")
    sample_map_resolution: IntProperty(name=_z("sample_map_resolution"), default=512, description = "sample_map_resolution")
    light_sampling_threshold: IntProperty(name=_z("light_sampling_threshold"), default=0, description = "light_sampling_threshold")
    caustics_reflective: BoolProperty(name=_z("caustics_reflective"), default=True, description = "caustics_reflective")
    caustics_refractive: BoolProperty(name=_z("caustics_refractive"), default=True, description = "caustics_refractive")

    use_gtao: BoolProperty(name=_z("use_gtao"), default=False, description = "use_gtao")
    use_ssr: BoolProperty(name=_z("use_ssr"), default=False, description = "use_ssr")
    use_bloom: BoolProperty(name=_z("use_bloom"), default=False, description = "use_bloom")
    use_ssr_halfres: BoolProperty(name=_z("use_ssr_halfres"), default=True, description = "use_ssr_halfres")
    use_soft_shadows: BoolProperty(name=_z("use_soft_shadows"), default=False, description = "use_soft_shadows")
    use_taa_reprojection: BoolProperty(name=_z("use_taa_reprojection"), default=False, description = "use_taa_reprojection")
    use_shadow_high_bitdepth: BoolProperty(name=_z("use_shadow_high_bitdepth"), default=False, description = "use_shadow_high_bitdepth")
    gi_diffuse_bounces: IntProperty(name=_z("gi_diffuse_bounces"), default=2, description = "gi_diffuse_bounces")
    taa_samples: IntProperty(name=_z("taa_samples"), default=2, description = "taa_samples")
    show_shadows: BoolProperty(name=_z("show_shadows"), default=False, description = "show_shadows")
    show_cavity: BoolProperty(name=_z("show_cavity"), default=False, description = "show_cavity")

    called_ui = False

    def __init__(self, *args, **kwargs):

        HOPS_OT_renset2Operator.called_ui = False

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)

        if context.scene.render.engine == 'CYCLES':

            column.prop(self, "use_square_samples")
            column.prop(self, "sample_clamp_indirect")
            column.prop(self, "sample_clamp_direct")
            column.prop(self, "preview_samples")
            column.prop(self, "samples")
            column.prop(self, "min_bounces")
            column.prop(self, "glossy_bounces")
            column.prop(self, "transparent_max_bounces")
            column.prop(self, "transmission_bounces")
            column.prop(self, "volume_bounces")
            column.prop(self, "diffuse_bounces")
            column.prop(self, "blur_glossy")
            column.prop(self, "sample_map_resolution")
            column.prop(self, "light_sampling_threshold")
            column.prop(self, "caustics_reflective")
            column.prop(self, "caustics_refractive")

        if context.scene.render.engine == 'BLENDER_EEVEE':

            column.prop(self, "use_gtao")
            column.prop(self, "use_ssr")
            column.prop(self, "use_bloom")
            column.prop(self, "use_ssr_halfres")
            column.prop(self, "use_soft_shadows")
            column.prop(self, "use_taa_reprojection")
            column.prop(self, "use_shadow_high_bitdepth")
            column.prop(self, "gi_diffuse_bounces")

            row = column.row(align=True)
            row.prop(addon.preference().property, "Eevee_preset_LQ", expand=True)

            column.prop(self, "taa_samples")
            column.prop(self, "show_shadows")
            column.prop(self, "show_cavity")

    def execute(self, context):
        c = bpy.context.scene
        c2 = bpy.context.space_data.shading
        if bpy.context.scene.render.engine == 'CYCLES':
            c.cycles.progressive = 'PATH'
            c.cycles.use_square_samples = self.use_square_samples
            c.cycles.samples = self.samples
            c.cycles.glossy_bounces = self.glossy_bounces
            c.cycles.transparent_max_bounces = self.transparent_max_bounces
            c.cycles.transmission_bounces = self.transmission_bounces
            c.cycles.volume_bounces = self.volume_bounces
            c.cycles.diffuse_bounces = self.diffuse_bounces
            c.cycles.sample_clamp_direct = self.sample_clamp_direct
            c.cycles.sample_clamp_indirect = self.sample_clamp_indirect
            c.cycles.blur_glossy = self.blur_glossy
            c.cycles.caustics_reflective = self.caustics_reflective
            c.cycles.caustics_refractive = self.caustics_refractive
            c.cycles.device = 'GPU'
        if c.render.engine == 'BLENDER_EEVEE':
            c.render.engine = 'BLENDER_EEVEE'
            c.eevee.use_gtao = self.use_gtao
            c.eevee.use_ssr = self.use_ssr
            #c.eevee.use_dof = self.use_dof
            c.eevee.use_bloom = self.use_bloom
            c.eevee.use_shadow_high_bitdepth = self.use_shadow_high_bitdepth
            c.eevee.use_taa_reprojection = self.use_taa_reprojection
            c.eevee.use_ssr_halfres = self.use_ssr_halfres
            c.eevee.use_soft_shadows = self.use_soft_shadows
            #bpy.context.space_data.overlay.show_overlays = True
            c.eevee.shadow_cube_size = addon.preference().property.Eevee_preset_LQ
            c.eevee.gi_cubemap_resolution = addon.preference().property.Eevee_preset_LQ
            c.eevee.shadow_cascade_size = addon.preference().property.Eevee_preset_LQ
            c.eevee.taa_samples = self.taa_samples
            #Shading
            c2.show_shadows = self.show_shadows
            c2.show_cavity = self.show_cavity
        else:
            pass

        # Operator UI
        if not HOPS_OT_renset2Operator.called_ui:
            HOPS_OT_renset2Operator.called_ui = True

            ui = Master()

            if c.render.engine == 'BLENDER_EEVEE':
                draw_data = [
                    [_z("Eevee LQ")],
                    [_z("Eevee configured to low quality"), ""],
                    [_z("Resolution"), addon.preference().property.Eevee_preset_LQ],
                    [_z("Soft Shadows"), self.use_soft_shadows],
                    [_z("Reflections"), self.use_ssr],
                    [_z("Viewport Cavity/Shadows"), self.show_cavity]
                    ]
            else:
                draw_data = [
                    [_z("Cycles LQ")],
                    [_z("Cycles configured to low quality"), ""],
                    [_z("Samples"), self.samples],
                    [_z("Preview Samples"), self.preview_samples],
                    [_z("Glossy Bounces"), self.glossy_bounces]
                    ]
            ui.receive_draw_data(draw_data=draw_data)
            ui.draw(draw_bg=addon.preference().ui.Hops_operator_draw_bg, draw_border=addon.preference().ui.Hops_operator_draw_border)

        return {'FINISHED'}

#############################
# RenderSet3
#############################

class HOPS_OT_renset3Operator(bpy.types.Operator):
    
    bl_idname = 'renderc.setup'
    bl_label = _z('RenderSetupc')
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Sets Eevee / Cycles settings to render High Quality")

    colmgm : BoolProperty(default=False)

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)
        row = column.row(align=True)
        row.prop(addon.preference().property, "Eevee_preset_HQ", expand=True)

    def execute(self, context):
        c = bpy.context.scene
        c2 = bpy.context.space_data.shading

        if c.render.engine == 'CYCLES':
            c.cycles.device = 'GPU'
            # c.render.tile_x = 256
            # c.render.tile_y = 256
            try:
                c.view_settings.look = _z('AgX - High Contrast')
                bpy.ops.hops.display_notification(info=F'GPU HQ', subtext = _z('AgX - High Contrast'))
            except:
                bpy.ops.hops.display_notification(info=F'GPU HQ', subtext = _z('AgX Unavailable'))
            c.cycles.progressive = 'PATH'
            c.cycles.use_square_samples = True
            c.cycles.sample_clamp_indirect = 2
            c.cycles.sample_clamp_direct = 2
            c.cycles.preview_samples = 40
            c.cycles.samples = 25
            c.cycles.min_bounces = 5
            c.cycles.max_bounces = 16
            c.cycles.diffuse_bounces = 16
            c.cycles.glossy_bounces = 16
            c.cycles.transparent_max_bounces = 16
            c.cycles.transmission_bounces = 16
            c.cycles.volume_bounces = 0
            c.cycles.blur_glossy = 0.8
            c.world.cycles.sample_as_light = True
            c.world.cycles.sample_map_resolution = 2048
            c.cycles.light_sampling_threshold = 0
        if c.render.engine == 'BLENDER_EEVEE':
            c.render.engine = 'BLENDER_EEVEE'
            c.eevee.use_gtao = True
            c.eevee.use_ssr = True
            c.eevee.use_ssr_halfres = False
            c.eevee.use_soft_shadows = True
            c.eevee.use_shadow_high_bitdepth = True
            c.eevee.shadow_cube_size = addon.preference().property.Eevee_preset_HQ
            c.eevee.gi_cubemap_resolution = addon.preference().property.Eevee_preset_HQ
            c.eevee.shadow_cascade_size = addon.preference().property.Eevee_preset_HQ
            c.eevee.gi_diffuse_bounces = 4
            c.eevee.taa_samples = 64

            #Shading
            c2.show_shadows = True
            c2.show_cavity = True
            c2.use_scene_lights = True
            c2.cavity_type = 'BOTH'
            c2.curvature_valley_factor = 0.745455
            c2.curvature_ridge_factor = 0.690909
            c2.cavity_valley_factor = 0.475
            c2.cavity_ridge_factor = 0.225

        else:
            pass

        return {'FINISHED'}


#############################
# Set UI Ops Start Here
#############################

# Return The UI Back To Normal


class HOPS_OT_ReguiOperator(bpy.types.Operator):
    
    bl_idname = "ui.reg"
    bl_label = _z("regViewport")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Solid / Texture Toggle\nToggle general viewport and material view in viewport.\nUseful for uprez tasks and tasks involving a material reference")

    def execute(self, context):

        bpy.context.space_data.shading.type = 'SOLID'
        if bpy.context.space_data.shading.light != 'FLAT':
            bpy.context.space_data.shading.light = 'FLAT'
            bpy.context.space_data.shading.color_type = 'TEXTURE'
        else:
            bpy.context.space_data.shading.light = 'STUDIO'
            bpy.context.space_data.shading.color_type = 'MATERIAL'
        return {'FINISHED'}


# Attempting To Clean Up UI For A Clean Workspace

class HOPS_OT_CleanuiOperator(bpy.types.Operator):
    
    bl_idname = "ui.clean"
    bl_label = _z("cleanViewport")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Regular viewport elements hidden / simplified view.")


    def execute(self, context):
        c = bpy.context.space_data.overlay
        c2 = bpy.context.space_data.shading

        if c.show_cursor == True:
            c.show_overlays = True
            c.show_cursor = False
            c.show_extras = False
            c.show_floor = False
            c.show_ortho_grid = False
            c.show_axis_x = False
            c.show_axis_y = False
            c.show_relationship_lines = False
            c.show_object_origins = False
            bpy.ops.hops.display_notification(info=_z('Simplify Viewport - On'))
        else:
            c.show_overlays = True
            c.show_cursor = True
            c.show_extras = True
            c.show_floor = True
            c.show_ortho_grid = True
            c.show_axis_x = True
            c.show_axis_y = True
            c.show_relationship_lines = True
            c.show_object_origins = True
            bpy.ops.hops.display_notification(info=_z('Simplify Viewport - Off'))
        return {'FINISHED'}

# Sets the final frame. Experimental


class HOPS_OT_EndframeOperator(bpy.types.Operator):
    
    bl_idname = "setframe.end"
    bl_label = _z("Frame Range")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Frame Range Popup\nAllows user to specify start / end frame")

    #this should be a property next to the option

    firstframe: IntProperty(name=_z("StartFrame"), description="StartFrame\nSetStartFrame.", default=1, min=1, max=20000)
    lastframe: IntProperty(name=_z("EndFrame"), description="EndFrame\nSetStartFrame.", default=6000, min=1, max=20000)

    def execute(self, context):
        lastframe = self.lastframe  # needed to get var involved
        firstframe = self.firstframe
        bpy.context.scene.frame_start = firstframe
        bpy.context.scene.frame_end = lastframe
        if addon.preference().ui.Hops_extra_info:
            bpy.ops.hops.display_notification(info=_z("Last Frame: {}").format(lastframe))
        return {'FINISHED'}

# Sets the final frame. Experimental


class HOPS_OT_MeshdispOperator(bpy.types.Operator):
    
    bl_idname = "hops.meshdisp"
    bl_label = _z("Mesh Disp")
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = _z("Hides Marked Edges from view.")

    # this should be a property next to the option

    # firstframe = IntProperty(name="StartFrame", description="SetStartFrame.", default=1, min = 1, max = 20000)
    # lastframe = IntProperty(name="EndFrame", description="SetStartFrame.", default=100, min = 1, max = 20000)

    def execute(self, context):
        if bpy.context.space_data.overlay.show_edge_sharp:
            bpy.context.space_data.overlay.show_edge_crease = False
            bpy.context.space_data.overlay.show_edge_sharp = False
            bpy.context.space_data.overlay.show_edge_bevel_weight = False
            bpy.context.space_data.overlay.show_edge_seams = False
            bpy.ops.hops.display_notification(info=_z("Mesh Overlays: Off"))
        else:
            bpy.context.space_data.overlay.show_edge_crease = True
            bpy.context.space_data.overlay.show_edge_sharp = True
            bpy.context.space_data.overlay.show_edge_bevel_weight = True
            bpy.context.space_data.overlay.show_edge_seams = True
            bpy.ops.hops.display_notification(info=_z("Mesh Overlays: On"))

        return {'FINISHED'}
