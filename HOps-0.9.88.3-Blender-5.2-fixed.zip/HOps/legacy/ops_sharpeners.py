# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

import bpy
from bpy.props import BoolProperty
import bpy.utils.previews

# Clean Off Bevel and Sharps In Edit Mode


class HOPS_OT_UnsharpOperatorE(bpy.types.Operator):
    """UnsharpBevelE
    Removes marking from edges.

    """
    bl_idname = "clean1.objects"
    bl_label = _z("UnsharpBevelE")
    bl_options = {'REGISTER', 'UNDO'}

    clearsharps: BoolProperty(default=True)
    clearbevel: BoolProperty(default=True)
    clearcrease: BoolProperty(default=True)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop(self, 'clearsharps', text=_z("Clear Sharps"))
        box.prop(self, 'clearbevel', text=_z("Clear Bevels"))
        box.prop(self, 'clearcrease', text=_z("Clear Crease"))

    def execute(self, context):

        if self.clearsharps is True:
            bpy.ops.mesh.mark_sharp(clear=True)
        if self.clearbevel is True:
            bpy.ops.transform.edge_bevelweight(value=-1)
        if self.clearcrease is True:
            bpy.ops.transform.edge_crease(value=-1)

        return {'FINISHED'}

# Bevel and Sharps In Edit Mode to Selection
class HOPS_OT_SharpandbevelOperatorE(bpy.types.Operator):
    """SharpBevelE
    Mark Sharps And Bevels In Edit Mode

    """
    bl_idname = "bevelandsharp1.objects"
    bl_label = _z("SharpBevelE")
    bl_options = {'REGISTER', 'UNDO'}

    marksharps: BoolProperty(default=True)
    markbevel: BoolProperty(default=True)
    markcrease: BoolProperty(default=True)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop(self, 'marksharps', text=_z("Mark Sharps"))
        box.prop(self, 'markbevel', text=_z("Mark Bevels"))
        box.prop(self, 'markcrease', text=_z("Mark Crease"))

    def execute(self, context):
        marksharps = self.marksharps
        markbevel = self.markbevel
        markcrease = self.markcrease

        # (former)
        # bpy.ops.transform.edge_bevelweight(value=1)
        # bpy.ops.transform.edge_crease(value=1)
        # bpy.ops.mesh.mark_sharp()

        if marksharps is True:
            bpy.ops.mesh.mark_sharp()
        if markbevel is True:
            bpy.ops.transform.edge_bevelweight(value=1)
        if markcrease is True:
            bpy.ops.transform.edge_crease(value=1)

        return {'FINISHED'}
