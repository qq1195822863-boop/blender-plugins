# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

from . import types
from . import modifiers

import bpy
from bpy.props import PointerProperty
from bpy.types import PropertyGroup


class HOpsSceneProeprties(PropertyGroup):
    collection: PointerProperty(type=bpy.types.Collection)
    modifiers: PointerProperty(type=modifiers.HOpsModifiers)


classes = (
    types.HOpsObjectProperties,
    types.HOpsMeshProperties,
    types.HOpsNodeProperties,
    types.HOpsImgProperties,
    modifiers.HOpsModifiers,
    HOpsSceneProeprties
)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Object.hops = PointerProperty(name=_z("HardOps Properties"), type=types.HOpsObjectProperties, description = "HardOps Properties")
    bpy.types.Mesh.hops = PointerProperty(name=_z("HardOps Mesh Props"), type=types.HOpsMeshProperties, description = "HardOps Mesh Props")
    bpy.types.Node.hops = PointerProperty(name=_z("HardOps Node Props"), type=types.HOpsNodeProperties, description = "HardOps Node Props")
    bpy.types.Image.hops = PointerProperty(name=_z("HardOps Node Props"), type=types.HOpsImgProperties, description = "HardOps Node Props")
    bpy.types.Scene.hops = PointerProperty(name=_z("HardOps Scene Props"), type=HOpsSceneProeprties, description = "HardOps Scene Props")


def unregister():
    from bpy.utils import unregister_class
    for cls in classes:
        unregister_class(cls)

    del bpy.types.Object.hops
    del bpy.types.Mesh.hops
    del bpy.types.Node.hops
    del bpy.types.Image.hops
    del bpy.types.Scene.hops
