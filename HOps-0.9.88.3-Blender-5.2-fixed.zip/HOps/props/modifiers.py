# -*- coding:utf-8 -*-
from HOps.iBlender_HOps import _z

from bpy.types import PropertyGroup
from bpy.props import BoolProperty


class HOpsModifiers(PropertyGroup):

    array1: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    garray_random: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    garray_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    bevel1: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    bevel2: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    bevel3: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    build_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gmirror_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gmulistroke_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    ghook_falloff: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    ghook_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    glattice_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    mirrordata: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    multires_advanced: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    multires_subdivision: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    multires_shape: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    multires_generate: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    goffset_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gnoice_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gcolor_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gopacity_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gtex_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gtint_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    screw_normals: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    solidify_normals: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    solidify_materials: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    solidify_edgedata: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    solidify_thicknes: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    solidify_output: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    subsurf_advanced: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gsubsurf_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gsmooth_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gsimplify_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gthick_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    gtime_influence: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    wireframe_vgroup: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    hook_falloff: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    simpledeform_restrictions: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    warp_falloff: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    warp_textures: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    wave_start: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    wave_time: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    wave_texture: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    uvwarp_transform: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    normaledit_mix: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    normaledit_offset: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    datatransfer_toplogy: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    datatransfer_vgroups: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    datatransfer_vcolors: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    datatransfer_uv: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    transformation_map: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    transformation_to: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)

    node_outputs: BoolProperty(
        name=_z('prop'),
        description="prop\nused for panel replacement",
        default=False)